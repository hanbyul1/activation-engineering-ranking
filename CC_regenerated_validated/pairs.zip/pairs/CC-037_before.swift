
    func detectPatterns(rows: [OCRRow]) -> [ExtractionUtilityPattern] {

        var patterns: Set<ExtractionUtilityPattern> = []

        for row in rows {

            let text = row.fullText.uppercased()

            // 🔥 1. METER READING (water/gas/electric 일부)
            if text.contains("CURR") ||
               text.contains("PREV") ||
               text.contains("READ") ||
               text.contains("CU FT") ||
                isMeterLikeRow(text){

                patterns.insert(.meterReading)
            }

            // 🔥 숫자 구조 기반 fallback (핵심 추가)
            // 예: "1572A 1553A 19 $20.14"
            if isMeterLikeRow(text) {
                patterns.insert(.meterReading)
            }

            // 🔥 2. DIRECT USAGE (electric/gas)
            if text.contains("KWH") ||
               text.contains("THERM") ||
               text.contains("USED") ||
               text.contains("USAGE") {

                patterns.insert(.directUsage)
            }

            // 🔥 3. MONETARY
            if text.contains("AMOUNT") || text.contains("$") {
                patterns.insert(.monetary)
            }

            // 🔥 4. DATE RANGE
            if text.contains("PERIOD") ||
               text.contains("-") ||
               text.range(of: #"\d{2}/\d{2}/\d{2,4}"#, options: .regularExpression) != nil {

                patterns.insert(.dateRange)
            }
        }

        print("🔥 DETECTED PATTERNS:", patterns)

        return Array(patterns)
    }