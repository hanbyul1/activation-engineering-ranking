func matchesAll(
    recipe: RecipeDetail,
    filters: [RecipeSearchFilter: [String]]
) -> Bool {
    return matchesAllCore(recipe, filters)
}


func matchesAllCore(
    recipe: RecipeDetail,
    filters: [RecipeSearchFilter: [String]]
) -> Bool {

    let nameText = recipe.name.lowercased()

    let ingredientText = recipe.ingredients
        .joined(separator: " ")
        .lowercased()

    // =======================
    // 🔥 Excluded Ingredient — ABSOLUTE PRIORITY
    // (ingredient only)
    // =======================
    if let excluded = filters[.excludedIngredient], !excluded.isEmpty {
        for bad in excluded {
            if ingredientText.contains(bad.lowercased()) {
                return false // ❌ 즉시 탈락
            }
        }
    }

    // =======================
    // Normal filters
    // =======================
    for (filter, values) in filters {

        switch filter {

        // =================================================
        // 🔎 NAME ONLY SEARCH
        // =================================================
        case .cuisine:
            let ok = values.contains { cuisine in
                guard let keywords = cuisineKeywordMap[cuisine] else { return false }
                return keywords.contains { nameText.contains($0) }
            }
            if !ok { return false }

        case .dishType:
            if values.isEmpty { continue }
            let ok = values.contains { dish in
                let d = dish.lowercased()

                if d == "dessert" {
                    return dessertKeywords.contains {
                        nameText.contains($0)
                    }
                }

                if d == "soup" {
                    return soupKeywords.contains {
                        nameText.contains($0)
                    }
                }

                if d == "noodle" {
                    return noodleKeywords.contains {
                        nameText.contains($0)
                    }
                }

                if d == "salad" {
                    return saladKeywords.contains {
                        nameText.contains($0)
                    }
                }

                if d == "side" {
                    return sideKeywords.contains {
                        nameText.contains($0)
                    }
                }

                // Main / 기타
                return nameText.contains(d)
            }
            if !ok { return false }

        case .diet:
            if values.isEmpty { continue }
            let ingredientText = recipe.ingredients
                .joined(separator: " ")
                .lowercased()

            let ok = values.contains { diet in
                switch diet.lowercased() {

                case "vegan":
                    return !veganForbidden.contains {
                        ingredientText.contains($0)
                    }

                case "vegetarian":
                    return !vegetarianForbidden.contains {
                        ingredientText.contains($0)
                    }

                case "keto":
                    return !ketoForbidden.contains {
                        ingredientText.contains($0)
                    }

                default:
                    return true
                }
            }

            if !ok { return false }

        case .cookingMethod:
            if values.isEmpty { continue }
            let name = recipe.name.lowercased()

            let ok = values.contains { method in
                switch method {
                case "Grilled":
                    return grilledKeywords.contains { name.contains($0) }
                case "Steamed":
                    return steamedKeywords.contains { name.contains($0) }
                case "Fried":
                    return friedKeywords.contains { name.contains($0) }
                default:
                    return false
                }
            }

            if !ok { return false }

        // =================================================
        // 🧺 INGREDIENT ONLY SEARCH
        // =================================================
        case .mainIngredient:
            if values.isEmpty { continue }
            let ingredientText = recipe.ingredients
                .joined(separator: " ")
                .lowercased()

            let ok = values.contains { selected in
                let key = selected.lowercased()
                guard let keywords = mainIngredientMap[key] else { return false }

                return keywords.contains {
                    ingredientText.contains($0)
                }
            }

            if !ok { return false }

        case .nutritionFocus:
            if values.isEmpty { continue }
            let text = recipe.ingredients
                .joined(separator: " ")
                .lowercased()

            let ok = values.contains { focus in
                switch focus {

                case "Low Sugar":
                    // 명시적 low-sugar 표현이 있으면 OK
                    if lowSugarKeywords.contains(where: { text.contains($0) }) {
                        return true
                    }
                    // sugar 관련 재료가 없으면 OK
                    return !highSugarKeywords.contains(where: { text.contains($0) })

                case "Low Sodium":
                    if lowSodiumKeywords.contains(where: { text.contains($0) }) {
                        return true
                    }
                    return !highSodiumKeywords.contains(where: { text.contains($0) })

                case "High Protein":
                    return highProteinKeywords.contains {
                        text.contains($0)
                    }

                default:
                    return false
                }
            }

            if !ok { return false }

        case .occasion:
            if values.isEmpty { continue }
            let ok = values.contains { occasion in
                let o = occasion.lowercased()

                switch o {
                case "party":
                    return partyKeywords.contains {
                        nameText.contains($0)
                    }

                case "holiday":
                    return holidayKeywords.contains {
                        nameText.contains($0)
                    }

                case "everyday":
                    // Party / Holiday에 안 걸리면 Everyday
                    let isParty = partyKeywords.contains {
                        nameText.contains($0)
                    }
                    let isHoliday = holidayKeywords.contains {
                        nameText.contains($0)
                    }
                    return !isParty && !isHoliday

                default:
                    return false
                }
            }

            if !ok { return false }
            
        case .excludedIngredient:
            if values.isEmpty { continue }
            // 이미 위에서 처리됨
            continue

        }
    }

    return true
}