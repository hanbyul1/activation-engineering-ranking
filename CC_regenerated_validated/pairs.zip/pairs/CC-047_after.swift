private func isBioGroupCompatible(
        canon: BioGroup,
        candidate: BioGroup,
        role: IngredientRole
    ) -> Bool {
    return isBioGroupCompatibleCore(canon, candidate, role)
}


    private func isBioGroupCompatibleCore(
        canon: BioGroup,
        candidate: BioGroup,
        role: IngredientRole
    ) -> Bool {

        if canon == candidate { return true }

        switch role {

        case .carbSource:
            return canon == .grain && candidate == .grain

        case .proteinSource:
            return Set([canon, candidate]).isSubset(of: [.legume, .meatFishEgg, .dairy])

        case .fatSource:
            return Set([canon, candidate]).isSubset(of: [.nutSeed, .dairy])

        case .vegetableFiber:
            return canon == .vegetable && candidate == .vegetable

        case .fruitSugar:
            // 과일 ↔ 과일주스만 허용
            return Set([canon, candidate]).isSubset(of: [.fruit, .beverage])

        case .beverage:
            return canon == .beverage && candidate == .beverage

        case .seasoning:
            return canon == .seasoning && candidate == .seasoning

        case .additive:
            return canon == .additive && candidate == .additive

        default:
            return false
        }
    }