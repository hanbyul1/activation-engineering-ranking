private func sanitizeExtractedParts(_ parts: [Part]) -> [Part] {
    return sanitizeExtractedPartsCore(parts)
}

    
    private func sanitizeExtractedPartsCore(_ parts: [Part]) -> [Part] {
        parts.filter { part in
            let number = part.partNumber.rawValue.uppercased()
            let desc = part.description.uppercased()
            let price = NSDecimalNumber(decimal: part.billedPrice.amount).doubleValue

            // reject zero/invalid price rows
            // allow zero price ONLY for OEM part lists

            let isOEMList =
                number.range(of: #"^\d{7,8}[A-Z]{2}$"#, options: .regularExpression) != nil

            if price <= 0 && !isOEMList {
                return false
            }

            // reject claim/workfile/non-part IDs
            if number.contains("D01") { return false }
            if number.hasPrefix("E") { return false }
            if number.contains("CLAIM") { return false }
            if number.contains("WORKFILE") { return false }

            // allow normal numeric GM/CCC part numbers
            let isNumericPart =
                number.range(of: #"^\d{7,10}$"#, options: .regularExpression) != nil

            let isGMPart =
                number.range(of: #"^GM\d{6,10}$"#, options: .regularExpression) != nil

            let isFordStylePart =
                number.range(
                    of: #"^[A-Z0-9]*\*[A-Z0-9]+(?:\*[A-Z0-9]+)+$"#,
                    options: .regularExpression
                ) != nil

            // ✅ FIX: allow OEM part lists (e.g., 68534963AB)
            if !isNumericPart && !isGMPart && !isFordStylePart && !isOEMList {
                return false
            }

            // reject non-part descriptions
            if desc.contains("CLAIM") { return false }
            if desc.contains("WORKFILE") { return false }
            if desc.contains("ESTIMATE SHARE") { return false }
            if desc.contains("PAYMENT ISSUED") { return false }
            if desc.contains("SUBTOTAL") { return false }
            if desc.contains("TOTAL") { return false }
            if desc.contains("DEDUCTIBLE") { return false }

            return true
        }
    }