    
    private func isStreetAddressLine(_ text: String) -> Bool {
        let t = text.uppercased()

        if isDate(t) { return false }
        if isAmount(t) { return false }

        if t.contains("AMOUNT") || t.contains("DATE") || t.contains("DUE") { return false }
        if t.contains("ACCOUNT") || t.contains("SECTION") || t.contains("CYCLE") { return false }
        if t.contains("READ") || t.contains("CODE") { return false }
        if t.contains("CURRENT RESIDENT") { return false }
        if t.contains("PRESORTED") || t.contains("POSTAGE") || t.contains("PERMIT") { return false }

        let startsWithNumber = t.range(of: #"^\d+\s+"#, options: .regularExpression) != nil

        let hasStreetWord = t.range(
            of: #"\b(RDG|RIDGE|RD|ROAD|DR|DRIVE|ST|STREET|AVE|AVENUE|BLVD|LANE|LN|CT|COURT|WAY)\b"#,
            options: .regularExpression
        ) != nil

        return startsWithNumber && hasStreetWord
    }