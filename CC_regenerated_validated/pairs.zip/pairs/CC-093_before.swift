    
    private func splitCombinedDishes(_ dishes: [(title: String, body: String)])
    -> [(title: String, body: String)]
    {
        var out: [(String, String)] = []
        let soupKeywords = Set(["soup", "bisque", "chowder", "stew", "curry", "broth"])
        
        for (rawTitle, rawBody) in dishes {
            
            let partsFromComma = rawTitle.components(separatedBy: ",")
            let allParts = partsFromComma.flatMap { $0.components(separatedBy: " and ") }
            
            for p in allParts {
                let clean = p.trimmingCharacters(in: .whitespaces)
                if clean.isEmpty { continue }
                
                let words = clean.split(separator: " ").map(String.init)
                var last = 0
                var found = false
                
                for (i, w) in words.enumerated() {
                    if soupKeywords.contains(w.lowercased()) {
                        let sub = words[last...i].joined(separator: " ")
                        out.append((sub, (i == words.count - 1) ? rawBody : ""))
                        last = i + 1
                        found = true
                    }
                }
                
                if !found || last < words.count {
                    let sub = words[last...].joined(separator: " ")
                    if !sub.isEmpty { out.append((sub, rawBody)) }
                }
            }
        }
        
        return out.isEmpty ? dishes : out
    }