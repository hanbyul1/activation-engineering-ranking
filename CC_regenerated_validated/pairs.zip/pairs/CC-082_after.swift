func extractDueDate(_ rows: [OCRRow]) -> String? {
    return extractDueDateCore(rows)
}

    
    func extractDueDateCore(_ rows: [OCRRow]) -> String? {
        for row in rows {
            let upper = row.fullText.uppercased()

            // 1) water bill: AFTER 11/18/2025 PAY THIS
            if upper.contains("AFTER") {
                let dates = row.items
                    .map { $0.text.trimmingCharacters(in: .whitespacesAndNewlines) }
                    .filter { isDate($0) }

                if let first = dates.first {
                    return normalizeDate(first)
                }
            }

            // 2) DTE / autopay / withdrawal 계열
            if upper.contains("WITHDRAW") {
                // 먼저 row 안에서 이미 정상 date token이 있으면 그걸 우선
                let directDates = row.items
                    .map { $0.text.trimmingCharacters(in: .whitespacesAndNewlines) }
                    .filter { isDate($0) }

                if let first = directDates.first {
                    return normalizeDate(first)
                }

                // OCR이 month/day/year를 찢어놓은 경우 복원
                let tokens = row.items
                    .map { $0.text.trimmingCharacters(in: .whitespacesAndNewlines) }
                    .filter { !$0.isEmpty }

                if let reconstructed = reconstructBrokenMonthDate(from: tokens) {
                    return reconstructed
                }
            }

            // 3) 일반 due date/pay by
            if upper.contains("DUE DATE") || upper.contains("PAY BY") || upper.contains("PAYMENT DUE") {
                let dates = row.items
                    .map { $0.text.trimmingCharacters(in: .whitespacesAndNewlines) }
                    .filter { isDate($0) }

                if let first = dates.first {
                    return normalizeDate(first)
                }
            }
        }

        return nil
    }