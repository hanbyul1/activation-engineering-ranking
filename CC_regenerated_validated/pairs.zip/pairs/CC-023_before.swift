
    static func cropSupplementFactsRegion(from image: UIImage) async throws -> UIImage {

        guard let cgImage = image.cgImage else {
            throw NSError(domain: "OCRRegionExtractor", code: 1)
        }

        let width = CGFloat(cgImage.width)
        let height = CGFloat(cgImage.height)

        // 1) Detect text boxes
        let textReq = VNRecognizeTextRequest()
        textReq.recognitionLevel = .accurate
        textReq.usesLanguageCorrection = true

        let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])
        try handler.perform([textReq])

        let observations = textReq.results ?? []

        // Debug: dump recognized lines + Y
        debugPrintRecognizedLines(observations, imgH: height)

        // Find header ("Supplement Facts")
        var headerRectPx: CGRect?

        for obs in observations {
            guard let s = obs.topCandidates(1).first?.string else { continue }
            let lower = s.lowercased()

            if lower.contains("supplement facts") {
                headerRectPx = pxRect(from: obs.boundingBox, imgW: width, imgH: height)
                break
            }
        }

        // 2) Detect horizontal lines (optional fallback + logging)
        let lines = try detectHorizontalLines(cgImage: cgImage)
        print("Detected horizontal lines at Y:", lines.map { $0.midY }.sorted())

        // 3) Decide crop rect
        // If no header found, do not crop (fallback)
        guard let headerRectPx else {
            print("⚠️ OCRRegionExtractor: header not found, returning original image")
            return image
        }

        // We want to crop BELOW the header text.
        // Add a little padding so we don't cut off first row.
        let topPadding: CGFloat = 10
        var cropTopY = headerRectPx.maxY + topPadding

        // Bottom selection priority:
        //   (1) "Other ingredient(s)" text if detected
        //   (2) last horizontal line below header (thick bottom border typically)
        //   (3) lowest detected text box
        // 1) Find "Other ingredient(s)" ONLY if it's below header
        var bottomRectPx: CGRect?

        for obs in observations {
            guard let s = obs.topCandidates(1).first?.string else { continue }
            let lower = s.lowercased()

            if lower.contains("other ingredient") {
                let rect = pxRect(from: obs.boundingBox, imgW: width, imgH: height)

                // ✅ only accept if it's BELOW the header (in px coordinates)
                if rect.minY > headerRectPx.maxY {
                    bottomRectPx = rect
                    break
                }
            }
        }

        let lowestTextRectPx: CGRect? = observations
            .map { pxRect(from: $0.boundingBox, imgW: width, imgH: height) }
            .max(by: { $0.maxY < $1.maxY }) // 가장 아래(큰 maxY)

        // fallback bottomY
        let bottomPadding: CGFloat = 10
        var cropBottomY: CGFloat?

        if let bottomRectPx {
            // stop ABOVE "Other ingredient(s)" line
            cropBottomY = bottomRectPx.minY - bottomPadding
        } else if !lines.isEmpty,
                  let lastLine = lines
                    .filter({ $0.midY > cropTopY })
                    .max(by: { $0.midY < $1.midY }) {

            cropBottomY = lastLine.midY - bottomPadding

        } else if let lowestTextRectPx {
            cropBottomY = lowestTextRectPx.maxY + bottomPadding
        }

        guard let cropBottomY, cropBottomY > cropTopY else {
            print("⚠️ OCRRegionExtractor: invalid crop range, returning original image")
            return image
        }

        // Clamp to image bounds
        cropTopY = max(0, min(height - 1, cropTopY))
        let clampedBottom = max(0, min(height, cropBottomY))
        let cropH = clampedBottom - cropTopY
        guard cropH > 20 else {
            print("⚠️ OCRRegionExtractor: crop height too small, returning original image")
            return image
        }

        let cropRect = CGRect(x: 0, y: cropTopY, width: width, height: cropH)
        print("✅ OCRRegionExtractor cropRect(px):", cropRect)

        guard let croppedCG = cgImage.cropping(to: cropRect) else {
            print("⚠️ OCRRegionExtractor: cropping failed, returning original image")
            return image
        }

        return UIImage(cgImage: croppedCG)
    }