static func filterGarbageOCR(_ raws: [String]) -> [String] {
    return filterGarbageOCRCore(raws)
}


    static func filterGarbageOCRCore(_ raws: [String]) -> [String] {

        let debug = true

        func drop(_ reason: String, _ raw: String) {
            if debug {
                print("🧹 FILTER DROP:", reason, "|", raw)
            }
        }

        func keep(_ raw: String) {
            if debug {
                print("✅ FILTER KEEP:", raw)
            }
        }

        let bannedExact: Set<String> = [
            "supplement facts",
            "amount",
            "per serving",
            "value",
            "% daily",
            "daily value",
            "serving",
            "servings per container",
            "other ingredients",
            "ingredients",
            "amount per % daily",
            "amount per",
            "daily value not established",
            "proprietary blend",
            "*",
            "for",
            "item",
            "item #",
            "ns1",
            "nsi"
        ]

        let bannedContains: [String] = [
            "other ingredient",
            "derived from",
            "manufactured",
            "distributed",
            "customer service",
            "made in",
            "tested",
            "facility",
            "gmp",
            "capsule",
            "serving size",
            "per container",
            "www",
            "http",
            ".com",
            "usa",
            "value not"
        ]

        let stopwords: Set<String> = [
            "for", "and", "or", "of", "the", "with", "from"
        ]

        var result: [String] = []

        for raw in raws {

            let trimmed = raw.trimmingCharacters(in: .whitespacesAndNewlines)
            let s = trimmed.lowercased()

            print("\n🔍 FILTER CHECK:", trimmed)

            // 🚫 너무 짧음
            if s.count < 4 {
                drop("tooShort", trimmed)
                continue
            }

            // 🚫 순수 기호
            if s.range(of: #"^[^a-zA-Z0-9]+$"#,
                       options: .regularExpression) != nil {
                drop("pureSymbol", trimmed)
                continue
            }

            // 🚫 숫자만
            if s.range(of: #"^\d+(\.\d+)?$"#,
                       options: .regularExpression) != nil {
                drop("numberOnly", trimmed)
                continue
            }

            // 🚫 숫자+단위
            if s.range(of: #"^\d+(\.\d+)?\s*(mg|g|mcg|µg|iu|%)$"#,
                       options: [.regularExpression, .caseInsensitive]) != nil {
                drop("numberWithUnit", trimmed)
                continue
            }

            // 🚫 exact 금지어
            if bannedExact.contains(s) {
                drop("bannedExact", trimmed)
                continue
            }

            // 🚫 stopword 단독
            if stopwords.contains(s) {
                drop("stopwordOnly", trimmed)
                continue
            }

            // 🚫 contains 기반 금지어
            if let bad = bannedContains.first(where: { s.contains($0) }) {
                drop("bannedContains(\(bad))", trimmed)
                continue
            }

            // 🚫 괄호 시작
            if s.hasPrefix("(") {
                drop("startsWithParen", trimmed)
                continue
            }

            if s.contains("derived from") {
                drop("containsDerivedFrom", trimmed)
                continue
            }

            keep(trimmed)
            result.append(trimmed)
        }

        return result
    }