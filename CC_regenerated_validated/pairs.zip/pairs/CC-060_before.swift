    private func inferTags(from text: String) -> [String] {

        let lower = text.lowercased()
        var tags: [String] = []

        if lower.contains("power") { tags.append("power_loss") }
        if lower.contains("idle") { tags.append("idle") }
        if lower.contains("stall") { tags.append("stall") }
        if lower.contains("start") { tags.append("start") }
        if lower.contains("fuel") { tags.append("fuel") }
        if lower.contains("shake") || lower.contains("misfire") { tags.append("misfire") }
        if lower.contains("air") { tags.append("air") }
        if lower.contains("sensor") { tags.append("sensor") }
        if lower.contains("accelerat") { tags.append("acceleration") }
        if lower.contains("hot") { tags.append("hot") }
        if lower.contains("cold") { tags.append("cold") }

        return tags
    }