    private static func primaryIcon(for n: String) -> String? {

        // 🥩 Protein
        if n.contains("beef") || n.contains("steak") { return "🥩" }
        if n.contains("pork") || n.contains("bacon") || n.contains("ham") { return "🍖" }
        if n.contains("chicken") || n.contains("wing") || n.contains("drum") { return "🍗" }
        if n.contains("egg") { return "🥚" }
        if n.contains("tofu") { return "🧈" }

        // 🐟 Seafood
        if n.contains("salmon") || n.contains("fish") { return "🐟" }
        if n.contains("shrimp") || n.contains("prawn") { return "🍤" }
        if n.contains("crab") { return "🦀" }
        if n.contains("squid") || n.contains("calamari") { return "🦑" }

        // 🍞 Staples
        if n.contains("bread") || n.contains("bun") { return "🍞" }
        if n.contains("rice") { return "🍚" }
        if n.contains("pasta") || n.contains("noodle") { return "🍝" }

        // 🥬 Veg / Fruit
        if n.contains("salad") { return "🥗" }
        if n.contains("apple") || n.contains("fruit") { return "🍎" }
        if n.contains("vegetable") || n.contains("broccoli") { return "🥦" }

        // 🍰 Dessert
        if n.contains("cake") { return "🍰" }
        if n.contains("cookie") { return "🍪" }
        if n.contains("ice cream") { return "🍨" }

        // 🥤 Drink
        if n.contains("water") { return "💧" }
        if n.contains("milk") { return "🥛" }
        if n.contains("coffee") { return "☕️" }
        if n.contains("juice") { return "🧃" }
        if n.contains("soda") || n.contains("cola") { return "🥤" }

        return nil
    }