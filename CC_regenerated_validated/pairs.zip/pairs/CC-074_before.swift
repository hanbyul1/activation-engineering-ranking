    
    func fetchPairReactions(
        drugA: String,
        drugB: String,
        mode: EvidenceMode
    ) async throws -> [ReactionEvidence] {
        
        if let path = Bundle.main.path(forResource: "faers_summary", ofType: "sqlite") {
            print("🔥 APP USING DB PATH:", path)
        }
        
        guard let summary = db.getSummaryDB() else {
            throw NSError(domain: "DBNotAvailable", code: 0)
        }
        
        // ✅ Normalize inputs to match DB convention (UPPER/TRIM)
        let a = drugA.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        let b = drugB.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        
        // ✅ Raw mode shows more rows and orders by case_count (more intuitive)
        let limit = (mode == .raw) ? 500 : 100
        
        let query: String
        
        if mode == .raw {
            
            query = """
            SELECT
                f.reaction_name,
                f.report_year,
                c.pair_case_count,
                f.case_count,
                f.death_count,
                NULL AS odds_ratio,
                NULL AS prr,
                NULL AS chi_square,
                NULL AS expected_a,
                'NONE' AS signal_level,
                '' AS signal_reason
            FROM drug_pair_reaction_fact f
            LEFT JOIN drug_pair_case_summary c
              ON f.drug_a = c.drug_a
             AND f.drug_b = c.drug_b
             AND f.report_year = c.report_year
            WHERE
              (UPPER(TRIM(f.drug_a)) = ? AND UPPER(TRIM(f.drug_b)) = ?)
              OR
              (UPPER(TRIM(f.drug_a)) = ? AND UPPER(TRIM(f.drug_b)) = ?)
            ORDER BY f.case_count DESC
            LIMIT \(limit)
            """
            
        } else if mode == .consumerSafe {

            query = """
            SELECT
                'SUMMARY' AS reaction_name,
                c.report_year,
                c.pair_case_count,
                c.pair_case_count AS case_count,
                c.death_cases AS death_count,
                NULL AS odds_ratio,
                NULL AS prr,
                NULL AS chi_square,
                NULL AS expected_a,
                'NONE' AS signal_level,
                'Pair-level summary (unique case reports)' AS signal_reason
            FROM drug_pair_case_summary c
            WHERE
              (UPPER(TRIM(c.drug_a)) = ? AND UPPER(TRIM(c.drug_b)) = ?)
              OR
              (UPPER(TRIM(c.drug_a)) = ? AND UPPER(TRIM(c.drug_b)) = ?)
            ORDER BY c.pair_case_count DESC
            LIMIT \(limit)
            """
            
        } else {
            
            // Future extension fallback (currently unused)
            query = """
            SELECT
                f.reaction_name,
                f.report_year,
                c.pair_case_count,
                f.case_count,
                f.death_count,
                s.odds_ratio,
                s.prr,
                s.chi_square,
                s.expected_a,
                COALESCE(s.signal_level, 'NONE') AS signal_level,
                COALESCE(s.signal_reason, '') AS signal_reason
            FROM drug_pair_reaction_fact f
            LEFT JOIN drug_pair_reaction_stats s
              ON f.drug_a = s.drug_a
             AND f.drug_b = s.drug_b
             AND f.reaction_name = s.reaction_name
             AND f.report_year = s.report_year
            LEFT JOIN drug_pair_case_summary c
              ON f.drug_a = c.drug_a
             AND f.drug_b = c.drug_b
             AND f.report_year = c.report_year
            WHERE
              (
                (UPPER(TRIM(f.drug_a)) = ? AND UPPER(TRIM(f.drug_b)) = ?)
                OR
                (UPPER(TRIM(f.drug_a)) = ? AND UPPER(TRIM(f.drug_b)) = ?)
              )
            ORDER BY s.odds_ratio DESC
            LIMIT \(limit)
            """
        }
        
        var stmt: OpaquePointer?
        guard sqlite3_prepare_v2(summary, query, -1, &stmt, nil) == SQLITE_OK else {
            print("❌ Failed to prepare FAERS query:", String(cString: sqlite3_errmsg(summary)))
            return []
        }
        defer { sqlite3_finalize(stmt) }
        
        // ✅ bind (A,B) and (B,A)
        sqlite3_bind_text(stmt, 1, a, -1, SQLITE_TRANSIENT)
        sqlite3_bind_text(stmt, 2, b, -1, SQLITE_TRANSIENT)
        sqlite3_bind_text(stmt, 3, b, -1, SQLITE_TRANSIENT)
        sqlite3_bind_text(stmt, 4, a, -1, SQLITE_TRANSIENT)
        
        var results: [ReactionEvidence] = []
        
        while sqlite3_step(stmt) == SQLITE_ROW {
            
            guard
                let cReaction = sqlite3_column_text(stmt, 0),
                let cSignal = sqlite3_column_text(stmt, 9)
            else { continue }
            
            let reaction = String(cString: cReaction)
            let year = Int(sqlite3_column_int(stmt, 1))
            let totalPairCases = Int(sqlite3_column_int(stmt, 2))
            let caseCount = Int(sqlite3_column_int(stmt, 3))
            let deathCount = Int(sqlite3_column_int(stmt, 4))
            
            let oddsRatio = sqlite3_column_double(stmt, 5)
            let prr = sqlite3_column_double(stmt, 6)
            let chiSquare = sqlite3_column_double(stmt, 7)
            let expectedA = sqlite3_column_double(stmt, 8)
            
            let signal = SignalLevel(rawValue: String(cString: cSignal)) ?? .none
            
            let reason: String = {
                if let cReason = sqlite3_column_text(stmt, 10) {
                    return String(cString: cReason)
                }
                return ""
            }()
            
            // ConsumerSafe filtering block removed: consumerSafe mode now returns only summary rows.
            
            results.append(
                ReactionEvidence(
                    reaction: reaction,
                    year: year,
                    totalPairCases: totalPairCases,
                    caseCount: caseCount,
                    deathCount: deathCount,
                    oddsRatio: oddsRatio,
                    prr: prr,
                    ror: oddsRatio,
                    chiSquare: chiSquare,
                    expectedA: expectedA,
                    signalLevel: signal,
                    signalReason: reason
                )
            )
        }
        
        return results
    }