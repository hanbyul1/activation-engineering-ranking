    
    private func scoreMapItem(
        _ item: MKMapItem,
        shopName: String,
        targetLocation: CLLocation?
    ) -> Double {

        var score = 0.0

        let resultName = normalizeShopName(item.name ?? "")
        let queryTokens = Set(shopName.split(separator: " ").map(String.init))
        let resultTokens = Set(resultName.split(separator: " ").map(String.init))

        let overlap = queryTokens.intersection(resultTokens).count
        score += Double(overlap) * 10.0

        if resultName == shopName {
            score += 30
        } else if resultName.contains(shopName) || shopName.contains(resultName) {
            score += 15
        }

        // 🔥 FIXED
        if let targetLocation {
            let distance = item.location.distance(from: targetLocation)

            if distance < 500 {
                score += 25
            } else if distance < 2000 {
                score += 15
            } else if distance < 8000 {
                score += 5
            } else {
                score -= 10
            }
        }

        return score
    }