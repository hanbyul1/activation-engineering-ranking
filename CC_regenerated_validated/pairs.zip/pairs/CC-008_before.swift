    
    private func extractVerticalColumns(_ tokens: [OCRToken]) -> [Part] {
        
        let partTokens = tokens.filter {
            $0.text.range(of: #"^(GM)?\d{7,10}$"#, options: .regularExpression) != nil
            || isLoosePartNumber($0.text)
        }
        
        // 🔥 IMPROVED: detect correct price column (avoid bottom summary numbers)
        let allPriceCandidates = tokens.filter {
            let cleaned = $0.text.replacingOccurrences(of: ",", with: "")
            return cleaned.range(of: #"^\d+\.\d{2}$"#, options: .regularExpression) != nil
        }
        
        // cluster by X (simple binning)
        let sortedByX = allPriceCandidates.sorted { $0.boundingBox.midX < $1.boundingBox.midX }
        
        var columns: [[OCRToken]] = []
        let xThreshold: CGFloat = 0.05
        
        for token in sortedByX {
            if let idx = columns.firstIndex(where: {
                abs($0[0].boundingBox.midX - token.boundingBox.midX) < xThreshold
            }) {
                columns[idx].append(token)
            } else {
                columns.append([token])
            }
        }
        
        // 🔥 choose the RIGHTMOST dense column (actual part prices)
        let priceColumn = columns.max(by: { $0.count < $1.count }) ?? []
        
        let priceTokens = priceColumn
        
        // 🔥 IMPROVED: detect description column by spatial proximity, not just text filtering
        let partXs = partTokens.map { $0.boundingBox.midX }
        let avgPartX = partXs.reduce(0, +) / CGFloat(max(partXs.count, 1))
        
        let descriptionTokens = tokens.filter { token in
            let text = token.text.uppercased()
            
            // must be alphabetic (allow patterns like (S)GASKET)
            let isWordLike =
            text.range(of: #"^[A-Z\(\)\/\s]+$"#, options: .regularExpression) != nil
            
            // exclude obvious noise
            let isNoise =
            text.contains("PART") ||
            text.contains("PRICE") ||
            text.contains("NUMBER") ||
            text.contains("DESCRIPTION") ||
            text.contains("MISC") ||
            text.contains("SHOP") ||
            text.contains("FEE") ||
            text.contains("LABOR") ||
            text.contains("TOTAL") ||
            text.contains("SUBTOTAL") ||
            text.contains("CHEVROLET") ||
            text.contains("ROGER") ||
            text.contains("DEAN") ||
            text.contains("ESTIMATE") ||
            text == "AND" ||
            text == "LINE"
            
            // 🔥 KEY: must be near the description column (right of part column, not far right like prices)
            let dx = token.boundingBox.midX - avgPartX
            
            return isWordLike &&
            !isNoise &&
            dx > 0.03 && dx < 0.35
        }
        
        // Detect quantity behavior
        let globalQty: Int? = {
            // find explicit QTY label
            if let qtyLabel = tokens.first(where: { $0.text.uppercased() == "QTY" }) {
                let labelY = qtyLabel.boundingBox.midY
                
                if let nearestQty = tokens
                    .filter({ Int($0.text) != nil })
                    .min(by: {
                        abs($0.boundingBox.midY - labelY) < abs($1.boundingBox.midY - labelY)
                    }),
                   let q = Int(nearestQty.text), q > 0, q < 100 {
                    return q
                }
            }
            return nil
        }()
        
        guard !partTokens.isEmpty else { return [] }
        
        // Sort parts top → bottom (anchor)
        let partsSorted = partTokens.sorted { $0.boundingBox.midY > $1.boundingBox.midY }
        
        var results: [Part] = []
        
        for part in partsSorted {
            
            let partY = part.boundingBox.midY
            
            // 🔥 IMPROVED: match description by BOTH vertical AND horizontal proximity
            let description = descriptionTokens.min(by: {
                let dy0 = abs($0.boundingBox.midY - partY)
                let dy1 = abs($1.boundingBox.midY - partY)
                
                let dx0 = abs($0.boundingBox.midX - part.boundingBox.midX)
                let dx1 = abs($1.boundingBox.midX - part.boundingBox.midX)
                
                // prioritize vertical alignment first, then horizontal closeness
                return (dy0, dx0) < (dy1, dx1)
            })?.text ?? "No description"
            
            // Find nearest price vertically (within 0.08)
            let priceToken = priceTokens
                .filter { abs($0.boundingBox.midY - partY) < 0.08 }
                .min(by: {
                    abs($0.boundingBox.midY - partY) < abs($1.boundingBox.midY - partY)
                })
            
            guard let priceToken else { continue }
            
            let priceText = priceToken.text.replacingOccurrences(of: ",", with: "")
            guard let price = Decimal(string: priceText) else { continue }
            
            // Correct quantity logic:
            // If only one qty value exists but multiple parts → distribute as 1 each
            let quantity: Int = {
                if let gq = globalQty {
                    if partsSorted.count > 1 {
                        return 1   // shared qty → each part is 1
                    } else {
                        return gq
                    }
                }
                return 1
            }()
            
            results.append(
                Part(
                    partNumber: PartNumber(part.text),
                    description: description,
                    quantity: quantity,
                    billedPrice: Money(amount: price)
                )
            )
        }
        
        return results
    }