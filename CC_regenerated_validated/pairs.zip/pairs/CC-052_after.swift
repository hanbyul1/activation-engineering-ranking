private func extractNarrativeParts(_ tokens: [OCRToken]) -> [Part] {
    return extractNarrativePartsCore(tokens)
}

    
    private func extractNarrativePartsCore(_ tokens: [OCRToken]) -> [Part] {
        // Sort tokens top → bottom, then left → right
        let sorted = tokens.sorted {
            if abs($0.boundingBox.midY - $1.boundingBox.midY) > 0.02 {
                return $0.boundingBox.midY > $1.boundingBox.midY
            }
            return $0.boundingBox.minX < $1.boundingBox.minX
        }
        
        var parts: [Part] = []
        
        for i in 0..<sorted.count {
            let text = sorted[i].text
            
            // STRICT part number detection: must be 7–8 digits (avoid technician IDs like 500165)
            guard text.range(of: #"^\d{7,10}$"#, options: .regularExpression) != nil else { continue }
            
            let partNumber = text
            
            // 🔥 Only consider rows inside "Parts" section (prevents picking technician IDs)
            let nearbyContext = sorted[max(0, i-10)..<min(sorted.count, i+10)]
                .map { $0.text.uppercased() }
                .joined(separator: " ")
            
            if !nearbyContext.contains("PARTS") {
                continue
            }
            
            // Look ahead for pattern: DESCRIPTION + PRICE
            var descriptionParts: [String] = []
            var price: Decimal?
            
            var j = i + 1
            while j < min(i + 10, sorted.count) {
                
                let next = sorted[j].text
                
                let cleaned = next.replacingOccurrences(of: "$", with: "")
                    .replacingOccurrences(of: ",", with: "")
                
                // detect price
                if cleaned.range(of: #"^\d+\.\d{2}$"#, options: .regularExpression) != nil,
                   let value = Decimal(string: cleaned) {
                    price = value
                    break
                }
                
                // skip noise tokens
                if next == "-" || next == "PARTS" { j += 1; continue }
                
                // avoid picking numeric garbage
                if Int(next) == nil {
                    descriptionParts.append(next)
                }
                
                j += 1
            }
            
            guard let finalPrice = price else { continue }
            
            let description = descriptionParts
                .joined(separator: " ")
                .trimmingCharacters(in: .whitespaces)
            
            // 🔥 Avoid duplicates (same part number + same price)
            if parts.contains(where: {
                $0.partNumber == PartNumber(partNumber) && $0.billedPrice.amount == finalPrice
            }) {
                continue
            }
            
            parts.append(
                Part(
                    partNumber: PartNumber(partNumber),
                    description: description.isEmpty ? "No description" : description,
                    quantity: 1,
                    billedPrice: Money(amount: finalPrice)
                )
            )
        }
        
        return parts
    }