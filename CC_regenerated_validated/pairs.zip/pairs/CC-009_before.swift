    
    func isLikelyCompanyName(_ text: String) -> Bool {

        let t = text.trimmingCharacters(in: .whitespacesAndNewlines)
        let upper = t.uppercased()

        if t.isEmpty { return false }

        // 문장/약관/설명 제거
        if upper.contains("WARRANTY") { return false }
        if upper.contains("NOT RESPONSIBLE") { return false }
        if upper.contains("AGREES") { return false }
        if upper.contains("FOREIGN MATERIAL") { return false }
        if upper.contains("PAYMENT TERMS") { return false }
        if upper.contains("DUE UPON RECEIPT") { return false }
        if upper.contains("SERVICES PERFORMED") { return false }
        if upper.contains("TERMS & CONDITIONS") { return false }
        if upper.contains("CUSTOMER ACKNOWLEDGEMENT") { return false }

        // 이메일/웹/주소/전화 제거
        if t.contains("@") { return false }
        if upper.contains("HTTP") || upper.contains("WWW.") { return false }
        if t.range(of: #"^\d+\s+"#, options: .regularExpression) != nil { return false }
        if firstMatch(t, pattern: #"\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}"#) != nil { return false }

        // 너무 긴 문장 제거
        if t.count > 60 { return false }
        if t.split(separator: " ").count > 6 { return false }

        // 너무 짧은 조각 제거
        if t.count < 4 { return false }

        // 🔥 문장 구조 제거 (핵심)
        if t.contains(" to ") { return false }
        if t.contains(" and ") { return false }
        if t.contains(" from ") { return false }

        // 🔥 동사 포함 문장 제거
        if t.range(of: #"\b(clear|checked|replaced|performed|verified|sending|includes)\b"#,
                   options: [.regularExpression, .caseInsensitive]) != nil {
            return false
        }
        
        // 회사명 신호
        if upper.contains("LLC") || upper.contains("INC") { return true }
        if upper.contains("PLUMBING") || upper.contains("APPLIANCE") ||
           upper.contains("HEATING") || upper.contains("COOLING") ||
           upper.contains("MECHANICAL") {
            return true
        }
        
        // 🔥 generic fallback (추가)
        if text.range(of: #"^[A-Z][A-Za-z&.\s]{3,}$"#, options: .regularExpression) != nil {
            return true
        }

        // 🔥 일반 회사 키워드 확장
        if upper.contains("CO.") ||
           upper.contains("COMPANY") ||
           upper.contains("SERVICES") ||
           upper.contains("TRIM") {
            return true
        }

        return false
    }