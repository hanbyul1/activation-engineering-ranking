static func fix(
        fields: [String: String],
        rows: [String]
    ) -> [String: String] {
    return fixCore(fields, rows)
}


    static func fixCore(
        fields: [String: String],
        rows: [String]
    ) -> [String: String] {

        var result = fields

        print("\n💧 WATER FIXER START")

        // =========================
        // 1. SERVICE PERIOD
        // =========================
        if result["service_period"] == nil {

            for row in rows {

                if row.contains("/") {

                    let matches = row.matches(for: #"\d{2}/\d{2}/\d{2,4}"#)

                    if matches.count >= 2 {
                        result["service_period"] =
                            "\(matches[0][0]) - \(matches[1][0])"

                        print("💧 SERVICE PERIOD FIXED:", result["service_period"]!)
                        break
                    }
                }
            }
        }

        // =========================
        // 2. AMOUNT DUE
        // =========================
        if result["amount_due"] == nil {

            for row in rows {

                let upper = row.uppercased()

                // 🔥 핵심: "DUE $xxx"
                if upper.contains("DUE") {

                    if let match = row.range(
                        of: #"\d{1,6}\.\d{2}"#,
                        options: .regularExpression
                    ) {

                        result["amount_due"] = String(row[match])

                        print("💧 AMOUNT FIXED:", result["amount_due"]!)
                        break
                    }
                }
            }
        }

        // =========================
        // 3. USAGE 보강
        // =========================
        if result["usage"] == nil {

            for row in rows {

                if row.contains("100 CU FT") || row.contains("CU FT") {

                    let nums = row.matches(for: #"\b\d+\b"#)

                    if let last = nums.last?.first {
                        result["usage"] = last
                        print("💧 USAGE FIXED:", last)
                        break
                    }
                }
            }
        }

        print("💧 WATER FIXER END\n")

        return result
    }