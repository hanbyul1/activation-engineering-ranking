    func setPDF(_ url: URL) {
        Task {
            print("🔥 setPDF CALLED:", url)

            let accessGranted = url.startAccessingSecurityScopedResource()
            defer { if accessGranted { url.stopAccessingSecurityScopedResource() } }

            guard accessGranted else {
                errorMessage = "Permission denied"
                return
            }

            // =========================
            // 🔥 STEP 0: TRY TEXT-BASED EXTRACTION FIRST
            // =========================
            let rawText = extractTextFromPDF(url)

            if !rawText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {

                print("✅ USING PDF TEXT EXTRACTION")

                let vehicle = extractVehicle(from: rawText)
                var parts = extractCCCPartsFromText(rawText)

                if parts.count < 3 {
                    print("⚠️ TEXT EXTRACTION INSUFFICIENT → USING COLUMN MODE")

                    let images = renderPDFToImages(url)
                    var allTokens: [OCRToken] = []

                    for image in images {
                        let ocr = try await ocrService.extractTextWithTokens(from: image)
                        allTokens.append(contentsOf: ocr.tokens)
                    }

                    parts = fallbackColumnPairing(from: allTokens)
                }

                print("🔥 TEXT PARTS:", parts.count)

                if !parts.isEmpty {
                    errorMessage = nil
                    await enrichAndBuildReport(parts: parts, vehicle: vehicle)
                    return
                }

                print("⚠️ TEXT EXTRACTION FAILED → FALLBACK TO OCR")
            }

            // =========================
            // 🔥 STEP 1: OCR FALLBACK (YOUR ORIGINAL LOGIC)
            // =========================
            let images = renderPDFToImages(url)

            if images.isEmpty {
                errorMessage = "Failed to render PDF"
                return
            }

            var allParts: [Part] = []
            var detectedVehicle: Vehicle? = nil

            for image in images {
                do {
                    let ocr = try await ocrService.extractTextWithTokens(from: image)

                    if detectedVehicle == nil {
                        detectedVehicle = extractVehicle(from: ocr.fullText)
                    }

                    print("PDF TOKENS:", ocr.tokens.count)

                    var parts = partExtractor.extractParts(from: ocr.tokens)

                    // =========================
                    // 🔥 FALLBACK CHAIN (PDF)
                    // =========================
                    if parts.isEmpty {
                        print("⚠️ PDF FALLBACK → ROW GROUPING")
                        let rows = groupTokensIntoRows(ocr.tokens)
                        parts = extractPartsFromRows(rows)
                    }

                    if parts.isEmpty {
                        print("⚠️ PDF FALLBACK → SEQUENTIAL")
                        parts = fallbackSequentialExtraction(from: ocr.tokens)
                    }

                    if parts.isEmpty {
                        print("⚠️ PDF FALLBACK → LOOSE REGEX")
                        parts = fallbackLooseExtraction(from: ocr.tokens)
                    }

                    if parts.isEmpty {
                        print("⚠️ PDF FALLBACK → FORD OLD-STYLE PARTS")
                        parts = fallbackFordOldStyleParts(from: ocr.tokens)
                    }

                    if parts.isEmpty {

                        print("⚠️ FALLBACK → PART LIST (NO PRICE)")

                        parts = fallbackPartListWithoutPrice(from: ocr.tokens)

                    }
                    
                    if parts.isEmpty {
                        parts = fallbackColumnPairing(from: ocr.tokens)
                    }
                    
                    print("🔥 PAGE PARTS:", parts.count)

                    allParts.append(contentsOf: parts)

                } catch {
                    print("❌ OCR failed on page:", error)
                }
            }

            print("🔥 TOTAL PARTS:", allParts.count)

            // =========================
            // 🔥 FINAL
            // =========================
            let filteredParts = sanitizeExtractedParts(allParts)

            let uniqueParts = Dictionary(grouping: filteredParts, by: { $0.partNumber.rawValue })
                .compactMap { _, group in
                    group.max(by: {
                        $0.billedPrice.amount < $1.billedPrice.amount
                    })
                }

            print("🔥 UNIQUE PARTS:", uniqueParts.count)

            errorMessage = uniqueParts.isEmpty ? "No parts detected in PDF" : nil

            await enrichAndBuildReport(parts: uniqueParts, vehicle: detectedVehicle)
        }
    }