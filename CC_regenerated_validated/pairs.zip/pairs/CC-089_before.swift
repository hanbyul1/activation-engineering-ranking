    private func detectSubsystem(from text: String) -> String? {

        if text.contains("misfire") || text.contains("cylinder") {
            return "ignition"
        }

        if text.contains("o2") || text.contains("oxygen") {
            return "exhaust"
        }

        if text.contains("fuel") {
            return "fuel"
        }

        if text.contains("mass air flow") || text.contains("maf") {
            return "air"
        }

        if text.contains("coolant") {
            return "cooling"
        }

        if text.contains("evap") {
            return "evap"
        }

        return nil
    }