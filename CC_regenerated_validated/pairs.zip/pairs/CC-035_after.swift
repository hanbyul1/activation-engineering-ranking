private func findAccountCandidates(_ rows: [OCRRow]) -> [(value: String, row: Int)] {
    return findAccountCandidatesCore(rows)
}

    
    private func findAccountCandidatesCore(_ rows: [OCRRow]) -> [(value: String, row: Int)] {

        var results: [(String, Int)] = []

        for (i, row) in rows.enumerated() {

            let text = row.fullText.replacingOccurrences(of: ",", with: "")
            let upper = row.fullText.uppercased()

            // ✅ hyphen account: account-like row에서만 허용
            if isLikelyAccountRow(row) {
                let hyphenMatches = text.matches(
                    for: #"\b[A-Z0-9]{2,6}-\d{4,8}-\d{3,6}(?:-\d{1,4})?\b|\b\d{4,8}\s*-\s*\d{3,6}\b"#
                )

                for m in hyphenMatches {
                    if let v = m.first {
                        results.append((v.replacingOccurrences(of: " ", with: ""), i))
                    }
                }
            }

            // ✅ long digit account: account-like row에서만 허용
            if isLikelyAccountRow(row) {
                let digitMatches = text.matches(for: #"\b\d{8,16}\b"#)
                    .filter { candidate in
                        guard let v = candidate.first else { return false }

                        let unique = Set(v)
                        if unique.count <= 2 { return false }

                        return true
                    }

                for m in digitMatches {
                    if let v = m.first {
                        results.append((v, i))
                    }
                }
            }

            // ✅ water bill 특수 fallback:
            // "ACCOUNT ... CUSTOMER ..." 헤더 바로 아래 row의 long digit
            if upper.contains("ACCOUNT") && upper.contains("CUSTOMER") && i + 1 < rows.count {
                let nextText = rows[i + 1].fullText.replacingOccurrences(of: ",", with: "")
                let nextDigits = nextText.matches(for: #"\b\d{8,16}\b"#)

                for m in nextDigits {
                    if let v = m.first {
                        results.append((v, i + 1))
                    }
                }
            }
        }

        return results
    }