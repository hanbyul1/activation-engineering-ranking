    
    func fetchCoOccurrence(
        meshTerm: String,
        treeLevel: Int,
        treeFilterEnabled: Bool
    ) async throws -> CoOccurrenceResponse {
        
        print("🚀 fetchCoOccurrence called with:", meshTerm)
        
        guard let pubmed = db.getPubmedDB(),
              let mesh = db.getMeshDB() else {
            throw NSError(domain: "DBNotAvailable", code: 0)
        }
        
        let limit = 20                    // UI 기준 limit
        let rawLimit = limit * 4          // 서버와 동일 전략
        
        let effectiveTreeFilter = treeFilterEnabled
        var basePrefixes: [String] = []
        
        // -----------------------------------------
        // STEP 1: Detect Descriptor vs SCR + Tree prefixes
        // -----------------------------------------
        // ✅ Resolve to MeSH descriptor name before querying pubmed.sqlite
        let resolved = resolveMeshDescriptorName(meshTerm, meshDB: mesh)
        
        // ✅ Minimal debug: mapping + pubmed presence check
        if resolved.caseInsensitiveCompare(meshTerm) != .orderedSame {
            print("🧭 MeSH mapping:", meshTerm, "→", resolved)
        } else {
            print("🧭 MeSH mapping: no change for", meshTerm)
        }
        
        if treeFilterEnabled {
            
            let query = """
            SELECT tree_numbers, type
            FROM mesh_term
            WHERE name = ? COLLATE NOCASE
            """
            
            var stmt: OpaquePointer?
            
            guard sqlite3_prepare_v2(mesh, query, -1, &stmt, nil) == SQLITE_OK else {
                print("❌ Failed to prepare MeSH query")
                return CoOccurrenceResponse(
                    ingredient: meshTerm,
                    treeLevel: treeLevel,
                    treePrefixes: [],
                    coOccurring: []
                )
            }
            
            sqlite3_bind_text(stmt, 1, meshTerm, -1, SQLITE_TRANSIENT)
            
            if sqlite3_step(stmt) == SQLITE_ROW {
                
                let typeCString = sqlite3_column_text(stmt, 1)
                let type = typeCString != nil ? String(cString: typeCString!) : ""
                
                if type.lowercased() == "scr" {
                    // 서버 동작과 동일하게 → tree filter 유지하지만 결과 없음
                    sqlite3_finalize(stmt)
                    return CoOccurrenceResponse(
                        ingredient: meshTerm,
                        treeLevel: treeLevel,
                        treePrefixes: [],
                        coOccurring: []
                    )
                }
                
                if let cString = sqlite3_column_text(stmt, 0) {
                    
                    let jsonString = String(cString: cString)
                    
                    if let data = jsonString.data(using: .utf8),
                       let treeNumbers = try? JSONDecoder().decode([String].self, from: data),
                       !treeNumbers.isEmpty {
                        
                        for tn in treeNumbers {
                            let parts = tn.split(separator: ".")
                            if parts.count >= treeLevel {
                                let prefix = parts.prefix(treeLevel).joined(separator: ".") + "."
                                basePrefixes.append(prefix)
                            }
                        }
                    }
                }
            }
            
            sqlite3_finalize(stmt)
            
            // 🔥 서버와 동일: prefix 없으면 빈 결과
            if basePrefixes.isEmpty {
                return CoOccurrenceResponse(
                    ingredient: meshTerm,
                    treeLevel: treeLevel,
                    treePrefixes: [],
                    coOccurring: []
                )
            }
        }
        
        // -----------------------------------------
        // STEP 2: Raw co-occurrence query
        // -----------------------------------------
        
        // 🔎 PubMed 존재 확인
        let existsInPubmed = pubmedHasMeshTerm(resolved, pubmedDB: pubmed)
        print("📚 PubMed contains [\(resolved)] =", existsInPubmed)
        
        print("✅ pubmed term exists? [\(resolved)] =", pubmedHasMeshTerm(resolved, pubmedDB: pubmed))
        
        let coQuery = """
        SELECT m2.mesh_term, COUNT(DISTINCT m1.pmid) AS count
        FROM article_mesh m1
        JOIN article_mesh m2 ON m1.pmid = m2.pmid
        WHERE m1.mesh_term = ?
          AND m2.mesh_term != ?
        GROUP BY m2.mesh_term
        ORDER BY count DESC
        LIMIT ?
        """
        
        var stmt: OpaquePointer?
        sqlite3_prepare_v2(pubmed, coQuery, -1, &stmt, nil)
        
        sqlite3_bind_text(stmt, 1, resolved, -1, SQLITE_TRANSIENT)
        sqlite3_bind_text(stmt, 2, resolved, -1, SQLITE_TRANSIENT)
        sqlite3_bind_int(stmt, 3, Int32(rawLimit))
        
        var results: [CoOccurrenceItem] = []
        
        while sqlite3_step(stmt) == SQLITE_ROW {
            
            guard let cMesh = sqlite3_column_text(stmt, 0) else { continue }
            
            let coMesh = String(cString: cMesh)
            let count = Int(sqlite3_column_int(stmt, 1))
            
            // Tree filter OFF → 그대로 통과
            if !effectiveTreeFilter {
                results.append(CoOccurrenceItem(mesh: coMesh, count: count))
                if results.count >= limit { break }
                continue
            }
            
            // -----------------------------------------
            // Tree filter ON
            // -----------------------------------------
            
            let treeQuery = """
            SELECT tree_numbers
            FROM mesh_term
            WHERE name = ? COLLATE NOCASE
            """
            
            var meshStmt: OpaquePointer?
            sqlite3_prepare_v2(mesh, treeQuery, -1, &meshStmt, nil)
            sqlite3_bind_text(meshStmt, 1, coMesh, -1, SQLITE_TRANSIENT)
            
            var shouldInclude = false
            
            if sqlite3_step(meshStmt) == SQLITE_ROW,
               let cString = sqlite3_column_text(meshStmt, 0) {
                
                let jsonString = String(cString: cString)
                
                if let data = jsonString.data(using: .utf8),
                   let treeNumbers = try? JSONDecoder().decode([String].self, from: data) {
                    
                    for tn in treeNumbers {
                        if basePrefixes.contains(where: { tn.hasPrefix($0) }) {
                            shouldInclude = true
                            break
                        }
                    }
                }
            }
            
            sqlite3_finalize(meshStmt)
            
            if shouldInclude {
                results.append(CoOccurrenceItem(mesh: coMesh, count: count))
            }
            
            if results.count >= limit { break }
        }
        
        sqlite3_finalize(stmt)
        
        return CoOccurrenceResponse(
            ingredient: meshTerm,
            treeLevel: effectiveTreeFilter ? treeLevel : nil,
            treePrefixes: basePrefixes,
            coOccurring: results
        )
    }