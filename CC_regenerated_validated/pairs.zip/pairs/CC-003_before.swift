    private func buildParts(
        systems: [String],
        components: [String],
        description: String,
        subsystem: String?
    ) -> [String] {

        var parts: [String] = []
        var primaryParts: [String] = []

        let lower = normalize(description)

        // 👇 ADD HERE
        print("🔍 LOWER TEXT:", lower)
        let isLeanCondition = lower.contains("lean")

        // -------------------------
        // HARD DOMAIN RULES
        // -------------------------
        if lower.contains("mass air flow") || lower.contains("maf") {

            print("✅ MAF RULE TRIGGERED")

            primaryParts.append("mass air flow sensor")

            if lower.contains("circuit")
                || lower.contains("malfunction")
                || lower.contains("range")
                || lower.contains("performance") {

                parts.append(contentsOf: ["wiring harness", "connector"])
            }
        }
        
        // IAT SENSOR (🔥 CRITICAL MISSING RULE)
        if lower.contains("intake air temperature") || lower.contains("iat") {

            primaryParts.append("intake air temperature sensor")

            // signal issues → electrical support parts
            if lower.contains("high")
                || lower.contains("low")
                || lower.contains("circuit")
                || lower.contains("malfunction") {

                parts.append(contentsOf: [
                    "wiring harness",
                    "connector"
                ])
            }
        }

        if lower.contains("misfire") || lower.contains("cylinder") {
            primaryParts.append(contentsOf: ["ignition coil", "spark plug"])
            parts.append(contentsOf: ["fuel injector", "ignition module"])
        }

        if lower.contains("o2") || lower.contains("oxygen") {
            primaryParts.append("oxygen sensor")

            if lower.contains("circuit") || lower.contains("malfunction") {
                parts.append(contentsOf: ["wiring harness", "connector"])
            }
        }

        if lower.contains("regulator") {
            primaryParts.append("fuel pressure regulator")
        }

        if isLeanCondition {
            primaryParts.append(contentsOf: [
                "mass air flow sensor",
                "oxygen sensor"
            ])

            parts.append(contentsOf: [
                "vacuum leak",
                "intake manifold",
                "fuel injector",
                "fuel pump"
            ])
        }

        // -------------------------
        // SYSTEM + COMPONENT
        // -------------------------
        for system in systems {
            for component in components {
                parts.append(format(system: system, component: component))
            }
        }

        for system in systems {
            if system.contains("fuel") { parts.append("fuel pressure sensor") }
            if system.contains("air")  { parts.append("mass air flow sensor") }
        }

        parts.append(contentsOf: components)

        // -------------------------
        // DOMAIN BOOSTS
        // -------------------------
        if lower.contains("fuel") && !lower.contains("regulator") {
            parts.append(contentsOf: [
                "fuel pressure regulator",
                "fuel rail",
                "fuel pressure sensor",
                "fuel pump"
            ])
        }

        if lower.contains("fuel") && lower.contains("regulator") {
            parts.append("fuel pressure sensor")
        }

        if lower.contains("pressure") && lower.contains("low") {
            parts.append(contentsOf: [
                "fuel pump",
                "fuel filter",
                "fuel pressure sensor"
            ])
        }

        if lower.contains("circuit") || lower.contains("open") {
            parts.append(contentsOf: ["wiring harness", "connector"])
        }

        if parts.isEmpty && primaryParts.isEmpty {
            parts.append("control module")
        }

        // -------------------------
        // MERGE + CANONICALIZE
        // -------------------------
        let combined = primaryParts + parts

        var canonical = combined.map { part -> String in
            let norm = normalizeComponent(part).lowercased()

            if norm.contains("o2") || norm.contains("oxygen") {
                return "oxygen sensor"
            }

            return norm
        }

        // 🔥 remove generic junk early
        if isLeanCondition {
            canonical.removeAll { $0 == "engine sensor" }
        }

        let primarySet = Set(primaryParts.map {
            normalizeComponent($0).lowercased()
        })

        // -------------------------
        // CLEAN
        // -------------------------
        let hasSpecificSensor = canonical.contains {
            $0.contains("sensor") && $0 != "sensor"
        }

        canonical = canonical.filter { part in
            if primarySet.contains(part) { return true }
            if part.contains("wiring") || part.contains("connector") { return true }

            if hasSpecificSensor && part == "sensor" { return false }

            if part == "air sensor" { return false }
            if part == "air valve" { return false }
            if part == "ignition sensor" { return false }
            if part == "fuel valve" { return false }
            if part == "fuel sensor" { return false }
            if part == "engine sensor" { return false }

            return true
        }

        // -------------------------
        // PRUNE EDGE CASES
        // -------------------------
        if lower.contains("regulator") && lower.contains("circuit") {
            canonical.removeAll { $0 == "fuel rail" }
        }

        // -------------------------
        // FAULT TYPE
        // -------------------------
        let isElectricalFault =
            lower.contains("circuit") ||
            lower.contains("open") ||
            lower.contains("malfunction")

        // -------------------------
        // FILTER BY SUBSYSTEM
        // -------------------------
        var filtered = canonical.filter { part in
            guard let subsystem else { return true }

            if isLeanCondition {
                return true
            }

            if isElectricalFault {
                if part.contains("wiring") || part.contains("connector") {
                    return true
                }
            }

            return matchesSubsystem(part, subsystem)
        }

        // -------------------------
        // GUARANTEE ELECTRICAL PARTS
        // -------------------------
        if isElectricalFault {
            if !filtered.contains("wiring harness") {
                filtered.append("wiring harness")
            }
            if !filtered.contains("connector") {
                filtered.append("connector")
            }
        }

        // -------------------------
        // FINAL CLEAN
        // -------------------------
        filtered = filtered.map {
            ($0.contains("o2") || $0.contains("oxygen")) ? "oxygen sensor" : $0
        }

        filtered.removeAll { $0 == "engine sensor" }

        // -------------------------
        // PRIORITY ORDERING
        // -------------------------
        let priorityOrder = [
            "mass air flow sensor",
            "vacuum leak",
            "intake manifold",
            "oxygen sensor",
            "fuel injector",
            "fuel pump",
            "fuel pressure regulator",
            "wiring harness",
            "connector"
        ]

        var ordered: [String] = []

        for p in filtered {
            if primarySet.contains(p) && !ordered.contains(p) {
                ordered.append(p)
            }
        }

        let secondary = filtered.filter { !primarySet.contains($0) }

        let sortedSecondary = secondary.sorted { a, b in
            let ia = priorityOrder.firstIndex(of: a) ?? Int.max
            let ib = priorityOrder.firstIndex(of: b) ?? Int.max
            return ia < ib
        }

        ordered.append(contentsOf: sortedSecondary)

        // -------------------------
        // FINAL OUTPUT
        // -------------------------
        var seen = Set<String>()

        return ordered
            .filter {
                if seen.contains($0) { return false }
                seen.insert($0)
                return true
            }
            .map { $0.capitalized }
    }