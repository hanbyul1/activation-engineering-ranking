private func extractColumnBased(_ tokens: [OCRToken]) -> [Part] {
    return extractColumnBasedCore(tokens)
}

    
    private func extractColumnBasedCore(_ tokens: [OCRToken]) -> [Part] {
        
        let rows = groupTokensIntoRows(tokens)
        guard !rows.isEmpty else { return [] }
        
        // 1) Find header row
        guard let headerRowIndex = rows.firstIndex(where: { row in
            let rowText = row.map { $0.text.uppercased() }.joined(separator: " ")
            return rowText.contains("PART") &&
            rowText.contains("NUMBER") &&
            rowText.contains("PRICE")
        }) else {
            return []
        }
        
        let headerRow = rows[headerRowIndex]
        
        // 2) Detect column anchors from header row
        let qtyX = xPosition(ofFirstMatching: ["QTY"], in: headerRow)
        let partNumberX = xPosition(ofFirstMatching: ["NUMBER"], in: headerRow)
        let descriptionX = xPosition(ofFirstMatching: ["DESCRIPTION"], in: headerRow)
        
        let priceTokens = headerRow.filter { $0.text.uppercased() == "PRICE" }
            .sorted { $0.boundingBox.midX < $1.boundingBox.midX }
        
        guard let partNumberX,
              let descriptionX,
              priceTokens.count >= 1 else {
            return []
        }
        
        let partPriceX = priceTokens[0].boundingBox.midX
        let extPriceX = priceTokens.count >= 2 ? priceTokens[1].boundingBox.midX : nil
        
        // 3) Parse only rows below header row until misc/subtotal area
        var parts: [Part] = []
        
        for row in rows[(headerRowIndex + 1)...] {
            
            let rowText = row.map { $0.text.uppercased() }.joined(separator: " ")
            
            if rowText.contains("MISC CODE") ||
                rowText.contains("MISC DESCRIPTION") ||
                rowText.contains("SUBTOTAL") ||
                rowText.contains("LABOR") ||
                rowText.contains("TAX") ||
                rowText.contains("TOTAL") {
                break
            }
            
            guard let partNumber = nearestTokenText(to: partNumberX, in: row, maxDistance: 0.10, pattern: #"^(GM)?\d{7,10}$"#) else {
                continue
            }
            
            let quantity: Int = {
                guard let qtyX else { return 1 }
                if let qtyText = nearestTokenText(to: qtyX, in: row, maxDistance: 0.08),
                   let qty = Int(qtyText),
                   qty > 0, qty < 100 {
                    return qty
                }
                return 1
            }()
            
            let description = collectDescription(
                near: descriptionX,
                in: row,
                stopBeforeX: partPriceX
            )
            
            let billedPrice =
            nearestPrice(to: partPriceX, in: row, maxDistance: 0.10)
            ?? extractFallbackPrice(in: row)
            
            guard let billedPrice else { continue }
            
            // ignore rows where part price and ext price exist but this row is obviously misc/fee
            if let extPriceX,
               let extPrice = nearestPrice(to: extPriceX, in: row, maxDistance: 0.10),
               description.uppercased().contains("SUPPLIES") || description.uppercased().contains("FEE") {
                _ = extPrice
                continue
            }
            
            parts.append(
                Part(
                    partNumber: PartNumber(partNumber),
                    description: description.isEmpty ? "No description" : description,
                    quantity: quantity,
                    billedPrice: Money(amount: billedPrice)
                )
            )
        }
        
        return parts
    }