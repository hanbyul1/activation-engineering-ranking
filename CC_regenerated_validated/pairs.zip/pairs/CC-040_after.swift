func shareItems() -> [Any] {
    return shareItemsCore()
}

    
    func shareItemsCore() -> [Any] {

        var items: [Any] = []

        let core = doc.coreData

        // 🔥 formatter 가져오기 (핵심)
        let formatter = UtilityContentView(doc: doc)

        let account = core?.accountNumber ?? "—"
        let period = core?.servicePeriod ?? "—"

        // 🔥 UI와 동일한 포맷 사용
        let amount = formatter.format(core?.amountDue)
        let usage = formatter.formatUsage(core?.usage, unit: core?.usageUnit)

        let due = core?.dueDate ?? "—"
        let address = core?.address ?? "Not detected"

        let text = """
        📄 Utility Bill

        🔢 Account Number: \(account)
        📅 Service Period: \(period)
        ⚡ Usage: \(usage)
        💵 Amount Due: \(amount)
        ⏰ Due Date: \(due)
        📍 Service Address: \(address)

        ——————————————
        DocuSense
        """

        items.append(text)


        return items
    }