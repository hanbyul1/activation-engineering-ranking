public func extractTextWithTokens(from image: UIImage) async throws -> OCRText {
    return extractTextWithTokensCore(image)
}

    public func extractTextWithTokensCore(from image: UIImage) async throws -> OCRText {

        guard let cgImage = image.cgImage else {
            throw NSError(domain: "VisionOCRService", code: 1, userInfo: nil)
        }

        return try await withCheckedThrowingContinuation { continuation in

            let request = VNRecognizeTextRequest { request, error in

                if let error = error {
                    continuation.resume(throwing: error)
                    return
                }

                guard let observations = request.results as? [VNRecognizedTextObservation] else {
                    continuation.resume(returning: OCRText(fullText: "", tokens: []))
                    return
                }

                var lines: [String] = []
                var tokens: [OCRToken] = []

                for observation in observations {

                    guard let candidate = observation.topCandidates(1).first else { continue }

                    let lineText = candidate.string
                    lines.append(lineText)

                    // 🔥 Extract word-level tokens with bounding boxes
                    let words = lineText.split(separator: " ").map(String.init)

                    for word in words {

                        guard let range = lineText.range(of: word) else { continue }

                        if let box = try? candidate.boundingBox(for: range) {
                            let rect = box.boundingBox

                            tokens.append(
                                OCRToken(
                                    text: word,
                                    boundingBox: rect
                                )
                            )
                        }
                    }
                }

                let fullText = lines.joined(separator: "\n")
                continuation.resume(returning: OCRText(fullText: fullText, tokens: tokens))
            }

            request.recognitionLevel = .accurate
            request.usesLanguageCorrection = false

            let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])

            do {
                try handler.perform([request])
            } catch {
                continuation.resume(throwing: error)
            }
        }
    }