private func extractInlinePatternPartsSafely(_ tokens: [OCRToken]) -> [Part] {
    return extractInlinePatternPartsSafelyCore(tokens)
}

    
    private func extractInlinePatternPartsSafelyCore(_ tokens: [OCRToken]) -> [Part] {
        
        let fullText = tokens.map { $0.text }.joined(separator: " ")
        
        // STRICT pattern: must include hyphen-separated structure AND $ price
        let pattern = #"\d{7,10}\s*-\s*[A-Z0-9\s\/]+\s*-\s*\$\d+\.\d{2}"#
        
        guard fullText.range(of: pattern, options: .regularExpression) != nil else {
            return []
        }
        
        // Now run precise extraction
        let extractPattern = #"(\d{7,10})\s*-\s*([A-Z0-9\s\/]+?)\s*-\s*\$?(\d+\.\d{2})"#
        
        guard let regex = try? NSRegularExpression(pattern: extractPattern) else {
            return []
        }
        
        let matches = regex.matches(in: fullText, range: NSRange(fullText.startIndex..., in: fullText))
        
        var parts: [Part] = []
        
        for match in matches {
            guard match.numberOfRanges == 4,
                  let pRange = Range(match.range(at: 1), in: fullText),
                  let dRange = Range(match.range(at: 2), in: fullText),
                  let prRange = Range(match.range(at: 3), in: fullText) else { continue }
            
            let partNumber = String(fullText[pRange])
            let rawDescription = String(fullText[dRange]).trimmingCharacters(in: .whitespaces)
            let priceStr = String(fullText[prRange])
            
            guard let price = Decimal(string: priceStr) else { continue }
            
            // 🔥 NEW: extract quantity from description patterns like "TIRE 3"
            var quantity = 1
            let qtyPattern = #"\b(\d+)\b"#
            if let regex = try? NSRegularExpression(pattern: qtyPattern),
               let match = regex.firstMatch(in: rawDescription, range: NSRange(rawDescription.startIndex..., in: rawDescription)),
               let range = Range(match.range(at: 1), in: rawDescription),
               let extractedQty = Int(rawDescription[range]) {
                // only accept reasonable quantities
                if extractedQty > 1 && extractedQty < 20 {
                    quantity = extractedQty
                }
            }
            
            // 🔥 clean description (remove trailing quantity like "TIRE 3" → "TIRE")
            let cleanedDescription = rawDescription.replacingOccurrences(
                of: #"\s*\d+\b"#,
                with: "",
                options: .regularExpression
            ).trimmingCharacters(in: .whitespaces)
            
            parts.append(
                Part(
                    partNumber: PartNumber(partNumber),
                    description: cleanedDescription.isEmpty ? rawDescription : cleanedDescription,
                    quantity: quantity,
                    billedPrice: Money(amount: price)
                )
            )
        }
        
        return parts
    }