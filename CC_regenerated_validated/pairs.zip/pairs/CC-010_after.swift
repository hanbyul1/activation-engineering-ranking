private func refineRoleWithMacros(
        currentRole: IngredientRole,
        currentBio: BioGroup,
        macros: MacroProfile,
        evidence: inout [String]
    ) -> (role: IngredientRole, bio: BioGroup) {
    return refineRoleWithMacrosCore(currentRole, currentBio, macros, evidence)
}


    private func refineRoleWithMacrosCore(
        currentRole: IngredientRole,
        currentBio: BioGroup,
        macros: MacroProfile,
        evidence: inout [String]
    ) -> (role: IngredientRole, bio: BioGroup) {

        // If we have macros, we can detect macro-dominance.
        let carbs = macros.carbs ?? 0
        let protein = macros.protein ?? 0
        let fat = macros.fat ?? 0
        let sugar = macros.sugar ?? 0
        let fiber = macros.fiber ?? 0

        // Avoid correcting for seasoning/additive (macros often missing or 0)
        if currentBio == .seasoning || currentBio == .additive { return (currentRole, currentBio) }

        // Heuristic dominance
        // (tweak these thresholds as you test)
        if protein >= 10 && protein > carbs && protein > fat {
            evidence.append("macro:protein-dominant")
            // beans / meat-like
            if currentBio == .unknown { return (.proteinSource, .legume) } // safe default
            return (.proteinSource, currentBio == .grain ? .legume : currentBio)
        }

        if fat >= 10 && fat > carbs && fat > protein {
            evidence.append("macro:fat-dominant")
            return (.fatSource, currentBio == .unknown ? .nutSeed : currentBio)
        }

        // fruit-like: sugar high, fiber not too high
        if sugar >= 8 && sugar > protein && currentBio != .sweetener {
            evidence.append("macro:sugar-high")
            return (.fruitSugar, currentBio == .unknown ? .fruit : currentBio)
        }

        // veggie/fiber-like: fiber notable, low calories
        if fiber >= 3 && sugar < 6 && carbs < 15 {
            evidence.append("macro:fiber-lean")
            return (.vegetableFiber, currentBio == .unknown ? .vegetable : currentBio)
        }

        // carb source: carbs high
        if carbs >= 15 && carbs > protein && carbs > fat {
            evidence.append("macro:carb-dominant")
            return (.carbSource, currentBio == .unknown ? .grain : currentBio)
        }

        return (currentRole, currentBio)
    }