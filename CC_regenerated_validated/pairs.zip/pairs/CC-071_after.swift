private func handleFeatureAction(_ action: ActionType) {
    handleFeatureActionCore(action)
}

    
    private func handleFeatureActionCore(_ action: ActionType) {
        switch action {

        // =====================
        // 🏠 Home Feature Buttons
        // =====================
        case .menuScan:
            AnalyticsEventStore.shared.log(.openMenuScan)
            showingTextScanner = true

        case .foodPhoto:
            print("📸 FoodPhoto button tapped")
            // ✅ 홈에 남아 있는 사진 상태 완전 초기화
            foodPhoto = nil
            menuPresentation = .none
            lastSavedFoodPhotoLocalIdentifierWrapper = nil

            AnalyticsEventStore.shared.log(.openFoodPhoto)
            showingFoodPhotoLibrary = true

        case .barcode:
            AnalyticsEventStore.shared.log(.openBarcodeScanner)
            showingBarcodeScanner = true

        case .preferences:
            AnalyticsEventStore.shared.log(.openPreferences)
            showingPreferences = true

        case .findNearby:
            AnalyticsEventStore.shared.log(.openNearbyRestaurants)
            guard settings.isLocationDetectionEnabled else {
                showLocationOffAlert = true
                return
            }
            showNearbyPicker = true

        case .recipes:
            AnalyticsEventStore.shared.log(.openRecipes)
            showingRecipeSheet = true

        case .history:
            AnalyticsEventStore.shared.log(.openHistory)
            showingHistorySheet = true

        case .storyGame:
            AnalyticsEventStore.shared.log(.openGameMenu)
            showingGameMenu = true

        case .receiptScan:
            AnalyticsEventStore.shared.log(.openReceiptScan)
            showingReceiptScan = true
            
        // =====================
        // 🚫 RecipeHub 전용 Action (여기선 무시)
        // =====================
        case .recipeDishType,
             .recipeIngredient,
             .recipeCuisine,
             .recipeCookingMethod,
             .recipeDiet,
             .recipeNutrition,
             .recipeOccasion,
             .recipePopular,
             .recipeMyRecipe:
            return
            
        // =====================
        // 🚫 Preferences / Other Screens 전용 Action
        // =====================
        case .prefHealthInsights,
             .prefScan,
             .prefFavorites,
             .prefPhotoMap,
             .prefMyKitchen,
             .prefCalCoin,
             .prefAnalytics:
            return
        }
    }