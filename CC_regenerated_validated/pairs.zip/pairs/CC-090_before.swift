    
    private func mapToCategory(_ feature: FeatureButtonModel) -> CategoryType? {
        switch feature.actionID {

        case .recipeDishType:
            return .dishType

        case .recipeIngredient:
            return .ingredient

        case .recipeCuisine:
            return .cuisine

        case .recipeCookingMethod:
            return .cookingMethod

        case .recipeDiet:
            return .diet

        case .recipeNutrition:
            return .nutrition

        case .recipeOccasion:
            return .occasion

        case .recipePopular:
            return .popular

        case .recipeMyRecipe:
            return .myRecipe

        default:
            return nil
        }
    }