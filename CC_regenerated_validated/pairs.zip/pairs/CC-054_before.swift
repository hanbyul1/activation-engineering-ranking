
    func normalize(
        fields: [String: String],
        rows: [OCRRow],
        patterns: [ExtractionUtilityPattern],
        billType: String
    ) -> UtilityCoreData {

        let account = fields["account_number"]
        let address = fields["address"]

        var amount = parseAmount(fields["amount_due"])

        // 🔥 MINIMAL FIX (기존 안 건드림)
        if amount == nil {

            print("⚠️ AMOUNT fallback triggered")

            let candidates = rows
                .compactMap { extractDollarAmount(from: $0.fullText) }

            if let best = candidates.max() {
                print("💰 FALLBACK AMOUNT:", best)
                amount = best
            }
        }

        let dueDate = fields["due_date"]

        let servicePeriod =
            fields["service_period"] ??
            extractServicePeriodFromRows(rows)

        let effectiveType = billType.lowercased()

        print("\n🧩 ===== NORMALIZER START =====")
        print("📌 incoming billType:", effectiveType)
        print("📌 raw usage field:", fields["usage"] ?? "nil")

        let usage: Double?
        let unit: String?

        switch effectiveType {

        case "water":

            // 🔥 [ADD - NON-DESTRUCTIVE GUARD]
            if let raw = fields["usage"],
               let parsed = parseUsage(raw),
               parsed > 100 {   // gallons 보호

                print("🛑 WATER: preserving OCR usage:", parsed)
                usage = parsed
                unit = "GAL"
            } else {
                let result = extractWaterUsageWithUnit(rows)
                usage = result.0
                unit = result.1
                print("💧 FINAL WATER:", usage as Any, unit as Any)
            }

        case "gas":
            let result = extractGasUsageWithUnit(rows, fields: fields, patterns: patterns)
            usage = result.0
            unit = result.1
            print("🔥 FINAL GAS:", usage as Any, unit as Any)

        case "electricity":

            let raw = parseUsage(fields["usage"])

            let corrected = correctElectricUsage(
                rawUsage: raw,
                rows: rows
            )

            if let corrected {
                usage = corrected
                unit = "kWh"
                print("⚡️ FINAL ELECTRIC (CORRECTED):", corrected)

            } else {
                // ❌ 기존 fallback 제거
                print("❌ NO TRUSTED USAGE → returning nil")
                usage = nil
                unit = "kWh"
            }

        default:
            let parsedUsage = parseUsage(fields["usage"])
            let inferredUnit = inferUsageUnit(from: rows, patterns: patterns)

            if let parsedUsage, parsedUsage > 0 {
                usage = parsedUsage
                unit = inferredUnit
            } else {
                let fallback = extractGenericUsageWithUnit(rows: rows, patterns: patterns)
                usage = fallback.0
                unit = fallback.1
            }

            print("❓ FINAL GENERIC:", usage as Any, unit as Any)
        }

        print("🧩 ===== NORMALIZER END =====\n")

        return UtilityCoreData(
            type: effectiveType,              // 🔥 반드시 첫 번째
            servicePeriod: servicePeriod,
            amountDue: amount,
            address: address,
            accountNumber: account,
            dueDate: dueDate,
            usage: usage,
            usageUnit: unit
        )
    }