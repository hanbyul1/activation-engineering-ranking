    func scanIngredients(from image: UIImage) async throws -> [String] {
        
        print(">>> SCAN STARTED")
        let fixed = normalizedImage(image)
        guard let cgImage = fixed.cgImage else { return [] }

        var observations: [VNRecognizedTextObservation] = []

        let detectRequest = VNRecognizeTextRequest { req, _ in
            observations = req.results as? [VNRecognizedTextObservation] ?? []
        }

        detectRequest.recognitionLevel = .accurate
        detectRequest.usesLanguageCorrection = true
        detectRequest.recognitionLanguages = ["en-US"]
        detectRequest.minimumTextHeight = 0.002

        let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])
        try handler.perform([detectRequest])

        // 1. Supplement Facts 및 Other Ingredients의 y좌표 찾기
        // 1️⃣ Find Supplement Facts header Y
        guard let headerObs = observations.first(where: {
            let t = $0.topCandidates(1).first?.string.lowercased() ?? ""
            return t.contains("supplement") && t.contains("fact")
        }) else {
            // If header not found, return everything
            return processFinalIngredients(
                from: observations.compactMap { $0.topCandidates(1).first?.string }
            )
        }

        let headerY = headerObs.boundingBox.minY

        // 2️⃣ Find first "Other Ingredients" BELOW header (optional stop)
        let stopObs = observations.first(where: {
            let t = $0.topCandidates(1).first?.string.lowercased() ?? ""
            return (t.contains("other ingredient"))
                && $0.boundingBox.minY < headerY
        })

        let stopY = stopObs?.boundingBox.minY ?? 0.0

        // 3️⃣ Extract everything BELOW header and ABOVE stop line
        let filteredTexts = observations
            .filter { obs in
                let y = obs.boundingBox.minY
                return y < headerY && y > stopY
            }
            .compactMap { $0.topCandidates(1).first?.string }

        print("RAW OCR LINES 1:")
        for t in filteredTexts {
            print("•", t)
        }
        print(">>> RETURNING:", filteredTexts)
        return processFinalIngredients(from: filteredTexts)
    }