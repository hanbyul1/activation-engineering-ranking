private func fallbackFordOldStyleParts(from tokens: [OCRToken]) -> [Part] {
    return fallbackFordOldStylePartsCore(tokens)
}

    
    private func fallbackFordOldStylePartsCore(from tokens: [OCRToken]) -> [Part] {
        let words = tokens.map { $0.text }
        var results: [Part] = []

        func isFordStylePart(_ text: String) -> Bool {
            let upper = text.uppercased()

            return upper.range(
                of: #"^[A-Z0-9]*\*[A-Z0-9]+(?:\*[A-Z0-9]+)+$"#,
                options: .regularExpression
            ) != nil
        }

        func priceValue(_ text: String) -> Decimal? {
            let cleaned = text
                .replacingOccurrences(of: ",", with: "")
                .replacingOccurrences(of: ":", with: ".")
                .trimmingCharacters(in: .whitespacesAndNewlines)

            if cleaned.range(of: #"^\d+\.\d{2}$"#, options: .regularExpression) != nil {
                return Decimal(string: cleaned)
            }

            return nil
        }

        for i in 0..<words.count {
            let partNumber = words[i].uppercased()

            guard isFordStylePart(partNumber) else { continue }

            var descriptionWords: [String] = []
            var price: Decimal?

            for j in (i + 1)..<min(i + 8, words.count) {
                let word = words[j]
                let upper = word.uppercased()

                if let p = priceValue(word) {
                    price = p
                    break
                }

                if upper == "LIST" || upper == "NET" || upper == "TOTAL" {
                    break
                }

                if Int(word) != nil {
                    continue
                }

                descriptionWords.append(word)
            }

            guard let price, price > 0 else { continue }

            let description = descriptionWords
                .joined(separator: " ")
                .trimmingCharacters(in: .whitespacesAndNewlines)

            results.append(
                Part(
                    partNumber: PartNumber(partNumber),
                    description: description.isEmpty ? "Detected Part" : description,
                    quantity: 1,
                    billedPrice: Money(amount: price)
                )
            )
        }

        return results
    }