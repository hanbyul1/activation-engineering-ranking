    func extractParts(from tokens: [OCRToken]) -> [Part]
}

public struct RuleBasedPartExtractor: PartExtractor {
    public init() {}
    
    public func extractParts(from tokens: [OCRToken]) -> [Part] {
        // 🔥 SAFE pre-check: only trigger for hyphen-inline receipts like "12345678 - TEXT - $XXX.XX"
        let inlineParts = extractInlinePatternPartsSafely(tokens)
        if inlineParts.count >= 1 {
            print("USING SAFE INLINE PATTERN EXTRACTION")
            return inlineParts
        }
        // 1. Try structured row-based first
        let rowParts = extractRowBased(tokens)
        if rowParts.count >= 2 && rowParts.count >= extractEstimatedPartCount(tokens) {
            print("USING ROW-BASED EXTRACTION")
            return rowParts
        }
        
        // 2. Try column-based (header-aligned)
        let columnParts = extractColumnBased(tokens)
        if columnParts.count >= 2 {
            print("USING COLUMN-BASED EXTRACTION")
            return columnParts
        }
        
        // 3. NEW fallback: narrative parts extraction (for non-table receipts like tires)
        let narrativeParts = extractNarrativeParts(tokens)
        if narrativeParts.count >= 2 {
            print("USING NARRATIVE EXTRACTION")
            return narrativeParts
        }
        
        // 4. vertical
        let verticalParts = extractVerticalColumns(tokens)
        if !verticalParts.isEmpty {
            print("USING VERTICAL COLUMN PAIRING")
            return verticalParts
        }

        // 🔥 NEW: cross-row pairing
        let crossRowParts = extractCrossRowParts(tokens)
        if !crossRowParts.isEmpty {
            print("USING CROSS-ROW EXTRACTION")
            return crossRowParts
        }

        // 🔥 FINAL fallback
        print("⚠️ FINAL FALLBACK → LOOSE ROW")
        return extractLooseRowBased(tokens)
    }
    
    // MARK: - Row grouping
    
    private func groupTokensIntoRows(_ tokens: [OCRToken]) -> [[OCRToken]] {
        let threshold: CGFloat = 0.02
        var rows: [[OCRToken]] = []
        
        for token in tokens {
            if let index = rows.firstIndex(where: {
                abs($0[0].boundingBox.midY - token.boundingBox.midY) < threshold
            }) {
                rows[index].append(token)
            } else {
                rows.append([token])
            }
        }
        
        // sort left → right
        for i in 0..<rows.count {
            rows[i].sort { $0.boundingBox.minX < $1.boundingBox.minX }
        }
        
        return rows
    }
    
    // MARK: - Extraction helpers
    
    private func extractPartNumber(from texts: [String]) -> String? {
        return texts.first(where: {
            $0.range(of: #"^(GM)?\d{7,10}$"#, options: .regularExpression) != nil
        })
    }
    
    private func extractQuantity(from texts: [String], partIndex: Int) -> Int {
        // For table receipts, quantity is usually immediately left of part number.
        if partIndex > 0, let qty = Int(texts[partIndex - 1]), qty > 0, qty < 100 {
            return qty
        }
        
        // fallback
        return 1
    }
    
    private func extractPrice(from texts: [String]) -> Decimal? {
        for text in texts {
            let cleaned = text.replacingOccurrences(of: ",", with: "")
            if let value = Decimal(string: cleaned), cleaned.contains(".") {
                return value
            }
        }
        return nil
    }
    
    private func extractRowBased(_ tokens: [OCRToken]) -> [Part] {
        
        let rows = groupTokensIntoRows(tokens)
        var parts: [Part] = []
        
        for row in rows {
            let texts = row.map { $0.text }
            let rowText = texts.joined(separator: " ").uppercased()
            
            // 🔥 FILTER OUT NON-PART ROWS
            
            if rowText.contains("SUBTOTAL") ||
                rowText.contains("TOTAL") ||
                rowText.contains("TAX") ||
                rowText.contains("LABOR") ||
                rowText.contains("SUPPLIES") ||
                rowText.contains("FEE") ||
                rowText.contains("PART NUMBER") ||
                rowText.contains("PART PRICE") ||
                rowText.contains("EXT PRICE") ||
                rowText.contains("MISC") {
                continue
            }
            
            // 🔥 NEW: support "part # XXXXX" pattern (tire receipts, narrative style)
            var partNumber: String?
            
            if let strict = extractPartNumber(from: texts) {
                partNumber = strict
            } else if let loose = texts.first(where: { isLoosePartNumber($0) }) {
                partNumber = loose
            } else if let partHashIndex = texts.firstIndex(where: { $0 == "#" || $0.uppercased() == "#" }) {
                if partHashIndex + 1 < texts.count {
                    let candidate = texts[partHashIndex + 1]
                    if candidate.range(of: #"^\d{6,10}$"#, options: .regularExpression) != nil {
                        partNumber = candidate
                    }
                }
            } else if let partWordIndex = texts.firstIndex(where: { $0.uppercased().contains("PART") }),
                      partWordIndex + 2 < texts.count,
                      texts[partWordIndex + 1] == "#" {
                let candidate = texts[partWordIndex + 2]
                if candidate.range(of: #"^\d{6,10}$"#, options: .regularExpression) != nil {
                    partNumber = candidate
                }
            }
            
            guard let partNumber else { continue }
            
            guard let partIndex = texts.firstIndex(of: partNumber) ?? texts.firstIndex(where: { $0 == partNumber }) else { continue }
            
            let quantity = extractQuantity(from: texts, partIndex: partIndex)
            
            // 🔥 NEW: better price extraction for inline "$XXX.XX" formats
            let price = extractInlinePrice(texts: texts)
            ?? extractBestPrice(texts: texts, partIndex: partIndex)
            ?? extractNearestGlobalPrice(for: row, allTokens: tokens)
            
            guard let price else { continue }
            
            let description = extractFlexibleDescription(texts: texts, partIndex: partIndex)
            
            parts.append(
                Part(
                    partNumber: PartNumber(partNumber),
                    description: description,
                    quantity: quantity,
                    billedPrice: Money(amount: price)
                )
            )
        }
        
        return parts
    }
    
    private func extractColumnBased(_ tokens: [OCRToken]) -> [Part] {
        
        let rows = groupTokensIntoRows(tokens)
        guard !rows.isEmpty else { return [] }
        
        // 1) Find header row
        guard let headerRowIndex = rows.firstIndex(where: { row in
            let rowText = row.map { $0.text.uppercased() }.joined(separator: " ")
            return rowText.contains("PART") &&
            rowText.contains("NUMBER") &&
            rowText.contains("PRICE")
        }) else {
            return []
        }
        
        let headerRow = rows[headerRowIndex]
        
        // 2) Detect column anchors from header row
        let qtyX = xPosition(ofFirstMatching: ["QTY"], in: headerRow)
        let partNumberX = xPosition(ofFirstMatching: ["NUMBER"], in: headerRow)
        let descriptionX = xPosition(ofFirstMatching: ["DESCRIPTION"], in: headerRow)
        
        let priceTokens = headerRow.filter { $0.text.uppercased() == "PRICE" }
            .sorted { $0.boundingBox.midX < $1.boundingBox.midX }
        
        guard let partNumberX,
              let descriptionX,
              priceTokens.count >= 1 else {
            return []
        }
        
        let partPriceX = priceTokens[0].boundingBox.midX
        let extPriceX = priceTokens.count >= 2 ? priceTokens[1].boundingBox.midX : nil
        
        // 3) Parse only rows below header row until misc/subtotal area
        var parts: [Part] = []
        
        for row in rows[(headerRowIndex + 1)...] {
            
            let rowText = row.map { $0.text.uppercased() }.joined(separator: " ")
            
            if rowText.contains("MISC CODE") ||
                rowText.contains("MISC DESCRIPTION") ||
                rowText.contains("SUBTOTAL") ||
                rowText.contains("LABOR") ||
                rowText.contains("TAX") ||
                rowText.contains("TOTAL") {
                break
            }
            
            guard let partNumber = nearestTokenText(to: partNumberX, in: row, maxDistance: 0.10, pattern: #"^(GM)?\d{7,10}$"#) else {
                continue
            }
            
            let quantity: Int = {
                guard let qtyX else { return 1 }
                if let qtyText = nearestTokenText(to: qtyX, in: row, maxDistance: 0.08),
                   let qty = Int(qtyText),
                   qty > 0, qty < 100 {
                    return qty
                }
                return 1
            }()
            
            let description = collectDescription(
                near: descriptionX,
                in: row,
                stopBeforeX: partPriceX
            )
            
            let billedPrice =
            nearestPrice(to: partPriceX, in: row, maxDistance: 0.10)
            ?? extractFallbackPrice(in: row)
            
            guard let billedPrice else { continue }
            
            // ignore rows where part price and ext price exist but this row is obviously misc/fee
            if let extPriceX,
               let extPrice = nearestPrice(to: extPriceX, in: row, maxDistance: 0.10),
               description.uppercased().contains("SUPPLIES") || description.uppercased().contains("FEE") {
                _ = extPrice
                continue
            }
            
            parts.append(
                Part(
                    partNumber: PartNumber(partNumber),
                    description: description.isEmpty ? "No description" : description,
                    quantity: quantity,
                    billedPrice: Money(amount: billedPrice)
                )
            )
        }
        
        return parts
    }
    
    private func extractBestPrice(texts: [String], partIndex: Int) -> Decimal? {
        
        var prices: [Decimal] = []
        
        for i in (partIndex+1)..<texts.count {
            let cleaned = texts[i].replacingOccurrences(of: ",", with: "")
            
            if let value = Decimal(string: cleaned),
               cleaned.contains("."),
               value > 0 {
                
                prices.append(value)
            }
        }
        
        // 🔥 key rule:
        // if 2 prices exist → choose the SMALLER (unit price)
        if prices.count >= 2 {
            return prices.min()
        }
        
        return prices.first
    }
    
    private func extractInlinePrice(texts: [String]) -> Decimal? {
        for text in texts {
            let cleaned = text.replacingOccurrences(of: "$", with: "")
                .replacingOccurrences(of: ",", with: "")
            
            if cleaned.range(of: #"^\d+\.\d{2}$"#, options: .regularExpression) != nil,
               let value = Decimal(string: cleaned),
               value > 0 {
                return value
            }
        }
        return nil
    }
    
    private func extractNearestGlobalPrice(for row: [OCRToken], allTokens: [OCRToken]) -> Decimal? {
        let rowY = row.first?.boundingBox.midY ?? 0
        
        let priceTokens = allTokens.filter {
            let cleaned = $0.text.replacingOccurrences(of: ",", with: "")
            return cleaned.range(of: #"^\d+\.\d{2}$"#, options: .regularExpression) != nil
        }
        
        let nearest = priceTokens.min(by: {
            abs($0.boundingBox.midY - rowY) < abs($1.boundingBox.midY - rowY)
        })
        
        guard let text = nearest?.text.replacingOccurrences(of: ",", with: ""),
              let value = Decimal(string: text) else {
            return nil
        }
        
        return value
    }
    
    private func shouldUseColumnBased(_ tokens: [OCRToken]) -> Bool {
        let texts = tokens.map { $0.text.uppercased() }
        let joined = texts.joined(separator: " ")
        
        let hasTechSection = joined.contains("TECH(S):")
        let hasTableHeaders =
        joined.contains("PART NUMBER") ||
        joined.contains("PART PRICE") ||
        joined.contains("PART DESCRIPTION") ||
        joined.contains("EXT PRICE") ||
        joined.contains("QTY")
        
        let partNumberCount = texts.filter {
            $0.range(of: #"^\d{7,8}$"#, options: .regularExpression) != nil
        }.count
        
        let priceCount = texts.filter {
            let cleaned = $0.replacingOccurrences(of: ",", with: "")
            return cleaned.range(of: #"^\d+\.\d{2}$"#, options: .regularExpression) != nil
        }.count
        
        return hasTechSection && !hasTableHeaders && partNumberCount >= 6 && priceCount >= 6
    }
    
    private func extractFlexibleDescription(texts: [String], partIndex: Int) -> String {
        
        var descParts: [String] = []
        
        // 1. Try RIGHT side first (existing behavior)
        for i in (partIndex+1)..<texts.count {
            
            let text = texts[i].uppercased()
            
            if text.range(of: #"^\d+(\.\d{2})?$"#, options: .regularExpression) != nil {
                break
            }
            
            if Int(text) != nil { continue }
            
            descParts.append(texts[i])
        }
        
        if !descParts.isEmpty {
            return descParts.joined(separator: " ")
        }
        
        // 🔥 2. SAFE LEFT fallback (for receipts like your new example)
        descParts = []
        
        for i in stride(from: partIndex-1, through: 0, by: -1) {
            
            let text = texts[i].uppercased()
            
            // stop if we hit structured fields
            if text.contains("REPL") ||
                text.contains("QTY") ||
                text.contains("PRICE") {
                break
            }
            
            if text.range(of: #"^\d+(\.\d{2})?$"#, options: .regularExpression) != nil {
                continue
            }
            
            if Int(text) != nil { continue }
            
            descParts.insert(texts[i], at: 0)
        }
        
        if !descParts.isEmpty {
            return descParts.joined(separator: " ")
        }
        
        return "No description"
    }
    
    private func xPosition(ofFirstMatching words: [String], in row: [OCRToken]) -> CGFloat? {
        for token in row {
            let upper = token.text.uppercased()
            if words.contains(upper) {
                return token.boundingBox.midX
            }
        }
        return nil
    }
    
    private func nearestTokenText(
        to x: CGFloat,
        in row: [OCRToken],
        maxDistance: CGFloat,
        pattern: String? = nil
    ) -> String? {
        let candidates = row.filter { token in
            abs(token.boundingBox.midX - x) <= maxDistance
        }
        
        let filtered: [OCRToken]
        if let pattern {
            filtered = candidates.filter {
                $0.text.range(of: pattern, options: .regularExpression) != nil
            }
        } else {
            filtered = candidates
        }
        
        return filtered.min(by: {
            abs($0.boundingBox.midX - x) < abs($1.boundingBox.midX - x)
        })?.text
    }
    
    private func nearestPrice(
        to x: CGFloat,
        in row: [OCRToken],
        maxDistance: CGFloat
    ) -> Decimal? {
        let candidates = row.filter { token in
            abs(token.boundingBox.midX - x) <= maxDistance
        }
        
        for token in candidates.sorted(by: {
            abs($0.boundingBox.midX - x) < abs($1.boundingBox.midX - x)
        }) {
            let cleaned = token.text.replacingOccurrences(of: ",", with: "")
            if cleaned.range(of: #"^\d+\.\d{2}$"#, options: .regularExpression) != nil,
               let value = Decimal(string: cleaned),
               value > 0 {
                return value
            }
        }
        
        return nil
    }
    
    private func extractFallbackPrice(in row: [OCRToken]) -> Decimal? {
        
        let prices = row.compactMap { token -> Decimal? in
            let cleaned = token.text.replacingOccurrences(of: ",", with: "")
            
            if cleaned.range(of: #"^\d+\.\d{2}$"#, options: .regularExpression) != nil,
               let value = Decimal(string: cleaned),
               value > 0 {
                return value
            }
            return nil
        }
        
        if prices.isEmpty { return nil }
        
        // 🔥 critical rule for tables:
        // choose the SMALLER → unit price, not ext price
        return prices.min()
    }
    
    private func collectDescription(
        near descriptionX: CGFloat,
        in row: [OCRToken],
        stopBeforeX: CGFloat
    ) -> String {
        let tokens = row
            .filter {
                $0.boundingBox.midX >= descriptionX - 0.12 &&
                $0.boundingBox.midX < stopBeforeX - 0.02
            }
            .sorted { $0.boundingBox.minX < $1.boundingBox.minX }
        
        let texts = tokens.map { $0.text }.filter { text in
            text.range(of: #"^(GM)?\d{7,10}$"#, options: .regularExpression) == nil &&
            Int(text) == nil
        }
        
        return texts.joined(separator: " ").trimmingCharacters(in: .whitespacesAndNewlines)
    }
    
    // MARK: - Narrative extraction (critical fix for tire-style receipts)
    
    private func extractNarrativeParts(_ tokens: [OCRToken]) -> [Part] {
        // Sort tokens top → bottom, then left → right
        let sorted = tokens.sorted {
            if abs($0.boundingBox.midY - $1.boundingBox.midY) > 0.02 {
                return $0.boundingBox.midY > $1.boundingBox.midY
            }
            return $0.boundingBox.minX < $1.boundingBox.minX
        }
        
        var parts: [Part] = []
        
        for i in 0..<sorted.count {
            let text = sorted[i].text
            
            // STRICT part number detection: must be 7–8 digits (avoid technician IDs like 500165)
            guard text.range(of: #"^\d{7,10}$"#, options: .regularExpression) != nil else { continue }
            
            let partNumber = text
            
            // 🔥 Only consider rows inside "Parts" section (prevents picking technician IDs)
            let nearbyContext = sorted[max(0, i-10)..<min(sorted.count, i+10)]
                .map { $0.text.uppercased() }
                .joined(separator: " ")
            
            if !nearbyContext.contains("PARTS") {
                continue
            }
            
            // Look ahead for pattern: DESCRIPTION + PRICE
            var descriptionParts: [String] = []
            var price: Decimal?
            
            var j = i + 1
            while j < min(i + 10, sorted.count) {
                
                let next = sorted[j].text
                
                let cleaned = next.replacingOccurrences(of: "$", with: "")
                    .replacingOccurrences(of: ",", with: "")
                
                // detect price
                if cleaned.range(of: #"^\d+\.\d{2}$"#, options: .regularExpression) != nil,
                   let value = Decimal(string: cleaned) {
                    price = value
                    break
                }
                
                // skip noise tokens
                if next == "-" || next == "PARTS" { j += 1; continue }
                
                // avoid picking numeric garbage
                if Int(next) == nil {
                    descriptionParts.append(next)
                }
                
                j += 1
            }
            
            guard let finalPrice = price else { continue }
            
            let description = descriptionParts
                .joined(separator: " ")
                .trimmingCharacters(in: .whitespaces)
            
            // 🔥 Avoid duplicates (same part number + same price)
            if parts.contains(where: {
                $0.partNumber == PartNumber(partNumber) && $0.billedPrice.amount == finalPrice
            }) {
                continue
            }
            
            parts.append(
                Part(
                    partNumber: PartNumber(partNumber),
                    description: description.isEmpty ? "No description" : description,
                    quantity: 1,
                    billedPrice: Money(amount: finalPrice)
                )
            )
        }
        
        return parts
    }
    
    // MARK: - Vertical column pairing (fix for misaligned tables)
    
    private func extractVerticalColumns(_ tokens: [OCRToken]) -> [Part] {
        
        let partTokens = tokens.filter {
            $0.text.range(of: #"^(GM)?\d{7,10}$"#, options: .regularExpression) != nil
            || isLoosePartNumber($0.text)
        }
        
        // 🔥 IMPROVED: detect correct price column (avoid bottom summary numbers)
        let allPriceCandidates = tokens.filter {
            let cleaned = $0.text.replacingOccurrences(of: ",", with: "")
            return cleaned.range(of: #"^\d+\.\d{2}$"#, options: .regularExpression) != nil
        }
        
        // cluster by X (simple binning)
        let sortedByX = allPriceCandidates.sorted { $0.boundingBox.midX < $1.boundingBox.midX }
        
        var columns: [[OCRToken]] = []
        let xThreshold: CGFloat = 0.05
        
        for token in sortedByX {
            if let idx = columns.firstIndex(where: {
                abs($0[0].boundingBox.midX - token.boundingBox.midX) < xThreshold
            }) {
                columns[idx].append(token)
            } else {
                columns.append([token])
            }
        }
        
        // 🔥 choose the RIGHTMOST dense column (actual part prices)
        let priceColumn = columns.max(by: { $0.count < $1.count }) ?? []
        
        let priceTokens = priceColumn
        
        // 🔥 IMPROVED: detect description column by spatial proximity, not just text filtering
        let partXs = partTokens.map { $0.boundingBox.midX }
        let avgPartX = partXs.reduce(0, +) / CGFloat(max(partXs.count, 1))
        
        let descriptionTokens = tokens.filter { token in
            let text = token.text.uppercased()
            
            // must be alphabetic (allow patterns like (S)GASKET)
            let isWordLike =
            text.range(of: #"^[A-Z\(\)\/\s]+$"#, options: .regularExpression) != nil
            
            // exclude obvious noise
            let isNoise =
            text.contains("PART") ||
            text.contains("PRICE") ||
            text.contains("NUMBER") ||
            text.contains("DESCRIPTION") ||
            text.contains("MISC") ||
            text.contains("SHOP") ||
            text.contains("FEE") ||
            text.contains("LABOR") ||
            text.contains("TOTAL") ||
            text.contains("SUBTOTAL") ||
            text.contains("CHEVROLET") ||
            text.contains("ROGER") ||
            text.contains("DEAN") ||
            text.contains("ESTIMATE") ||
            text == "AND" ||
            text == "LINE"
            
            // 🔥 KEY: must be near the description column (right of part column, not far right like prices)
            let dx = token.boundingBox.midX - avgPartX
            
            return isWordLike &&
            !isNoise &&
            dx > 0.03 && dx < 0.35
        }
        
        // Detect quantity behavior
        let globalQty: Int? = {
            // find explicit QTY label
            if let qtyLabel = tokens.first(where: { $0.text.uppercased() == "QTY" }) {
                let labelY = qtyLabel.boundingBox.midY
                
                if let nearestQty = tokens
                    .filter({ Int($0.text) != nil })
                    .min(by: {
                        abs($0.boundingBox.midY - labelY) < abs($1.boundingBox.midY - labelY)
                    }),
                   let q = Int(nearestQty.text), q > 0, q < 100 {
                    return q
                }
            }
            return nil
        }()
        
        guard !partTokens.isEmpty else { return [] }
        
        // Sort parts top → bottom (anchor)
        let partsSorted = partTokens.sorted { $0.boundingBox.midY > $1.boundingBox.midY }
        
        var results: [Part] = []
        
        for part in partsSorted {
            
            let partY = part.boundingBox.midY
            
            // 🔥 IMPROVED: match description by BOTH vertical AND horizontal proximity
            let description = descriptionTokens.min(by: {
                let dy0 = abs($0.boundingBox.midY - partY)
                let dy1 = abs($1.boundingBox.midY - partY)
                
                let dx0 = abs($0.boundingBox.midX - part.boundingBox.midX)
                let dx1 = abs($1.boundingBox.midX - part.boundingBox.midX)
                
                // prioritize vertical alignment first, then horizontal closeness
                return (dy0, dx0) < (dy1, dx1)
            })?.text ?? "No description"
            
            // Find nearest price vertically (within 0.08)
            let priceToken = priceTokens
                .filter { abs($0.boundingBox.midY - partY) < 0.08 }
                .min(by: {
                    abs($0.boundingBox.midY - partY) < abs($1.boundingBox.midY - partY)
                })
            
            guard let priceToken else { continue }
            
            let priceText = priceToken.text.replacingOccurrences(of: ",", with: "")
            guard let price = Decimal(string: priceText) else { continue }
            
            // Correct quantity logic:
            // If only one qty value exists but multiple parts → distribute as 1 each
            let quantity: Int = {
                if let gq = globalQty {
                    if partsSorted.count > 1 {
                        return 1   // shared qty → each part is 1
                    } else {
                        return gq
                    }
                }
                return 1
            }()
            
            results.append(
                Part(
                    partNumber: PartNumber(part.text),
                    description: description,
                    quantity: quantity,
                    billedPrice: Money(amount: price)
                )
            )
        }
        
        return results
    }
    
    private func extractEstimatedPartCount(_ tokens: [OCRToken]) -> Int {
        return tokens.filter {
            $0.text.range(of: #"^(GM)?\d{7,10}$"#, options: .regularExpression) != nil
            || isLoosePartNumber($0.text)
        }.count
    }
    
    // MARK: - SAFE inline pattern extraction (only triggers when clear pattern exists)
    
    private func extractInlinePatternPartsSafely(_ tokens: [OCRToken]) -> [Part] {
        
        let fullText = tokens.map { $0.text }.joined(separator: " ")
        
        // STRICT pattern: must include hyphen-separated structure AND $ price
        let pattern = #"\d{7,10}\s*-\s*[A-Z0-9\s\/]+\s*-\s*\$\d+\.\d{2}"#
        
        guard fullText.range(of: pattern, options: .regularExpression) != nil else {
            return []
        }
        
        // Now run precise extraction
        let extractPattern = #"(\d{7,10})\s*-\s*([A-Z0-9\s\/]+?)\s*-\s*\$?(\d+\.\d{2})"#
        
        guard let regex = try? NSRegularExpression(pattern: extractPattern) else {
            return []
        }
        
        let matches = regex.matches(in: fullText, range: NSRange(fullText.startIndex..., in: fullText))
        
        var parts: [Part] = []
        
        for match in matches {
            guard match.numberOfRanges == 4,
                  let pRange = Range(match.range(at: 1), in: fullText),
                  let dRange = Range(match.range(at: 2), in: fullText),
                  let prRange = Range(match.range(at: 3), in: fullText) else { continue }
            
            let partNumber = String(fullText[pRange])
            let rawDescription = String(fullText[dRange]).trimmingCharacters(in: .whitespaces)
            let priceStr = String(fullText[prRange])
            
            guard let price = Decimal(string: priceStr) else { continue }
            
            // 🔥 NEW: extract quantity from description patterns like "TIRE 3"
            var quantity = 1
            let qtyPattern = #"\b(\d+)\b"#
            if let regex = try? NSRegularExpression(pattern: qtyPattern),
               let match = regex.firstMatch(in: rawDescription, range: NSRange(rawDescription.startIndex..., in: rawDescription)),
               let range = Range(match.range(at: 1), in: rawDescription),
               let extractedQty = Int(rawDescription[range]) {
                // only accept reasonable quantities
                if extractedQty > 1 && extractedQty < 20 {
                    quantity = extractedQty
                }
            }
            
            // 🔥 clean description (remove trailing quantity like "TIRE 3" → "TIRE")
            let cleanedDescription = rawDescription.replacingOccurrences(
                of: #"\s*\d+\b"#,
                with: "",
                options: .regularExpression
            ).trimmingCharacters(in: .whitespaces)
            
            parts.append(
                Part(
                    partNumber: PartNumber(partNumber),
                    description: cleanedDescription.isEmpty ? rawDescription : cleanedDescription,
                    quantity: quantity,
                    billedPrice: Money(amount: price)
                )
            )
        }
        
        return parts
    }
    
    private func isLoosePartNumber(_ text: String) -> Bool {
        let upper = text.uppercased()

        // must contain BOTH letters and digits
        let hasLetter = upper.range(of: #"[A-Z]"#, options: .regularExpression) != nil
        let hasDigit  = upper.range(of: #"\d"#, options: .regularExpression) != nil

        // must be at least length 6
        let validLength = upper.count >= 6

        // allow * and - patterns
        let allowedChars = upper.range(of: #"^[A-Z0-9\*\-]+$"#, options: .regularExpression) != nil

        return hasLetter && hasDigit && validLength && allowedChars
    }
    
    private func extractLooseRowBased(_ tokens: [OCRToken]) -> [Part] {

        let rows = groupTokensIntoRows(tokens)
        var parts: [Part] = []

        for row in rows {

            let texts = row.map { $0.text }

            // 🔥 detect loose part number (Ford style: BL3Z*6D256*D)
            guard let partIndex = texts.firstIndex(where: {
                isLoosePartNumber($0)
            }) else { continue }

            let partNumber = texts[partIndex]

            // 🔥 find nearest price in SAME row
            let prices: [Decimal] = texts.compactMap { text in
                let cleaned = text
                    .replacingOccurrences(of: ",", with: "")
                    .replacingOccurrences(of: ":", with: ".") // OCR fix

                if cleaned.range(of: #"^\d+\.\d{2}$"#, options: .regularExpression) != nil {
                    return Decimal(string: cleaned)
                }
                return nil
            }

            guard let price = prices.min() else { continue }

            // 🔥 simple description (right side first)
            var descriptionParts: [String] = []

            for i in (partIndex+1)..<texts.count {
                let t = texts[i]

                if t.range(of: #"^\d+(\.\d{2})?$"#, options: .regularExpression) != nil {
                    break
                }

                if Int(t) == nil {
                    descriptionParts.append(t)
                }
            }

            let description = descriptionParts.isEmpty
                ? "No description"
                : descriptionParts.joined(separator: " ")

            parts.append(
                Part(
                    partNumber: PartNumber(partNumber),
                    description: description,
                    quantity: 1,
                    billedPrice: Money(amount: price)
                )
            )
        }

        return parts
    }
    
    private func extractCrossRowParts(_ tokens: [OCRToken]) -> [Part] {

        let rows = groupTokensIntoRows(tokens)
        var parts: [Part] = []

        for i in 0..<rows.count {

            let texts = rows[i].map { $0.text }

            // 🔥 detect loose part number (Ford style)
            guard let partIndex = texts.firstIndex(where: {
                isLoosePartNumber($0)
            }) else { continue }

            let partNumber = texts[partIndex]

            // 🔥 find price in SAME row first
            var price: Decimal? = texts.compactMap { text in
                let cleaned = text
                    .replacingOccurrences(of: ",", with: "")
                    .replacingOccurrences(of: ":", with: ".")

                if cleaned.range(of: #"^\d+\.\d{2}$"#, options: .regularExpression) != nil {
                    return Decimal(string: cleaned)
                }
                return nil
            }.min()

            // 🔥 if not found → search NEXT rows (critical fix)
            if price == nil {
                for j in (i+1)..<min(i+4, rows.count) {

                    let nextTexts = rows[j].map { $0.text }

                    if let found = nextTexts.compactMap({ text -> Decimal? in
                        let cleaned = text
                            .replacingOccurrences(of: ",", with: "")
                            .replacingOccurrences(of: ":", with: ".")

                        if cleaned.range(of: #"^\d+\.\d{2}$"#, options: .regularExpression) != nil {
                            return Decimal(string: cleaned)
                        }
                        return nil
                    }).first {

                        price = found
                        break
                    }
                }
            }

            guard let finalPrice = price else { continue }

            // 🔥 extract description (right side only, safe)
            var descParts: [String] = []
            for k in (partIndex+1)..<texts.count {
                let t = texts[k]
                if t.range(of: #"^\d"#, options: .regularExpression) != nil { break }
                if Int(t) == nil {
                    descParts.append(t)
                }
            }

            let description = descParts.isEmpty
                ? "No description"
                : descParts.joined(separator: " ")

            parts.append(
                Part(
                    partNumber: PartNumber(partNumber),
                    description: description,
                    quantity: 1,
                    billedPrice: Money(amount: finalPrice)
                )
            )
        }

        return parts
    }
}