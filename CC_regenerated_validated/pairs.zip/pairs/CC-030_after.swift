private func detectSubsystem(from text: String) -> String? {
    return detectSubsystemCore(text)
}

    
    private func detectSubsystemCore(from text: String) -> String? {

        let t = text.lowercased()

        if t.contains("o2") || t.contains("oxygen sensor") {
            return "exhaust"
        }
        
        // =========================
        // 🔥 Lean / mixture detection
        // =========================
        if t.contains("lean") || t.contains("air fuel") || t.contains("mixture") {
            return "air"
        }

        // =========================
        // Fuel-related
        // =========================
        if t.contains("fuel") || t.contains("regulator") || t.contains("injector") {
            return "fuel"
        }

        // =========================
        // Cooling
        // =========================
        if t.contains("coolant") || t.contains("radiator") || t.contains("thermostat") {
            return "cooling"
        }

        // =========================
        // Air intake
        // =========================
        if t.contains("air") || t.contains("intake") || t.contains("maf") {
            return "air"
        }

        // =========================
        // EVAP
        // =========================
        if t.contains("evap") {
            return "evap"
        }

        // =========================
        // Exhaust
        // =========================
        if t.contains("egr") || t.contains("exhaust") {
            return "exhaust"
        }

        return nil
    }