    
    private func extractUsageFromRows(_ rows: [OCRRow]) -> String? {

        // =================================================
        // 🔥 [ADD] WATER: Gallons direct extraction (최우선)
        // =================================================
        for row in rows {

            let upper = row.fullText.uppercased()

            if upper.contains("GALLON") {

                let numbers = row.items
                    .map { $0.text }
                    .compactMap { Double($0) }

                // 👉 gallons는 항상 큰 값 (noise 제거)
                let candidates = numbers.filter { $0 > 100 && $0 < 100000 }

                if let best = candidates.max() {
                    print("💧 GALLONS detected:", best)
                    return String(format: "%.0f", best)
                }
            }
        }
        
        // =================================================
        // 1️⃣ PRIMARY: amount 왼쪽 값 (가장 정확)
        // =================================================
        for row in rows {

            let upper = row.fullText.uppercased()

            if upper.contains("ACCOUNT") { continue }
            if upper.contains("TOTAL") { continue }

            let tokens = row.items.map { $0.text }

            for i in 0..<tokens.count {

                let t = tokens[i]

                if t.range(of: #"\d+\.\d{2}"#, options: .regularExpression) != nil {

                    if i > 0 {

                        let prev = tokens[i - 1]

                        if let usage = Double(prev),
                           usage > 0,
                           usage < 1000 {
                            return String(format: "%.0f", usage)
                        }
                    }
                }
            }
        }

        // =================================================
        // 2️⃣ SECONDARY: unit row 기반 (하지만 max 금지)
        // =================================================
        for row in rows {

            let upper = row.fullText.uppercased()

            if upper.contains("ACCOUNT") { continue }
            if upper.contains("AMOUNT") { continue }
            if upper.contains("TOTAL") { continue }

            let hasUnit =
                upper.contains("MCF") ||
                upper.contains("KWH") ||
                upper.contains("CCF")

            if hasUnit {

                let numbers = row.items
                    .map { $0.text }
                    .compactMap { Double($0) }

                // 🔥 핵심: "작은 값" 선택
                let candidates = numbers.filter { $0 > 0 && $0 < 1000 }

                if let best = candidates.min() {
                    return String(format: "%.0f", best)
                }
            }
        }

        // =================================================
        // 3️⃣ FINAL FALLBACK: global heuristic (max 제거)
        // =================================================
        for row in rows {

            let upper = row.fullText.uppercased()

            if upper.contains("ACCOUNT") { continue }
            if upper.contains("AMOUNT") { continue }

            let numbers = row.items
                .map { $0.text }
                .compactMap { Double($0) }

            let candidates = numbers.filter {
                $0 > 0 && $0 < 1000   // 🔥 핵심 제한
            }

            if let best = candidates.min() {
                return String(format: "%.0f", best)
            }
        }

        return nil
    }