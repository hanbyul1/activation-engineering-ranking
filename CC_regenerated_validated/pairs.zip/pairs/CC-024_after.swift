func classify(
        text: String,
        rows: [String]
    ) -> String {
    return classifyCore(text, rows)
}


    func classifyCore(
        text: String,
        rows: [String]
    ) -> String {

        let full = text.uppercased()
//        let combined = rows.joined(separator: " ").uppercased()

        print("\n🧠 ===== UTILITY CLASSIFIER START =====")

        // =====================================================
        // 🔥 1. GAS (먼저!)
        // =====================================================
        if full.contains("MCF") ||
           full.contains("THERM") ||
           full.contains("NATURAL GAS") {

            print("🔥 TYPE: gas (unit)")
            return "gas"
        }

        // =====================================================
        // 🔥 2. ELECTRICITY
        // =====================================================
        if full.contains("KWH") ||
           full.contains("ELECTRIC") {

            print("🔥 TYPE: electricity")
            return "electricity"
        }

        // =====================================================
        // 🔥 3. WATER (축소된 조건)
        // =====================================================
        if full.contains("CCF") ||
           full.contains("GALLON") ||
           (full.contains("WATER") && full.contains("SEWER")) {

            print("🔥 TYPE: water")
            return "water"
        }

        // =====================================================
        // 🔥 4. fallback scoring
        // =====================================================
        var gasScore = 0
        var electricScore = 0
        var waterScore = 0

        if full.contains("NATURAL GAS") { gasScore += 5 }
        if full.contains("GAS USE") { gasScore += 3 }

        if full.contains("ELECTRIC") { electricScore += 3 }

        if full.contains("WATER") { waterScore += 3 }
        if full.contains("SEWER") { waterScore += 3 }

        print("📊 SCORES → gas:", gasScore,
              "| electricity:", electricScore,
              "| water:", waterScore)

        if gasScore >= electricScore && gasScore >= waterScore {
            return "gas"
        }

        if electricScore >= gasScore && electricScore >= waterScore {
            return "electricity"
        }

        if waterScore >= gasScore && waterScore >= electricScore {
            return "water"
        }

        // =====================================================
        // 🔥 fallback
        // =====================================================
        if full.contains("ACCOUNT") && full.contains("DUE") {
            return "utility"
        }

        return "unknown"
    }