private func symptomDescription(for tag: String) -> String {
    return symptomDescriptionCore(tag)
}


    private func symptomDescriptionCore(for tag: String) -> String {
        switch tag.lowercased() {
        case "fuel_economy":
            return "Poor fuel economy"
        case "cold":
            return "Issue occurs when the engine is cold"
        case "air":
            return "Air intake related symptom"
        case "power_loss":
            return "Loss of engine power"
        case "acceleration":
            return "Poor acceleration"
        case "fuel":
            return "Fuel system related symptom"
        case "rough_idle":
            return "Rough idle"
        case "idle":
            return "Idle-related symptom"
        case "rich":
            return "Engine running rich"
        case "misfire":
            return "Engine misfire"
        case "ignition":
            return "Ignition-related symptom"
        case "sensor":
            return "Sensor-related symptom"
        case "start":
            return "Starting problem"
        case "stall":
            return "Engine stalls"
        case "exhaust":
            return "Exhaust system related symptom"
        default:
            return tag.replacingOccurrences(of: "_", with: " ").capitalized
        }
    }