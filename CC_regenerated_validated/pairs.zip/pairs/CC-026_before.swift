
    private func correctElectricUsage(
        rawUsage: Double?,
        rows: [OCRRow]
    ) -> Double? {

        print("🧠 ELECTRIC CORRECTION START")

        // =================================================
        // 0️⃣ 표 기반 usage (ABC 샘플 대응)
        // =================================================
        if let tableUsage = extractElectricUsageFromTable(rows: rows) {
            return tableUsage
        }
        
        // =================================================
        // 0️⃣ USED 기반 (DTE 핵심 패턴) 🔥
        // =================================================
        if let used = extractUsedKwh(rows: rows) {
            return used
        }
        
        // =================================================
        // 1️⃣ KWH USED (최우선 - strongest signal)
        // =================================================
        for row in rows {
            let upper = row.fullText.uppercased()

            if upper.contains("KWH USED") {

                let values = row.fullText.matches(for: #"\d+(\.\d+)?"#)
                    .compactMap { Double($0[0]) }

                if let best = values.max(), best > 100 {
                    print("✅ CORRECTED (KWH USED):", best)
                    return best
                }
            }
        }

        // =================================================
        // 2️⃣ METER READING DIFF (FIXED - 정확한 패턴)
        // =================================================
        for row in rows {
            let upper = row.fullText.uppercased()

            if upper.contains("METER READING") {

                // 🔥 핵심: "A - B" 구조만 추출
                let pattern = #"\d+(\.\d+)?\s*-\s*\d+(\.\d+)?"#

                if let range = row.fullText.range(of: pattern, options: .regularExpression) {

                    let segment = String(row.fullText[range])

                    let values = segment.matches(for: #"\d+(\.\d+)?"#)
                        .compactMap { Double($0[0]) }

                    if values.count == 2 {
                        let diff = abs(values[1] - values[0])

                        if diff > 100 && diff < 10000 {
                            print("✅ CORRECTED (METER DIFF FIXED):", diff)
                            return diff
                        }
                    }
                }
            }
        }

        // =================================================
        // 3️⃣ 기존 값 검증 (주소/쓰레기 필터)
        // =================================================
        if let raw = rawUsage {

            let isAddressLike = rows.contains { row in
                row.fullText.contains("\(Int(raw))") &&
                (row.fullText.contains("ST") ||
                 row.fullText.contains("DR") ||
                 row.fullText.contains("RD") ||
                 row.fullText.contains("AVE"))
            }

            if isAddressLike {
                print("❌ REJECT ADDRESS-LIKE USAGE:", raw)
                return nil
            }

            if raw < 100 {
                print("❌ REJECT TOO SMALL:", raw)
                return nil
            }

            print("⚠️ KEEP ORIGINAL USAGE:", raw)
            return raw
        }

        print("❌ NO VALID USAGE FOUND")
        return nil
    }