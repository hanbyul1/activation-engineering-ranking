private func classifyDocument(_ text: String) -> String {
    return classifyDocumentCore(text)
}

        
        private func classifyDocumentCore(_ text: String) -> String {
            let upper = text.uppercased()

            // 🔥 Service Receipt
            if upper.contains("INVOICE") ||
               upper.contains("TOTAL DUE") ||
               upper.contains("BALANCE DUE") ||
               upper.contains("DESCRIPTION OF WORK") ||
               upper.contains("SERVICE") ||
               upper.contains("AMOUNT DUE") {
                return "service"
            }

            // 🔥 Utility
            if upper.contains("KWH") ||
               upper.contains("ELECTRIC") ||
               upper.contains("GAS") ||
               upper.contains("WATER") {
                return "utility"
            }

            return "utility"
        }