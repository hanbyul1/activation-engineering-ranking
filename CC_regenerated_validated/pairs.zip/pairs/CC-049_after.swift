private func normalizeIngredients(from rawTexts: [String]) -> [String] {
    return normalizeIngredientsCore(rawTexts)
}

    private func normalizeIngredientsCore(from rawTexts: [String]) -> [String] {
        var results: Set<String> = []
        
        // 1. 성분표 구역 감지를 위한 상태 변수
        var isInsideFacts = false
        
        // 2. 강력한 제외 키워드 리스트 (성분표 외부 텍스트)
        let globalExcludes = [
            "recommended", "additional", "refrigeration", "store in", "daily value",
            "at time of", "manufacture", "expiration", "organisms", "dary", "free",
            "non-gmo", "ingredients:", "other ingredients", "serving size", "amount per"
        ]

        for line in rawTexts {
            let lower = line.lowercased().trimmingCharacters(in: .whitespaces)
            
            // --- 구역 감지 ---
            if lower.contains("supplement facts") {
                isInsideFacts = true
                continue
            }
            
            // "Other Ingredients"를 만나면 성분표 구역이 끝난 것으로 간주
            if lower.contains("other ingredients") || lower.contains("rie of") {
                isInsideFacts = false
                break // 주요 성분 분석 중단
            }

            // --- 구역 내 텍스트 처리 ---
            if isInsideFacts {
                // ❌ 제외 키워드가 포함된 줄은 통째로 버림
                if globalExcludes.contains(where: { lower.contains($0) }) { continue }
                
                // ❌ "Proprietary Blend" 혹은 숫자/기호만 있는 데이터 제거
                if lower.contains("proprietary") || lower.contains("blend") { continue }
                
                // 3. 숫자, 함량 단위(mg, g, %), 특수문자 (+, *, ~) 제거
                let cleaned = line.replacingOccurrences(
                    of: #"\d+(\s*(mg|g|mcg|iu|%|cfu|billion))?|\+|\*|~|i\s*\d*"#,
                    with: "",
                    options: [.regularExpression, .caseInsensitive]
                ).trimmingCharacters(in: .whitespacesAndNewlines)

                // 4. 오타 수정 (Bio/Bino/Brico -> Bifidobacterium)
                var corrected = cleaned
                if lower.contains("bacterium") || lower.contains("bacter") {
                    if lower.contains("bino") || lower.contains("brico") || lower.contains("bilbo") {
                        corrected = corrected.replacingOccurrences(of: #"(Bino|Brico|Bilbo)\w+"#, with: "Bifidobacterium", options: .regularExpression)
                    }
                }
                
                if corrected.count > 4 { // "2ing" 같은 짧은 오타 원천 차단
                    results.insert(cleanupIngredientName(corrected))
                }
            }
        }

        return Array(results).sorted()
    }