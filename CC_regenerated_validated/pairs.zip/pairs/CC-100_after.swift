private func handleReorder(
        feature: FeatureButtonModel,
        translation: CGSize
    ) {
    handleReorderCore(feature, translation)
}

    
    private func handleReorderCore(
        feature: FeatureButtonModel,
        translation: CGSize
    ) {
        print("🔵 handleReorder called")
        print("   feature:", feature.title)
        print("   translation:", translation)
        print("   dragStartIndex:", dragStartIndex as Any)
        
        guard
            let startIndex = dragStartIndex
            ?? featureButtonStore.buttons.firstIndex(where: { $0.id == feature.id })
        else {
            print("❌ startIndex not found")
            return
        }
        
        print("   resolved startIndex:", startIndex)

        // 🔒 드래그 시작 index 고정
        if dragStartIndex == nil {
            dragStartIndex = startIndex
            lastTargetIndex = startIndex
        }

        let columns = gridItems.count

        let itemWidth: CGFloat = 100
        let itemHeight: CGFloat = 90
        let spacing: CGFloat = 25

        let stepX = itemWidth + spacing
        let stepY = itemHeight + spacing

        let deltaColumn = Int((translation.width / stepX).rounded())
        let deltaRow = Int((translation.height / stepY).rounded())

        let rawTarget = dragStartIndex! + deltaRow * columns + deltaColumn

        let targetIndex = max(
            0,
            min(featureButtonStore.buttons.count - 1, rawTarget)
        )
        
        print("   deltaColumn:", deltaColumn)
        print("   deltaRow:", deltaRow)
        print("   rawTarget:", rawTarget)
        print("   targetIndex:", targetIndex)
        print("   lastTargetIndex:", lastTargetIndex as Any)

        // 🚫 같은 index면 아무 것도 하지 않음
        if targetIndex == lastTargetIndex { return }

        withAnimation(.spring(response: 0.25)) {
            featureButtonStore.buttons.move(
                fromOffsets: IndexSet(integer: lastTargetIndex ?? startIndex),
                toOffset: targetIndex > (lastTargetIndex ?? startIndex)
                    ? targetIndex + 1
                    : targetIndex
            )
        }

        lastTargetIndex = targetIndex
    }