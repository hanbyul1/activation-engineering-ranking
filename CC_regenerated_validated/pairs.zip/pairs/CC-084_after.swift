func extractStructuredText(from image: ImageData) -> OCRSplitResult {
    return extractStructuredTextCore(image)
}

    func extractStructuredTextCore(from image: ImageData) -> OCRSplitResult {
        guard let uiImage = UIImage(data: image.data) else {
            return OCRSplitResult(blocks: [], tokens: [])
        }
        let normalizedImage = normalizeImage(uiImage)
        guard let cgImage = normalizedImage.cgImage else {
            return OCRSplitResult(blocks: [], tokens: [])
        }
        
        let request = VNRecognizeTextRequest()
        request.recognitionLevel = .accurate
        request.usesLanguageCorrection = false
        
        let handler = VNImageRequestHandler(
            cgImage: cgImage,
            orientation: .up,   // 🔥 강제 고정
            options: [:]
        )
        
        do {
            try handler.perform([request])
            guard let observations = request.results else {
                return OCRSplitResult(blocks: [], tokens: [])
            }
            
            var blockItems: [OCRItem] = []
            var tokenItems: [OCRItem] = []
            
            for obs in observations {
                guard let top = obs.topCandidates(1).first else { continue }
                
                let rawText = top.string.trimmingCharacters(in: .whitespacesAndNewlines)
                guard !rawText.isEmpty else { continue }
                
                // 🔴 block box
                let blockBox = CGRect(
                    x: obs.boundingBox.origin.x,
                    y: 1 - obs.boundingBox.origin.y - obs.boundingBox.height,
                    width: obs.boundingBox.width,
                    height: obs.boundingBox.height
                )
                
                blockItems.append(OCRItem(text: rawText, box: blockBox))
                
                // 🔥 핵심: 실제 위치 기반 token 분리
                let nsString = rawText as NSString
                
                let words = rawText
                    .components(separatedBy: .whitespacesAndNewlines)
                    .filter { !$0.isEmpty }
                
                var searchRange = NSRange(location: 0, length: nsString.length)
                
                for word in words {
                    
                    let foundRange = nsString.range(of: word, options: [], range: searchRange)
                    
                    if foundRange.location != NSNotFound,
                       let swiftRange = Range(foundRange, in: rawText),
                       let quad = try? top.boundingBox(for: swiftRange) {
                        
                        let minX = min(quad.topLeft.x, quad.bottomLeft.x)
                        let maxX = max(quad.topRight.x, quad.bottomRight.x)
                        
                        let minY = min(quad.bottomLeft.y, quad.bottomRight.y)
                        let maxY = max(quad.topLeft.y, quad.topRight.y)
                        
                        let tokenBox = CGRect(
                            x: minX, // 그대로 유지
                            y: 1 - maxY, // Vision의 0(하단)을 0(상단)으로 뒤집기
                            width: maxX - minX,
                            height: maxY - minY
                        )
                        
                        tokenItems.append(OCRItem(text: word, box: tokenBox))
                        
                        let nextLocation = foundRange.location + foundRange.length
                        searchRange = NSRange(
                            location: nextLocation,
                            length: nsString.length - nextLocation
                        )
                    }
                }
            }
            
            return OCRSplitResult(blocks: blockItems, tokens: tokenItems)
            
        } catch {
            print("OCR error:", error)
            return OCRSplitResult(blocks: [], tokens: [])
        }
    }