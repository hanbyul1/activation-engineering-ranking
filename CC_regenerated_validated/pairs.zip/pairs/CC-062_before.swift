
    private func extractDirectUsage(
        _ rows: [OCRRow]
    ) -> Double? {

        for row in rows {
            let upper = row.fullText.uppercased()

            if upper.contains("USAGE") &&
               (upper.contains("MCF") || upper.contains("THERM") || upper.contains("KWH")) {

                let values = row.fullText.matches(for: #"\d+(\.\d+)?"#)
                    .compactMap { Double($0[0]) }

                if let best = values.max(), best > 0 {
                    return best
                }
            }
        }

        for row in rows {
            let upper = row.fullText.uppercased()

            if upper.contains("TOTAL METERED") {
                let values = row.fullText.matches(for: #"\d+(\.\d+)?"#)
                    .compactMap { Double($0[0]) }

                if let best = values.max(), best > 0 {
                    return best
                }
            }
        }

        return nil
    }