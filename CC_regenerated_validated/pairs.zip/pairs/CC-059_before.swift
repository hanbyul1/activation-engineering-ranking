
    private func mapBioToRole(_ bio: BioGroup) -> IngredientRole {
        switch bio {
        case .grain: return .carbSource
        case .legume: return .proteinSource          // legumes = protein-dominant mixed macro
        case .nutSeed: return .fatSource
        case .fruit: return .fruitSugar
        case .vegetable: return .vegetableFiber
        case .dairy: return .dairy
        case .beverage: return .beverage
        case .sweetener: return .sweetener
        case .seasoning: return .seasoning
        case .additive: return .additive
        case .meatFishEgg: return .proteinSource
        case .unknown: return .unknown
        }
    }