    
    private func isLoosePartNumber(_ text: String) -> Bool {
        let upper = text.uppercased()

        let hasLetter = upper.range(of: #"[A-Z]"#, options: .regularExpression) != nil
        let hasDigit  = upper.range(of: #"\d"#, options: .regularExpression) != nil

        guard upper.count >= 5 && upper.count <= 20 else { return false }

        let allowedChars = upper.range(of: #"^[A-Z0-9\*\-]+$"#, options: .regularExpression) != nil

        let isGarbage =
            upper.contains("TOTAL") ||
            upper.contains("LABOR") ||
            upper.contains("PARTS") ||
            upper.contains("ENGINE") ||
            upper.contains("CASH") ||
            upper.contains("DATE")

        return hasLetter && hasDigit && allowedChars && !isGarbage
    }