private func extractAddressFromRows(_ rows: [OCRRow]) -> String? {
    return extractAddressFromRowsCore(rows)
}


    private func extractAddressFromRowsCore(_ rows: [OCRRow]) -> String? {

        for i in 0..<rows.count {

            let text = rows[i].fullText.uppercased()

            // 🔥 ONLY trust CURRENT RESIDENT or SERVICE ADDRESS
            if text.contains("CURRENT RESIDENT") ||
               text.contains("SERVICE ADDRESS") {

                var parts: [String] = []

                for j in (i+1)..<min(i+4, rows.count) {

                    let raw = rows[j].fullText
                    let upper = raw.uppercased()

                    // 🔥 HARD FILTER (critical)
                    if upper.contains("ACCOUNT") ||
                       upper.contains("MAIL") ||
                       upper.contains("POSTAGE") ||
                       upper.contains("SECTION") ||
                       upper.contains("CYCLE") {
                        continue
                    }

                    parts.append(raw)
                }

                // 🔥 join + clean garbage (e.g., -22.70)
                let joined = parts.joined(separator: ", ")

                let cleaned = joined.replacingOccurrences(
                    of: #"-\d+\.\d+"#,
                    with: "",
                    options: .regularExpression
                )

                return cleaned.trimmingCharacters(in: .whitespaces)
            }
        }

        return nil
    }