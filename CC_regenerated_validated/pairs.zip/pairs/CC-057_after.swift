private func fetchLatestBloodPressure() async -> (Double?, Double?) {
    return fetchLatestBloodPressureCore()
}


    private func fetchLatestBloodPressureCore() async -> (Double?, Double?) {
        guard
            let systolicType = HKObjectType.quantityType(forIdentifier: .bloodPressureSystolic),
            let diastolicType = HKObjectType.quantityType(forIdentifier: .bloodPressureDiastolic)
        else {
            return (nil, nil)
        }

        async let systolic: Double? = withCheckedContinuation { continuation in
            let query = HKSampleQuery(
                sampleType: systolicType,
                predicate: nil,
                limit: 1,
                sortDescriptors: [
                    NSSortDescriptor(
                        key: HKSampleSortIdentifierEndDate,
                        ascending: false
                    )
                ]
            ) { _, samples, _ in
                let value = (samples?.first as? HKQuantitySample)?
                    .quantity
                    .doubleValue(for: .millimeterOfMercury())
                continuation.resume(returning: value)
            }
            healthStore.execute(query)
        }

        async let diastolic: Double? = withCheckedContinuation { continuation in
            let query = HKSampleQuery(
                sampleType: diastolicType,
                predicate: nil,
                limit: 1,
                sortDescriptors: [
                    NSSortDescriptor(
                        key: HKSampleSortIdentifierEndDate,
                        ascending: false
                    )
                ]
            ) { _, samples, _ in
                let value = (samples?.first as? HKQuantitySample)?
                    .quantity
                    .doubleValue(for: .millimeterOfMercury())
                continuation.resume(returning: value)
            }
            healthStore.execute(query)
        }

        return await (systolic, diastolic)
    }