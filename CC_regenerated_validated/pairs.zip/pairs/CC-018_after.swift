private func matchesSubsystem(
        _ part: String,
        _ subsystem: String,
        allowElectrical: Bool
    ) -> Bool {
    return matchesSubsystemCore(part, subsystem, allowElectrical)
}

    
    private func matchesSubsystemCore(
        _ part: String,
        _ subsystem: String,
        allowElectrical: Bool
    ) -> Bool {

        let lower = part.lowercased()

        switch subsystem {

        case "fuel":
            if allowElectrical {
                return lower.contains("fuel")
                    || lower.contains("injector")
                    || lower.contains("regulator")
                    || lower.contains("rail")
                    || lower.contains("wiring")
                    || lower.contains("connector")
                    || lower.contains("module")
            } else {
                return lower.contains("fuel")
                    || lower.contains("injector")
                    || lower.contains("regulator")
                    || lower.contains("rail")
            }

        case "cooling":
            return lower.contains("radiator")
                || lower.contains("coolant")
                || lower.contains("thermostat")
                || lower.contains("water pump")

        case "air":
            return lower.contains("air")
                || lower.contains("intake")
                || lower.contains("maf")
                || lower.contains("sensor")
                || lower.contains("throttle")
                || lower.contains("vacuum")

        case "exhaust":
            return lower.contains("egr")
                || lower.contains("exhaust")
                || lower.contains("oxygen")
                || lower.contains("o2")
                || lower.contains("sensor")

        case "evap":
            return lower.contains("evap")

        default:
            return true
        }
    }