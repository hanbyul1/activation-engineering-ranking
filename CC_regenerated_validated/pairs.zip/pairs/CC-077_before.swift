
    private func extractVehicle(from text: String) -> Vehicle? {

        let lines = text.components(separatedBy: .newlines)

        var model: String?
        var vin: String?

        for line in lines {

            let upper = line.uppercased()

            // 🔹 Extract model (Vehicle: Volt)
            if upper.contains("VEHICLE:") {
                let parts = line.components(separatedBy: ":")
                if parts.count > 1 {
                    model = parts[1].trimmingCharacters(in: .whitespaces)
                }
            }

            // 🔹 Extract VIN
            if vin == nil {
                vin = extractVIN(from: line)
            }
        }

        // 🔥 KEY: allow partial info (DO NOT require year/make)
        if model == nil && vin == nil {
            return nil
        }

        return Vehicle(
            year: "",        // unknown
            make: "",        // DO NOT hardcode
            model: model ?? "",
            trim: nil,
            vin: vin
        )
    }