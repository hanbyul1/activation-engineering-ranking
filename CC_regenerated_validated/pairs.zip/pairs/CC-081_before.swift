    public func lookupIngredientForEdit(_ input: String) -> IngredientInfo? {

        let tokens = normalizeIngredientTokens(input)
        guard !tokens.isEmpty else { return nil }

        let db = calorieDB

        // 🔹 normalize lookup (parseIngredientsOptimized와 동일)
        let lookup: [String: String] = db.keys.reduce(into: [:]) { dict, key in
            let n = normalizeKey(key)
            dict[n] = key
            if n.hasSuffix("s") {
                dict[String(n.dropLast())] = key
            }
        }

        // 🅰️ exact two-word
        if tokens.count >= 2 {
            for i in 0..<(tokens.count - 1) {
                let two = "\(tokens[i]) \(tokens[i+1])"
                if let dbKey = lookup[two], let info = db[dbKey] {
                    return info
                }
            }
        }

        // 🅱️ second-word fallback (🔥 parseIngredientsOptimized 핵심)
        for w in tokens {
            if let pickedTwo = resolveTwoWordBySecond(w) {
                let norm = normalizeKey(pickedTwo)
                if let dbKey = lookup[norm], let info = db[dbKey] {
                    return info
                }
            }
        }

        // 🅲 single-word
        for w in tokens {
            if let dbKey = lookup[w], let info = db[dbKey] {
                return info
            }
        }

        return nil
    }