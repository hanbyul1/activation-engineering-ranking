
    private func loadHealthData() {
        guard HKHealthStore.isHealthDataAvailable() else { return }

        // ✅ 수동 override 중이면 HealthKit 쿼리 결과로 flags 바꾸면 안 됨
        guard isHealthKitEnabled && !isUsingManualOverrides else { return }

        print("HKM Load: Starting data queries...")

        let ninetyDaysAgo = Calendar.current.date(byAdding: .day, value: -90, to: Date())
        let predicate = HKQuery.predicateForSamples(
            withStart: ninetyDaysAgo,
            end: Date(),
            options: .strictEndDate
        )

        // --- Blood Pressure ---
        if let systolicType = HKObjectType.quantityType(forIdentifier: .bloodPressureSystolic) {

            let bpQuery = HKSampleQuery(
                sampleType: systolicType,
                predicate: predicate,
                limit: HKObjectQueryNoLimit,
                sortDescriptors: nil
            ) { [weak self] _, samples, error in
                guard let self,
                      let samples = samples as? [HKQuantitySample],
                      error == nil else { return }

                // 기존 기준 유지(여긴 130이었지만, 최종 flags는 refreshHealthData 기준으로 맞춰짐)
                let unit = HKUnit.millimeterOfMercury()
                let hasHighBP = samples.contains {
                    $0.quantity.doubleValue(for: unit) > 130
                }

                DispatchQueue.main.async {
                    // ✅ 수동 override가 켜지면 무시
                    guard self.isHealthKitEnabled && !self.isUsingManualOverrides else { return }
                    self.updateHealthFlags(
                        diabetes: self.hasDiabetes,
                        hypertension: hasHighBP
                    )
                }
            }

            healthStore.execute(bpQuery)
        }

        // --- Glucose ---
        if let glucoseType = HKObjectType.quantityType(forIdentifier: .bloodGlucose) {

            let glucoseQuery = HKSampleQuery(
                sampleType: glucoseType,
                predicate: predicate,
                limit: HKObjectQueryNoLimit,
                sortDescriptors: nil
            ) { [weak self] _, samples, error in
                guard let self,
                      let samples = samples as? [HKQuantitySample],
                      error == nil else { return }

                let mg = HKUnit.gramUnit(with: .milli)
                let dL = HKUnit.literUnit(with: .deci)
                let unit = mg.unitDivided(by: dL)

                let hasHighGlucose = samples.contains {
                    $0.quantity.doubleValue(for: unit) > 126
                }

                DispatchQueue.main.async {
                    // ✅ 수동 override가 켜지면 무시
                    guard self.isHealthKitEnabled && !self.isUsingManualOverrides else { return }
                    self.updateHealthFlags(
                        diabetes: hasHighGlucose,
                        hypertension: self.hasHypertension
                    )
                }
            }

            healthStore.execute(glucoseQuery)
        }
    }