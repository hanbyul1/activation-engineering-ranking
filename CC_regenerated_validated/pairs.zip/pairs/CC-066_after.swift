func checkMenuText(
        menuText: String,
        healthProfile: HealthProfile
    ) -> [AlertCardData] {
    return checkMenuTextCore(menuText, healthProfile)
}

    func checkMenuTextCore(
        menuText: String,
        healthProfile: HealthProfile
    ) -> [AlertCardData] {
        var alerts: [AlertCardData] = []
        
        // ----------------------------------------------------
        // 1. HealthKit 비활성화 시 일반 경고
        // ----------------------------------------------------
        if !healthProfile.isHealthKitEnabled {
            // (추후 여기에 '고지방', '고나트륨' 키워드에 대한 일반 경고 로직 추가 예정)
        }
        
        // ----------------------------------------------------
        // 2. HealthKit 기반 개인 맞춤 경고 (키워드 검색)
        // ----------------------------------------------------
        let lowercasedText = menuText.lowercased()
        
        if healthProfile.hasDiabetes {
            // 당뇨 키워드 예시: sugar, carb, sweet, syrup, fried
            if lowercasedText.contains("sugar") || lowercasedText.contains("sweet") || lowercasedText.contains("syrup") || lowercasedText.contains("dessert") {
                alerts.append(AlertCardData(
                    icon: "drop.triangle.fill",
                    title: "🔔 HealthKit Warning: High Sugar Risk",
                    message: "Based on your diabetes profile, this menu item likely contains high levels of sugar/carbohydrates.",
                    color: .red
                ))
            }
        }
        
        if healthProfile.hasHypertension {
            // 고혈압 키워드 예시: salt, sodium, fried, sauce, soup, brine
            if lowercasedText.contains("salt") || lowercasedText.contains("sodium") || lowercasedText.contains("soup") || lowercasedText.contains("brine") || lowercasedText.contains("sauce") {
                alerts.append(AlertCardData(
                    icon: "heart.fill",
                    title: "🚫 HealthKit Warning: High Sodium Risk",
                    message: "Based on your hypertension profile, this menu item may be high in sodium (e.g., broth or seasoning).",
                    color: .red
                ))
            }
        }
        
        // ----------------------------------------------------
        // 3. 기타 공통 경고 (Halal 등)
        // ----------------------------------------------------
        // Menu Scan은 성분 텍스트가 정확하지 않을 수 있으므로,
        // MenuCal 프로젝트의 별도 Menu/Dish 파싱 로직에 맡기는 것이 더 정확합니다.
        // 현재는 HealthKit 관련 키워드 검색만 수행합니다.
        
        return alerts
    }