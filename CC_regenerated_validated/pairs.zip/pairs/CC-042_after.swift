func debugPrintLatestValues() {
    debugPrintLatestValuesCore()
}


    func debugPrintLatestValuesCore() {

        guard HKHealthStore.isHealthDataAvailable() else {
            print("❌ HealthKit not available")
            return
        }

        print("========== 🧪 HealthKit REAL VALUES ==========")

        // -------- Glucose --------
        if let glucoseType = HKObjectType.quantityType(forIdentifier: .bloodGlucose) {

            let query = HKSampleQuery(
                sampleType: glucoseType,
                predicate: nil,
                limit: 1,
                sortDescriptors: [NSSortDescriptor(key: HKSampleSortIdentifierEndDate, ascending: false)]
            ) { _, samples, _ in

                if let sample = samples?.first as? HKQuantitySample {
                    let mg = HKUnit.gramUnit(with: .milli)
                    let dL = HKUnit.literUnit(with: .deci)
                    let unit = mg.unitDivided(by: dL)

                    let value = sample.quantity.doubleValue(for: unit)
                    print("🩸 Glucose:", value, "mg/dL @", sample.endDate)
                } else {
                    print("🩸 Glucose: No data")
                }
            }

            healthStore.execute(query)
        }

        // -------- Blood Pressure --------
        if let systolicType = HKObjectType.quantityType(forIdentifier: .bloodPressureSystolic),
           let diastolicType = HKObjectType.quantityType(forIdentifier: .bloodPressureDiastolic) {

            let unit = HKUnit.millimeterOfMercury()

            let systolicQuery = HKSampleQuery(
                sampleType: systolicType,
                predicate: nil,
                limit: 1,
                sortDescriptors: [NSSortDescriptor(key: HKSampleSortIdentifierEndDate, ascending: false)]
            ) { _, samples, _ in

                if let sample = samples?.first as? HKQuantitySample {
                    let value = sample.quantity.doubleValue(for: unit)
                    print("🫀 Systolic BP:", value, "mmHg @", sample.endDate)
                } else {
                    print("🫀 Systolic BP: No data")
                }
            }

            let diastolicQuery = HKSampleQuery(
                sampleType: diastolicType,
                predicate: nil,
                limit: 1,
                sortDescriptors: [NSSortDescriptor(key: HKSampleSortIdentifierEndDate, ascending: false)]
            ) { _, samples, _ in

                if let sample = samples?.first as? HKQuantitySample {
                    let value = sample.quantity.doubleValue(for: unit)
                    print("🫀 Diastolic BP:", value, "mmHg @", sample.endDate)
                } else {
                    print("🫀 Diastolic BP: No data")
                }

                print("============================================")
            }

            healthStore.execute(systolicQuery)
            healthStore.execute(diastolicQuery)
        }
    }