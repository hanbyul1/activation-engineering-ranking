static func generate(for signal: NutritionSignal) -> (String, String) {
    return generateCore(signal)
}


    static func generateCore(for signal: NutritionSignal) -> (String, String) {

        switch signal {

        case .highCarbs(let severity):
            return pick(
                title: "Carbohydrate Intake",
                from: Templates.highCarbs[severity]
                    ?? Templates.highCarbs[.moderate]
                    ?? ["Carbohydrate intake may need attention."]
            )

        case .highSodium:
            return pick(
                title: "Sodium Level",
                from: Templates.highSodium
            )

        case .ultraProcessed:
            return pick(
                title: "Processing Level",
                from: Templates.ultraProcessed
            )

        case .lowProtein:
            return pick(
                title: "Protein Balance",
                from: Templates.lowProtein
            )

        case .frequentHighCalories(let severity):
            return pick(
                title: "Calorie Pattern",
                from: Templates.highCalorieFrequency[severity]
                    ?? Templates.highCalorieFrequency[.moderate]
                    ?? ["High-calorie choices appear in your recent history."]
            )

        case .highAverageCalories(let severity):
            return pick(
                title: "Average Intake",
                from: Templates.averageCalories[severity]
                    ?? Templates.averageCalories[.moderate]
                    ?? ["Average calorie intake appears elevated."]
            )

        case .irregularTracking:
            return pick(
                title: "Tracking Consistency",
                from: Templates.tracking
            )
        }
    }