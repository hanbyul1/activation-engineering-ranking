private func findAmountNearLabelFlexible(
        keywordSets: [[String]],
        items: [OCRItem]
    ) -> String? {
    return findAmountNearLabelFlexibleCore(keywordSets, items)
}

    
    private func findAmountNearLabelFlexibleCore(
        keywordSets: [[String]],
        items: [OCRItem]
    ) -> String? {

        for keywords in keywordSets {

            if let anchor = findLabelAnchorFlexible(keywords: keywords, items: items) {

                // 🔥 핵심: LATE 라벨이면 스킵
                let anchorText = items.filter {
                    abs($0.box.midY - anchor.box.midY) < 0.02
                }.map { $0.text.uppercased() }.joined(separator: " ")

                if anchorText.contains("LATE") {
                    continue
                }

                let candidates = items.filter {
                    $0.text
                        .replacingOccurrences(of: ",", with: "")
                        .range(of: #"\b\d{1,6}\.\d{2}\b"#, options: .regularExpression) != nil
                }

                var best: OCRItem?
                var bestScore = CGFloat.greatestFiniteMagnitude

                for c in candidates {

                    let dx = abs(c.box.midX - anchor.box.midX)
                    let dy = abs(c.box.midY - anchor.box.midY)

                    if dx < 0.4 && dy < 0.18 {

                        let score = dx + dy

                        if score < bestScore {
                            bestScore = score
                            best = c
                        }
                    }
                }

                if let result = best?.text {
                    return result.replacingOccurrences(of: "$", with: "")
                }
            }
        }

        return nil
    }