private func reconstructBrokenMonthDate(from tokens: [String]) -> String? {
    return reconstructBrokenMonthDateCore(tokens)
}

 
    private func reconstructBrokenMonthDateCore(from tokens: [String]) -> String? {
        let months = [
            "JANUARY","FEBRUARY","MARCH","APRIL","MAY","JUNE",
            "JULY","AUGUST","SEPTEMBER","OCTOBER","NOVEMBER","DECEMBER",
            "JAN","FEB","MAR","APR","MAY","JUN","JUL","AUG","SEP","OCT","NOV","DEC"
        ]

        // 월 토큰 찾기
        for i in 0..<tokens.count {
            let rawMonth = tokens[i]
                .replacingOccurrences(of: "_", with: "")
                .uppercased()

            guard months.contains(where: { rawMonth.hasPrefix($0) || $0.hasPrefix(rawMonth) }) else {
                continue
            }

            var day: String?
            var year: String?

            // 월 뒤 5개 토큰 정도 안에서 day/year 찾기
            let end = min(i + 6, tokens.count)

            for j in (i + 1)..<end {
                let cleaned = tokens[j].replacingOccurrences(of: ",", with: "")

                if day == nil,
                   cleaned.range(of: #"^\d{1,2}$"#, options: .regularExpression) != nil,
                   let d = Int(cleaned),
                   d >= 1, d <= 31 {
                    day = cleaned
                    continue
                }

                if year == nil,
                   cleaned.range(of: #"^\d{4}$"#, options: .regularExpression) != nil,
                   let y = Int(cleaned),
                   y >= 2000, y <= 2100 {
                    year = cleaned
                }
            }

            if let day, let year {
                let month = rawMonth.prefix(1) + rawMonth.dropFirst().lowercased()
                return "\(month) \(day), \(year)"
            }
        }

        return nil
    }