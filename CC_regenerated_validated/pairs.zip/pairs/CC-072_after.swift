func lookup(barcode: String) -> Product? {
    return lookupCore(barcode)
}


    func lookupCore(barcode: String) -> Product? {
        let rawCode = barcode.trimmingCharacters(in: .whitespacesAndNewlines)
        func trimLeadingZeros(_ s: String) -> String {
            let trimmed = s.drop(while: { $0 == "0" })
            return trimmed.isEmpty ? "0" : String(trimmed)
        }
        let cleaned = trimLeadingZeros(rawCode)

        // ✅ [확장된 쿼리]
        let query = """
            SELECT code, product_name, brand,
                   energy_kcal_100g, fat_100g, saturated_fat_100g,
                   carbs_100g, sugars_100g, fiber_100g, proteins_100g,
                   salt_100g, sodium_100g,
                   serving_size, ingredients_text, allergens, additives_tags,
                   is_vegan, is_vegetarian, is_palm_oil_free,
                   nutrition_grade, nova_group
            FROM products
            WHERE code = ? LIMIT 1;
        """

        var stmt: OpaquePointer?

        func runQuery(_ codeToSearch: String) -> Product? {
            if sqlite3_prepare_v2(db, query, -1, &stmt, nil) != SQLITE_OK {
                print("❌ SQL Error")
                return nil
            }

            sqlite3_bind_text(stmt, 1, codeToSearch, -1, SQLITE_TRANSIENT)

            var found: Product?
            
            if sqlite3_step(stmt) == SQLITE_ROW {
                // Helper to safely get string
                func getString(_ col: Int) -> String {
                    guard let ptr = sqlite3_column_text(stmt, Int32(col)) else { return "" }
                    return String(cString: ptr)
                }
                // Helper to safely get double
                func getDouble(_ col: Int) -> Double {
                    return sqlite3_column_double(stmt, Int32(col))
                }
                // Helper to get int
                func getInt(_ col: Int) -> Int {
                    return Int(sqlite3_column_int(stmt, Int32(col)))
                }

                found = Product(
                    code: getString(0),
                    name: getString(1),
                    brand: getString(2),
                    calories: getDouble(3),
                    fat: getDouble(4),
                    saturatedFat: getDouble(5),
                    carbs: getDouble(6),
                    sugars: getDouble(7),
                    fiber: getDouble(8),
                    protein: getDouble(9),
                    salt: getDouble(10),
                    sodium: getDouble(11),
                    servingSize: getString(12),
                    ingredientsText: getString(13),
                    allergens: getString(14),
                    additives: getString(15),
                    isVegan: getString(16),
                    isVegetarian: getString(17),
                    isPalmOilFree: getString(18),
                    nutriScore: getString(19),
                    novaGroup: getInt(20)
                )
                print("✅ Found match in DB: \(found!.name)")
            }

            sqlite3_finalize(stmt)
            return found
        }

        if let p = runQuery(rawCode) { return p }
        if cleaned != rawCode {
            if let p = runQuery(cleaned) { return p }
        }
        return nil
    }