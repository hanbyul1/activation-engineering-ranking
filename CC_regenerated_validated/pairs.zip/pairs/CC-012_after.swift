private func extractGasUsageWithUnit(
        _ rows: [OCRRow],
        fields: [String: String],
        patterns: [ExtractionUtilityPattern]
    ) -> (Double?, String?) {
    return extractGasUsageWithUnitCore(rows, fields, patterns)
}


    private func extractGasUsageWithUnitCore(
        _ rows: [OCRRow],
        fields: [String: String],
        patterns: [ExtractionUtilityPattern]
    ) -> (Double?, String?) {

        print("🔥 GAS USAGE EXTRACTION START")

        // 1순위: OCR field usage가 있고 unit이 gas 계열이면 우선 사용
        if let raw = fields["usage"],
           let parsed = parseUsage(raw) {

            let inferredUnit = inferUsageUnit(from: rows, patterns: patterns)

            if inferredUnit == "Mcf" || inferredUnit == "Therm" {
                print("✅ GAS using field usage:", parsed, inferredUnit ?? "nil")
                return (parsed, inferredUnit)
            }
        }

        // 2순위: "Usage: X Mcf" / "Total Metered Energy Use: X Mcf"
        for row in rows {
            let upper = row.fullText.uppercased()

            if upper.contains("USAGE") && (upper.contains("MCF") || upper.contains("THERM")) {
                let values = row.fullText.matches(for: #"\d+(\.\d+)?"#)
                    .compactMap { Double($0[0]) }
                    .filter { $0 > 0 && $0 < 500 }

                if let best = values.max() {
                    let unit = upper.contains("THERM") ? "Therm" : "Mcf"
                    print("✅ GAS usage from usage row:", best, unit)
                    return (best, unit)
                }
            }

            if upper.contains("TOTAL METERED") && (upper.contains("MCF") || upper.contains("THERM")) {
                let values = row.fullText.matches(for: #"\d+(\.\d+)?"#)
                    .compactMap { Double($0[0]) }
                    .filter { $0 > 0 && $0 < 500 }

                if let best = values.max() {
                    let unit = upper.contains("THERM") ? "Therm" : "Mcf"
                    print("✅ GAS usage from metered row:", best, unit)
                    return (best, unit)
                }
            }
        }

        // 3순위: gas 관련 row 전체에서 가장 타당한 값
        var candidates: [Double] = []

        for row in rows {
            let upper = row.fullText.uppercased()

            if upper.contains("MCF") || upper.contains("THERM") {
                let values = row.fullText.matches(for: #"\d+(\.\d+)?"#)
                    .compactMap { Double($0[0]) }
                    .filter { $0 > 0 && $0 < 500 }

                candidates.append(contentsOf: values)
            }
        }

        if let best = candidates.max() {
            print("✅ GAS fallback usage:", best)
            return (best, inferUsageUnit(from: rows, patterns: patterns) ?? "Mcf")
        }

        print("❌ GAS usage not found")
        return (nil, inferUsageUnit(from: rows, patterns: patterns))
    }