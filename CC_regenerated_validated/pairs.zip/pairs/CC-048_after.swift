func searchPart(partNumber: String) async throws -> (price: Double, url: String?, imageURL: String?) {
    return searchPartCore(partNumber)
}

    func searchPartCore(partNumber: String) async throws -> (price: Double, url: String?, imageURL: String?) {

        // 🔥 Ensure server is warm BEFORE first real request
        await ensureWarmed()

        let encoded = partNumber.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? partNumber
        let url = URL(string: "\(baseURL)/search?part=\(encoded)")!

        print("🌐 CALLING:", url.absoluteString)

        for attempt in 1...3 {
            do {
                let (data, response) = try await URLSession.shared.data(from: url)

                guard let http = response as? HTTPURLResponse, http.statusCode == 200 else {
                    throw URLError(.badServerResponse)
                }

                let json = try JSONSerialization.jsonObject(with: data) as! [String: Any]

                return (
                    json["price"] as? Double ?? 0,
                    json["url"] as? String,
                    json["imageURL"] as? String
                )

            } catch {
                print("⚠️ RETRY \(attempt):", error.localizedDescription)

                if attempt == 3 {
                    throw error
                }

                try await Task.sleep(nanoseconds: 1_000_000_000)
            }
        }

        throw URLError(.cannotConnectToHost)
    }