private func extractElectricUsageWithUnit(
        _ rows: [OCRRow],
        fields: [String: String],
        patterns: [ExtractionUtilityPattern]
    ) -> (Double?, String?) {
    return extractElectricUsageWithUnitCore(rows, fields, patterns)
}


    private func extractElectricUsageWithUnitCore(
        _ rows: [OCRRow],
        fields: [String: String],
        patterns: [ExtractionUtilityPattern]
    ) -> (Double?, String?) {

        print("⚡️ ELECTRIC USAGE EXTRACTION START")

        // 1순위: OCR field usage
        if let raw = fields["usage"],
           let parsed = parseUsage(raw) {

            let inferredUnit = inferUsageUnit(from: rows, patterns: patterns)

            // 🔥 ADD: sanity check
            let isSuspicious =
                parsed < 150 &&   // 너무 작은 값
                rows.contains { $0.fullText.contains("Usage (kWh)") } // table 존재

            if inferredUnit == "kWh" && !isSuspicious {
                print("✅ ELECTRIC using field usage:", parsed)
                return (parsed, inferredUnit)
            } else {
                print("⚠️ IGNORE OCR usage:", parsed)
            }
        }

        // =================================================
        // 🔥 [ADD] TABLE ROW 정확 추출 (비파괴)
        // =================================================
        for row in rows {

            let upper = row.fullText.uppercased()

            // "DATE USAGE COST AMOUNT" 헤더 다음 줄
            if upper.contains("USAGE") && upper.contains("KWH") {
                continue
            }

            let numbers = row.fullText.matches(for: #"\d+(\.\d+)?"#)
                .compactMap { Double($0[0]) }

            // 🔥 정확히 4개 구조: date usage cost amount
            if numbers.count == 4 {

                let usage = numbers[1]   // 👉 핵심

                if usage > 0 && usage < 100000 {
                    print("✅ ELECTRIC table usage:", usage)
                    return (usage, "kWh")
                }
            }
        }

        // =================================================
        // 3순위: KWH row 전체 fallback (FIXED)
        // =================================================
        var candidates: [Double] = []

        for row in rows {

            let upper = row.fullText.uppercased()

            // 🔥 반드시 KWH + 숫자 구조만 허용
            if upper.contains("KWH") {

                // ❌ 주소 / 계정 / 전화번호 필터
                if upper.contains("DR") ||
                   upper.contains("RD") ||
                   upper.contains("ST") ||
                   upper.contains("AVE") ||
                   upper.contains("ACCOUNT") {
                    continue
                }

                let values = row.fullText.matches(for: #"\d+(\.\d+)?"#)
                    .compactMap { Double($0[0]) }
                    .filter {
                        $0 > 100 &&        // 너무 작은 값 제거
                        $0 < 10000 &&      // 현실 범위
                        $0 != 540          // 🔥 임시 kill-switch (디버깅용)
                    }

                candidates.append(contentsOf: values)
            }
        }

        // 🔥 여기 핵심: max() 절대 금지
        if let best = candidates.sorted().last {
            print("✅ ELECTRIC fallback usage (filtered):", best)
            return (best, "kWh")
        }

        print("❌ ELECTRIC usage not found")
        return (nil, inferUsageUnit(from: rows, patterns: patterns))
    }