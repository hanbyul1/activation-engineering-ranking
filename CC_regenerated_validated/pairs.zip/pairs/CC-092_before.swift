
    func fetchRecipeNames(for type: CategoryType) async -> [String] {

        switch type {

        case .dishType:
            await DishTypeRecipeCache.shared.prepareIfNeeded()
            return DishTypeRecipeCache.shared.allRecipeNames()

        case .ingredient:
            await IngredientRecipeCache.shared.prepareIfNeeded()
            return IngredientRecipeCache.shared.allRecipeNames()

        case .cuisine:
            await CuisineRecipeCache.shared.prepareIfNeeded()
            return CuisineRecipeCache.shared.allRecipeNames()

        case .cookingMethod:
            await CookingRecipeCache.shared.prepareIfNeeded()
            return CookingRecipeCache.shared.allRecipeNames()

        case .diet:
            await DietRecipeCache.shared.prepareIfNeeded()
            return DietRecipeCache.shared.allRecipeNames()

        case .nutrition:
            await NutritionRecipeCache.shared.prepareIfNeeded()
            return NutritionRecipeCache.shared.allRecipeNames()

        case .occasion:
            await OccasionRecipeCache.shared.prepareIfNeeded()
            return OccasionRecipeCache.shared.allRecipeNames()

        case .popular:
            await PopularRecipeCache.shared.prepareIfNeeded()
            return PopularRecipeCache.shared.allRecipeNames()

        case .myRecipe:
            return []
        }
    }