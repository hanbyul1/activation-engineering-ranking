func encode(_ text: String) -> ([Int64], [Int64]) {
    return encodeCore(text)
}

    func encodeCore(_ text: String) -> ([Int64], [Int64]) {
        let cleaned = basicClean(text)

        let words = cleaned
            .split(whereSeparator: { $0.isWhitespace })
            .map { String($0) }

        var tokens: [String] = []
        for word in words {
            tokens.append(contentsOf: wordpieceTokenize(word))
        }

        // [CLS] + tokens + [SEP]
        var wordpieceTokens: [String] = [clsToken]
        wordpieceTokens.append(contentsOf: tokens)
        wordpieceTokens.append(sepToken)

        // id 변환
        var tokenIds: [Int64] = wordpieceTokens.map { token in
            Int64(vocab[token] ?? vocab[unkToken] ?? 0)
        }

        // 잘라내기 / 패딩
        if tokenIds.count > maxLength {
            tokenIds = Array(tokenIds.prefix(maxLength))
        }

        let padId = Int64(vocab[padToken] ?? 0)
        if tokenIds.count < maxLength {
            tokenIds.append(contentsOf: Array(repeating: padId,
                                              count: maxLength - tokenIds.count))
        }

        // attention mask: padding이 아닌 곳은 1, padding은 0
        var attentionMask = [Int64](repeating: 0, count: maxLength)
        for i in 0..<maxLength {
            if tokenIds[i] != padId {
                attentionMask[i] = 1
            }
        }

        return (tokenIds, attentionMask)
    }