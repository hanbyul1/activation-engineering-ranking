static func saveToPhotos(_ image: UIImage) async throws -> String {
    return saveToPhotosCore(image)
}

    static func saveToPhotosCore(_ image: UIImage) async throws -> String {
        let status = PHPhotoLibrary.authorizationStatus(for: .addOnly)
        if status == .notDetermined {
            let newStatus = await PHPhotoLibrary.requestAuthorization(for: .addOnly)
            if newStatus != .authorized && newStatus != .limited {
                throw FoodPhotoSaveError.notAuthorized
            }
        } else if status != .authorized && status != .limited {
            throw FoodPhotoSaveError.notAuthorized
        }

        return try await withCheckedThrowingContinuation { cont in
            var localIdentifier: String?

            PHPhotoLibrary.shared().performChanges({
                let request = PHAssetChangeRequest.creationRequestForAsset(from: image)
                localIdentifier = request.placeholderForCreatedAsset?.localIdentifier
            }, completionHandler: { success, error in
                if let error {
                    cont.resume(throwing: error)
                    return
                }
                guard success, let id = localIdentifier else {
                    cont.resume(throwing: FoodPhotoSaveError.failedToCreateAsset)
                    return
                }
                cont.resume(returning: id)
            })
        }
    }