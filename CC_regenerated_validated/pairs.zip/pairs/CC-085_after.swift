private func processFinalIngredients(from texts: [String]) -> [String] {
    return processFinalIngredientsCore(texts)
}


    private func processFinalIngredientsCore(from texts: [String]) -> [String] {
        var results: Set<String> = []

        for line in texts {
            let trimmed = line.trimmingCharacters(in: .whitespacesAndNewlines)
            if trimmed.isEmpty { continue }

            // 1) 헤더 제거
            if isHeaderLine(trimmed) { continue }

            // ✅ 2) 괄호로 시작하는 라인 조건부 drop
            let t0 = trimmed.trimmingCharacters(in: .whitespaces)
            let lowerT0 = t0.lowercased()

            if t0.hasPrefix("(") {

                // 너무 긴 괄호 설명 라인
                if t0.count > 12 {
                    continue
                }

                // 전형적인 설명 키워드 포함
                let explanationKeywords = [
                    "from",
                    "elemental",
                    "standardized",
                    "equivalent",
                    "as ",
                    "providing",
                    "yielding"
                ]

                if explanationKeywords.contains(where: { lowerT0.contains($0) }) {
                    continue
                }

                // 숫자/용량 정보 포함 시 drop
                if lowerT0.range(of: #"\d"#, options: .regularExpression) != nil {
                    continue
                }
            }

            // 3) 숫자/단위만 있는 라인 제거
            if isGarbageToken(trimmed) { continue }

            var cleaned = trimmed

            // 먼저 하이픈을 공백으로 변환
            cleaned = cleaned.replacingOccurrences(of: "-", with: " ")
            // ✅ 4) 괄호 안 내용 전체 제거 (generic rule: 케이스별 금지)
            cleaned = cleaned.replacingOccurrences(
                of: #"\(.*?\)"#,
                with: "",
                options: .regularExpression
            )

            // 5) 숫자/단위 제거
            // 🔥 숫자 + 단위 패턴만 제거 (성분 내부 숫자 유지)
            cleaned = cleaned.replacingOccurrences(
                of: #"\b\d+(\.\d+)?\s*(mg|g|mcg|µg|iu|%|cfu|billion)\b"#,
                with: "",
                options: [.regularExpression, .caseInsensitive]
            )

            // 6) OCR 기호 제거
            cleaned = cleaned
                .replacingOccurrences(of: "®", with: "")
                .replacingOccurrences(of: "™", with: "")
                .replacingOccurrences(of: "†", with: "")
                .replacingOccurrences(of: "*", with: "")

            // 7) 알파벳 + 공백만 유지
            cleaned = cleaned.replacingOccurrences(
                of: #"[^a-zA-Z0-9\s]"#,
                with: "",
                options: .regularExpression
            )

            // 8) 공백 정리
            cleaned = cleaned
                .replacingOccurrences(of: #"\s+"#, with: " ", options: .regularExpression)
                .trimmingCharacters(in: .whitespacesAndNewlines)

            if cleaned.count < 3 { continue }

            if cleaned.count < 3 { continue }

            // 10) 너무 긴 문장 제거
            if cleaned.split(separator: " ").count >= 7 { continue }

            results.insert(cleaned.capitalized)
        }

        return Array(results).sorted()
    }