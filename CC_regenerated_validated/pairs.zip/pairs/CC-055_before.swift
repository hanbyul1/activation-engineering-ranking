
    public func displayName(for type: InteractionType) -> String {
        switch type {

        case .absorptionInterference:
            return "Absorption-Related Observation (Reported): Reporting patterns suggest a potential association related to gastrointestinal absorption processes; causality has not been established"

        case .metabolicCompetition:
            return "Metabolic Pathway Observation (Reported): Reporting patterns suggest a possible association involving shared metabolic processing; no direct biological confirmation is implied"

        case .transporterEffect:
            return "Transport-Related Observation (Reported): Some reports describe concurrent involvement of cellular transport processes; evidence does not establish a direct effect"

        case .bindingEffect:
            return "Binding-Related Observation (Reported): Reports describe possible concurrent chemical or physical interaction patterns; functional impact remains uncertain"

        case .pharmacodynamicOverlap:
            return "Physiological Effect Overlap (Reported): Substances have been described in contexts involving similar physiological domains; this does not imply additive or harmful outcomes"

        case .reportedAdverseAssociation:
            return "Reporting Association (FAERS): These substances have been reported together in adverse event reporting data; reporting frequency does not demonstrate causation"

        case .observationalOnly:
            return "Observational Association (Literature): Substances have appeared together in scientific literature without confirmed interaction mechanisms"

        case .mechanismNotInvestigated:
            return "Mechanism Not Evaluated (Reported): Reports describe co-occurrence, but no biological pathway assessment was identified"

        case .hypothesizedMechanism:
            return "Hypothesized Biological Association: A possible mechanism has been proposed in literature; experimental confirmation may be limited"

        case .multifactorialEffect:
            return "Multifactorial Context (Reported): Observations may involve multiple biological domains; no single defined pathway has been established"

        case .conflictingEvidence:
            return "Inconsistent Reports: Available literature describes differing interpretations or findings; no unified conclusion is established"

        case .mechanismNotFullyCharacterized:
            return "Limited Mechanistic Detail (Reported): Interaction has been described, but underlying biological processes remain incompletely characterized"
        }
    }