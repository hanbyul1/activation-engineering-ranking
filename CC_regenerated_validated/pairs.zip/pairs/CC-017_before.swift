    
    private func processComponents(_ componentsInput: [String], for code: OBDCode) async {

        let components = Array(Set(componentsInput)).prefix(5).map { $0 }

        print("🔧 FINAL RECOMMENDED PARTS:", components)

        guard !components.isEmpty else {
            isLoading = false
            errorMessage = "Unable to infer repair estimate."
            return
        }

        let maxAge: TimeInterval = 60 * 60 * 24
        var loaded: [DiagnosticPartSuggestion] = []

        // ============================================================
        // 🔥 EBAY SEARCH LOOP
        // ============================================================
        for component in components {

            if Task.isCancelled { break }

            // ========================================================
            // 🔥 DIAGNOSTIC → MARKETPLACE MAPPING (FIXED DESIGN)
            // ========================================================
            let mappedComponent: String
            switch component.lowercased() {
            case "fuel rail":
                print("⚠️ Mapping Fuel Rail → Fuel Injector")
                mappedComponent = "fuel injector"
            default:
                mappedComponent = component
            }

            let lower = mappedComponent.lowercased()

            // ========================================================
            // 🔥 SEARCH NORMALIZATION
            // ========================================================
            let searchComponent: String
            switch lower {
            case "wiring harness":
                searchComponent = "engine wiring harness"
            case "connector":
                searchComponent = "sensor connector"
            case "oxygen sensor":
                searchComponent = "o2 sensor"
            case "mass air flow sensor":
                searchComponent = "maf sensor"
            case "fuel pump":
                searchComponent = "fuel pump assembly"
            case "fuel pressure regulator":
                searchComponent = "fuel pressure regulator oem"
            case "fuel pressure sensor":
                searchComponent = "fuel pressure sensor replacement"
            case "fuel injector":
                searchComponent = "fuel injector oem"
            default:
                searchComponent = mappedComponent
            }

            do {
                // ====================================================
                // 🔥 QUERY STRATEGY
                // ====================================================
                let queries = [
                    "\(searchComponent)",
                    "\(searchComponent) replacement",
                    "\(searchComponent) oem",
                    "\(searchComponent) auto part"
                ]

                var result: (price: Double, url: String?, imageURLs: [String], title: String?) =
                    (0, nil, [], nil)

                var usedQuery = ""
                var foundValidResult = false

                for q in queries {
                    print("🔍 TRY:", q)

                    result = try await ebayService.searchKeyword(q)
                    usedQuery = q

                    if let title = result.title?.lowercased(),
                       title.contains("for parts") {
                        continue
                    }

                    if !result.imageURLs.isEmpty {
                        foundValidResult = true
                        break
                    }
                }

                if !foundValidResult {
                    print("⚠️ NO VALID RESULT:", component)
                    continue
                }

                let cacheKey = "suggestion_\(usedQuery.lowercased())"

                // =========================
                // CACHE HIT
                // =========================
                if let cached = await cache.getIfFresh(cacheKey, maxAge: maxAge),
                   cached.price != nil || cached.imageURL != nil {

                    loaded.append(
                        DiagnosticPartSuggestion(
                            code: code.code,
                            componentName: component, // keep original diagnostic label
                            searchQuery: usedQuery,
                            estimatedPrice: cached.price,
                            marketURL: cached.url,
                            imageURL: cached.imageURL,
                            title: nil,
                            image: nil
                        )
                    )
                    continue
                }

                // =========================
                // SAVE RESULT
                // =========================
                let price = result.price > 0 ? result.price : nil

                await cache.set(
                    cacheKey,
                    value: CachedPrice(
                        price: price,
                        url: result.url,
                        imageURL: result.imageURLs.first,
                        timestamp: Date()
                    )
                )

                loaded.append(
                    DiagnosticPartSuggestion(
                        code: code.code,
                        componentName: component,
                        searchQuery: usedQuery,
                        estimatedPrice: price,
                        marketURL: result.url,
                        imageURL: result.imageURLs.first,
                        title: result.title,
                        image: nil
                    )
                )

                try await Task.sleep(nanoseconds: 500_000_000)

            } catch {
                print("⚠️ FAILED:", component, error.localizedDescription)
            }
        }

        // ============================================================
        // 🔥 UI UPDATE
        // ============================================================
        suggestions = loaded

        // ============================================================
        // 🔥 IMAGE LOADING
        // ============================================================
        for i in suggestions.indices {

            let key = ImageCache.Key.query(suggestions[i].searchQuery)

            if let cached = ImageCache.shared.get(key) {
                suggestions[i].image = cached
                continue
            }

            if let url = suggestions[i].imageURL {
                let image = await ImageLoader.shared.load(url)

                if let image {
                    suggestions[i].image = image
                    ImageCache.shared.set(key, image: image)
                    print("🌐 IMAGE DOWNLOADED")
                }
            }
        }

        isLoading = false
    }