private func fallbackPartListWithoutPrice(from tokens: [OCRToken]) -> [Part] {
    return fallbackPartListWithoutPriceCore(tokens)
}

    
    private func fallbackPartListWithoutPriceCore(from tokens: [OCRToken]) -> [Part] {
        print("⚠️ DETECTING PART LIST (NO PRICE TABLE)")

        let sorted = tokens.sorted { $0.boundingBox.midY < $1.boundingBox.midY }

        func isStellantisPart(_ text: String) -> Bool {
            let upper = text.uppercased()
            return upper.range(of: #"^\d{7,8}[A-Z]{2}$"#, options: .regularExpression) != nil
        }

        // 🔥 STEP 1: collect part tokens
        let partTokens = sorted.filter { isStellantisPart($0.text) }

        // 🔥 STEP 2: collect description tokens (exclude obvious headers/noise)
        let descriptionTokens = sorted.filter {
            let upper = $0.text.uppercased()

            if isStellantisPart(upper) { return false }

            // ❌ aggressively remove noise sections
            if upper.contains("SALES") { return false }
            if upper.contains("CODE") { return false }
            if upper.contains("NOTE") { return false }
            if upper.contains("REPAIR") { return false }
            if upper.contains("PROCEDURE") { return false }
            if upper.contains("STEP") { return false }

            // ❌ remove generic/common words
            if ["THE","AND","TO","OF","IN","FOR","THIS","IS","ARE","ANY"].contains(upper) {
                return false
            }

            // ✅ only allow strong part-like words (capitalize + length constraint)
            if upper.range(of: #"^[A-Z][A-Z]+$"#, options: .regularExpression) != nil {
                return upper.count >= 5 && upper.count <= 20
            }

            return false
        }

        print("🔍 PART TOKENS:", partTokens.map { $0.text })
        print("🔍 DESC TOKENS:", descriptionTokens.map { $0.text })

        guard !partTokens.isEmpty, !descriptionTokens.isEmpty else {
            return []
        }

        // 🔥 STEP 3: match each part to closest description by Y-distance, restrict to local window
        let sortedParts = partTokens.sorted { $0.boundingBox.midY < $1.boundingBox.midY }
        let sortedDescs = descriptionTokens.sorted { $0.boundingBox.midY < $1.boundingBox.midY }

        var results: [Part] = []

        for partToken in sortedParts {

            let partY = partToken.boundingBox.midY

            // ✅ restrict search to LOCAL vertical window (critical fix)
            let localDescs = sortedDescs.filter {
                abs($0.boundingBox.midY - partY) < 0.05
            }

            let closestDesc = localDescs.min(by: {
                abs($0.boundingBox.midY - partY) < abs($1.boundingBox.midY - partY)
            })

            let description = closestDesc?.text ?? "OEM Part"

            results.append(
                Part(
                    partNumber: PartNumber(partToken.text.uppercased()),
                    description: description,
                    quantity: 1,
                    billedPrice: Money(amount: 0)
                )
            )
        }

        print("🔥 PART LIST RESULT:", results.count)

        return results
    }