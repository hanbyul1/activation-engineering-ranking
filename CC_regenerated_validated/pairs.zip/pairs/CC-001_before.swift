    
    func extractServiceFields(
        _ blockItems: [OCRItem],
        tokenItems: [OCRItem],
        rows: [OCRRow],
        fullText: String
    ) -> [String: String] {
        
        var result: [String: String] = [:]

        // =========================
        // 🔥 GMAIL STRUCTURE DETECTION (여기!!!)
        // =========================
        let hasPageBreak = rows.contains {
            $0.fullText.contains("Page 1 of 2") || $0.fullText.contains("Page 2 of 2")
        }

        let hasEmailArtifacts = rows.contains {
            $0.fullText.contains("@") || $0.fullText.contains("mail.google.com")
        }

        let isGmailLike = hasPageBreak && hasEmailArtifacts

        // =========================
        // 🔥 ROW FILTERING 수정
        // =========================
        let filteredRows = isGmailLike
            ? rows
            : rows.filter { !isGmailNoise($0.fullText) }
        
        // =========================
        // 1. AMOUNT
        // =========================
        var totalDue: String? = nil
        var jobTotal: String? = nil
        var paymentAmount: String? = nil

        // 🔥 collect all candidates first
        for row in filteredRows {

            let upper = normalizeLabelText(row.fullText)

            // 🔥 Payment (highest priority)
            if upper.contains("PAYMENT AMOUNT") || upper.contains("PAID TOTAL") {
                if let amount = extractLastAmount(from: row.fullText) {
                    paymentAmount = amount
                }
            }

            // 🔥 Job total
            if upper.contains("JOB TOTAL") {
                if let amount = extractLastAmount(from: row.fullText) {
                    jobTotal = amount
                }
            }

            // 🔥 General total (covers "Total", "Total $885.00")
            if upper.contains("TOTAL") && !upper.contains("SUBTOTAL") {
                if let amount = extractLastAmount(from: row.fullText) {
                    totalDue = amount
                }
            }
        }

        // 🔥 priority decision (핵심)
        if let payment = paymentAmount {
            result["amount_due"] = payment
        } else if let job = jobTotal {
            result["amount_due"] = job
        } else if let total = totalDue {
            result["amount_due"] = total
        }
        // 🔥 no override — 이미 우선순위 로직에서 결정됨
        
        // =========================
        // 2. DATE
        // =========================
        for row in filteredRows {
            let upper = row.fullText.uppercased()
            
            if upper.contains("INVOICE DATE") || upper.contains("COMPLETED") {

                var text = row.fullText

                // 🔥 1. comma normalize (September 26,2030 → September 26, 2030)
                text = text.replacingOccurrences(
                    of: #",(?=\d{4})"#,
                    with: ", ",
                    options: .regularExpression
                )

                // 🔥 핵심: 날짜만 정확히 캡처
                if let match = firstMatch(
                    text,
                    pattern: #"(January|February|March|April|May|June|July|August|September|October|November|December|Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+\d{1,2},\s*\d{4}"#
                ) {
                    result["due_date"] = match
                    print("🔥 [INLINE DATE SUCCESS]:", match)
                    break
                }
                
                // 🔥 2. 뒤 쓰레기 제거 (회사명 붙는 문제 해결)
                text = text.replacingOccurrences(
                    of: #"(INC|LLC|COMPANY|EMAIL|PHONE).*"#,
                    with: "",
                    options: [.regularExpression, .caseInsensitive]
                )

                if let match = firstMatch(
                    text,
                    pattern: #"\d{1,2}/\d{1,2}/\d{4}"#
                ) {
                    result["due_date"] = match
                    break
                }
                
                if let match = firstMatch(
                    text,
                    pattern: #"(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec|January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{1,2},\s+\d{4}"#
                ) {
                    result["due_date"] = match
                    break
                }
            }
        }
        
        // 🔥 fallback: 다음 줄에서 date 찾기
        for i in 0..<filteredRows.count - 1 {
            
            let upper = rows[i].fullText.uppercased()
            
            if upper.contains("INVOICE DATE") ||
               upper.contains("COMPLETED") ||
               upper.contains("DUE DATE") {   // 🔥 추가
                
                let next = rows[i+1].fullText
                
                if let match = firstMatch(
                    next,
                    pattern: #"\d{1,2}/\d{1,2}/\d{4}"#
                ) {
                    result["due_date"] = match
                    break
                }
                
                if let match = firstMatch(
                    next,
                    pattern: #"(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+\d{1,2},\s+\d{4}"#
                ) {
                    result["due_date"] = match
                    break
                }
            }
        }
        
        // 🔥 ADD: Transaction Time 기반 날짜
        for row in filteredRows {

            let upper = row.fullText.uppercased()

            if upper.contains("TRANSACTION TIME") {

                let current = row.fullText

                if let date = firstMatch(
                    current,
                    pattern: #"\d{1,2}/\d{1,2}/\d{4}"#
                ) {
                    result["due_date"] = date
                    break
                }
            }
        }
        
        // 🔥 fallback: "Date" 키워드
        if result["due_date"] == nil {

            for row in rows {

                let upper = row.fullText.uppercased()

                if upper.contains("DATE") {

                    if let match = firstMatch(
                        row.fullText,
                        pattern: #"\d{1,2}/\d{1,2}/\d{4}"#
                    ) {
                        result["due_date"] = match
                        break
                    }
                }
            }
        }
        
        // =========================
        // 🔥 DATE FIX (no-space comma)
        // =========================
        if result["due_date"] == nil {

            for row in rows {

                if let match = firstMatch(
                    row.fullText,
                    pattern: #"(January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{1,2},\d{4}"#
                ) {
                    let fixed = match.replacingOccurrences(of: ",", with: ", ")
                    result["due_date"] = fixed
                    print("🔥 [DATE FIX SUCCESS]:", fixed)
                    break
                }
            }
        }
        
        // =========================
        // 🔥 FINAL OVERRIDE: DUE DATE (special case)
        // =========================
        for row in filteredRows {

            let upper = row.fullText.uppercased()

            if upper.contains("DUE DATE") {

                var text = row.fullText

                // comma normalize
                text = text.replacingOccurrences(
                    of: #",(?=\d{4})"#,
                    with: ", ",
                    options: .regularExpression
                )

                if let match = firstMatch(
                    text,
                    pattern: #"(January|February|March|April|May|June|July|August|September|October|November|December|Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+\d{1,2},\s*\d{4}"#
                ) {
                    result["due_date"] = match
                    print("🔥 [DUE DATE OVERRIDE]:", match)
                    break
                }

                if let match = firstMatch(
                    text,
                    pattern: #"\d{1,2}/\d{1,2}/\d{4}"#
                ) {
                    result["due_date"] = match
                    print("🔥 [DUE DATE OVERRIDE]:", match)
                    break
                }
            }
        }
        
        // =========================
        // 3. SHOP HEADER CLUSTER 찾기
        // =========================
        // 핵심:
        // shop 정보는 문서 상단 header에만 있어야 함.
        // BILLING / JOB ADDRESS / DESCRIPTION 시작 전까지만 본다.
        
        var headerEnd = filteredRows.count
        for (i, row) in filteredRows.enumerated() {
            let upper = row.fullText.uppercased()
            if upper.contains("BILLING ADDRESS") ||
               upper.contains("BILL TO") ||
               upper.contains("JOB ADDRESS") ||
               upper.contains("CUSTOMER") ||          // 🔥 추가
               upper.contains("SERVICE ADDRESS") ||   // 🔥 추가
               upper.contains("ACCOUNT") ||           // 🔥 추가
               upper.contains("DESCRIPTION OF WORK") ||
               upper.contains("DIAGNOSIS") ||
               upper.contains("TROUBLE REPORTED") ||
               upper.contains("INVOICE DATE") {
                headerEnd = i
                break
            }
        }
        
        let headerRowsTop = Array(filteredRows.prefix(headerEnd))
        
        let headerRows = headerRowsTop.filter {
            !isGmailNoise($0.fullText)
        }
        
        // 1. 헤더 탐색 범위 설정 (고객 관련 키워드 등장 전까지)
        let stopKeywords = ["BILLING ADDRESS", "JOB ADDRESS", "CUSTOMER", "DAEKYOO", "BILL TO"]
        var headerLimit = min(10, filteredRows.count) // 주소는 보통 상단 5줄 이내

        for (i, row) in filteredRows.enumerated() {
            let upper = row.fullText.uppercased()
            if stopKeywords.contains(where: { upper.contains($0) }) {
                headerLimit = i
                break
            }
        }

        // 2. 주소 추출 (상단 영역 루프)
        if result["address"] == nil {
            let shopHeaderArea = Array(filteredRows.prefix(headerLimit))
            
            for row in shopHeaderArea {
                let text = row.fullText
                
                // 🔥 전략: 주소는 반드시 '숫자'를 포함하며, '도시명/주이름'이 나타나는 구조임
                // "MM 57575 Rosell Road, New Haven, Michigan 4804" 대응
                
                // 정규식: 숫자로 시작하거나, 짧은 단어(MM) 뒤에 숫자가 오는 경우 매칭
                let regex = #"(?:\b[A-Z]{1,3}\s+)?(\d{2,6}\s+[A-Z][A-Za-z0-9\s.]{3,40}.+?\d{4,5})"#
                
                if let match = firstMatch(text, pattern: regex) {
                    var cleaned = match
                    
                    // "MM " 같은 접두어가 포함되었다면 숫자부터 시작하도록 절삭
                    if let range = cleaned.range(of: #"\d"#, options: .regularExpression) {
                        cleaned = String(cleaned[range.lowerBound...])
                    }
                    
                    // "Invoice", "Date" 등 주소 뒤에 붙은 노이즈 제거
                    let noiseWords = ["Invoice", "Date", "Completed", "Phone", "Customer"]
                    for noise in noiseWords {
                        if let range = cleaned.range(of: noise, options: .caseInsensitive) {
                            cleaned = String(cleaned[..<range.lowerBound])
                        }
                    }
                    
                    let finalAddress = cleaned.trimmingCharacters(in: .whitespacesAndNewlines)
                    
                    // 최소한의 주소 길이(번호+길이름+도시) 검증
                    if finalAddress.count > 12 {
                        result["address"] = finalAddress
                        print("📍 [ADDRESS SUCCESS]: \(finalAddress)")
                        break
                    }
                }
            }
        }
        
        // =========================
        // 🔥 FIX: MULTI-LINE ADDRESS MERGE (여기 추가)
        // =========================
        if let street = result["address"] {

            for i in 0..<filteredRows.count - 1 {

                let l1 = filteredRows[i].fullText
                let l2 = filteredRows[i+1].fullText

                // street 라인이 현재 address랑 동일하면
                if l1.contains(street) {

                    if let city = firstMatch(
                        l2,
                        pattern: #"[A-Za-z .]+,\s*[A-Z]{2}\s*\d{5}"#
                    ) {

                        let full = "\(street), \(city)"
                        result["address"] = full

                        print("🔥 [ADDRESS FIXED - MULTILINE]:", full)
                        break
                    }
                }
            }
        }
        
        // =========================
        // 🔥 INLINE ADDRESS EXTRACTION (핵심 해결)
        // =========================
        if result["address"] == nil {

            for row in headerRowsTop {

                let raw = row.fullText

                // 🔥 1. prefix 제거 (MM 같은거)
                let text = raw.replacingOccurrences(
                    of: #"^[A-Z]{1,3}\s+"#,
                    with: "",
                    options: .regularExpression
                )

                // 🔥 2. address match
                if let match = firstMatch(
                    text,
                    pattern: #"\d{4,6}\s+[A-Za-z0-9 .]+,\s*[A-Za-z .]+,\s*[A-Za-z .]+\s*\d{4,5}"#
                ) {

                    // 🔥 3. 뒤 쓰레기 제거
                    let cleaned = match
                        .replacingOccurrences(of: #"Invoice.*"#, with: "", options: .regularExpression)
                        .replacingOccurrences(of: #"Date.*"#, with: "", options: .regularExpression)
                        .trimmingCharacters(in: .whitespaces)

                    print("🔥 ADDRESS HIT:", cleaned)

                    result["address"] = cleaned
                    break
                }
            }
        }
        
        // =========================
        // 🔥 PIPE + INTERNATIONAL ADDRESS FIX (확장)
        // =========================
        if result["address"] == nil {

            for row in headerRowsTop {

                var text = row.fullText.trimmingCharacters(in: .whitespacesAndNewlines)

                // 🔥 핵심: | → , 로 정규화
                text = text.replacingOccurrences(of: "|", with: ",")

                // ❌ 이메일 제거
                if text.contains("@") { continue }

                // ✅ 캐나다 + 일반 주소 대응
                if let match = firstMatch(
                    text,
                    pattern: #"\d{2,6}\s+[A-Za-z0-9 .]+,\s*[A-Za-z .]+,\s*[A-Za-z0-9 ]{3,10}"#
                ) {
                    result["address"] = match
                    print("🔥 [INTL ADDRESS SUCCESS]:", match)
                    break
                }
            }
        }
        
        // =========================
        // 🔥 COMPANY ADDRESS FINAL FIX (REPLACE ALL)
        // =========================
        if result["address"] == nil {

            for row in rows {

                let raw = row.fullText

                if raw.uppercased().contains("COMPANY ADDRESS") {

                    var text = raw

                    // 🔥 1. Billing Address 전체 제거 (콜론 포함)
                    text = text.replacingOccurrences(
                        of: #"BILLING ADDRESS[:\s].*"#,
                        with: "",
                        options: [.regularExpression, .caseInsensitive]
                    )

                    // 🔥 2. Company Address 제거
                    text = text.replacingOccurrences(
                        of: #"COMPANY ADDRESS[:\s]*"#,
                        with: "",
                        options: [.regularExpression, .caseInsensitive]
                    )

                    let cleaned = text.trimmingCharacters(in: .whitespacesAndNewlines)

                    // 🔥 3. 숫자 포함 + 길이 체크
                    if cleaned.range(of: #"\d+"#, options: .regularExpression) != nil &&
                       cleaned.count > 10 {

                        result["address"] = cleaned
                        print("🔥 [COMPANY ADDRESS FINAL]:", cleaned)
                        break
                    }
                }
            }
        }
        // =========================
        // 4. SHOP NAME
        // =========================

        // 4-1. strongest pass
        for row in headerRows {

            let text = row.fullText.trimmingCharacters(in: .whitespacesAndNewlines)
            let upper = text.uppercased()

            if text.isEmpty { continue }

            // 공통 제외
            if upper.contains("BILL TO") { continue }
            if upper.contains("JOB ADDRESS") { continue }
            if upper.contains("INVOICE DATE") { continue }
            if upper.contains("DESCRIPTION OF WORK") { continue }
            if upper.contains("HTTP") || upper.contains("WWW.") { continue }
            if text.contains("@") { continue }

            // 주소/전화 제외
            if text.range(of: #"^\d+\s+"#, options: .regularExpression) != nil { continue }
            if firstMatch(text, pattern: #"\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}"#) != nil { continue }

            // ✅ strongest는 길이 필터보다 먼저
            if upper.contains("LLC") ||
               upper.contains("INC") ||
               upper.contains("APPLIANCE") ||
               upper.contains("MECHANICAL") {

                let cleaned = cleanShopName(text)
                if isLikelyCompanyName(cleaned) {
                    result["shop_name"] = cleaned
                    break
                }
            }
        }

        // 4-2. medium pass (strongest 못 찾았을 때만)
        if result["shop_name"] == nil {
            for row in headerRows {

                let text = row.fullText.trimmingCharacters(in: .whitespacesAndNewlines)
                let upper = text.uppercased()

                if text.isEmpty { continue }

                if upper.contains("BILL TO") { continue }
                if upper.contains("JOB ADDRESS") { continue }
                if upper.contains("INVOICE") { continue }
                if upper.contains("DESCRIPTION") { continue }
                if upper.contains("HTTP") || upper.contains("WWW.") { continue }
                if text.contains("@") { continue }

                // 주소/전화 제외
                if text.range(of: #"^\d+\s+"#, options: .regularExpression) != nil { continue }
                if firstMatch(text, pattern: #"\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}"#) != nil { continue }

                // 슬로건/문장 제외
                if text.contains("•") { continue }
                if text.count > 45 { continue }
                if text.split(separator: " ").count > 5 { continue }

                // ✅ medium signal
                if upper.contains("PLUMBING") ||
                   upper.contains("HEATING") ||
                   upper.contains("COOLING") {

                    let cleaned = cleanShopName(text)
                    if isLikelyCompanyName(cleaned) {
                        result["shop_name"] = cleaned
                        break
                    }
                }
            }
        }
        
        // =========================
        // 🔥 4-3. ADDRESS 기반 보조 규칙 (SAFE)
        // =========================
        if result["shop_name"] == nil {

            for i in 0..<max(0, headerRowsTop.count - 1) {
                
                let current = headerRowsTop[i].fullText.trimmingCharacters(in: .whitespaces)
                let next = headerRowsTop[i+1].fullText.trimmingCharacters(in: .whitespaces)
                
                let isStreet = next.range(
                    of: #"^\d+\s+.*"#,
                    options: .regularExpression
                ) != nil
                
                if isStreet {
                    
                    let cleaned = cleanShopName(current)
                    
                    if isLikelyCompanyName(cleaned) {
                        result["shop_name"] = cleaned
                        break
                    }
                }
            }
        }
        
        // =========================
        // 🔥 SHOP NAME FALLBACK (Gmail 대응)
        // =========================
        if result["shop_name"] == nil {
            
            for (_, row) in rows.enumerated() {
                
                let text = row.fullText.trimmingCharacters(in: .whitespacesAndNewlines)
                let upper = text.uppercased()
                
                if text.isEmpty { continue }
                
                // ❌ Gmail noise 제거
                if upper.contains("GMAIL") { continue }
                if upper.contains("PAYMENT RECEIPT") { continue }
                if upper.contains("REPLY-TO") { continue }
                if upper.contains("TO:") { continue }
                
                // ✅ 교체
                _ = text.replacingOccurrences(
                    of: #"<.*?>"#,
                    with: "",
                    options: .regularExpression
                ).trimmingCharacters(in: .whitespaces)
                
                if upper.contains("INC") || upper.contains("LLC") {
                    
                    // ❌ Gmail 라인 제거
                    if isGmailNoise(text) { continue }
                    
                    // ❌ 너무 긴 문장 제거 (핵심)
                    if text.count > 60 { continue }
                    
                    // ❌ 날짜 포함 줄 제거
                    if text.range(of: #"\d{1,2}/\d{1,2}/\d{2,4}"#, options: .regularExpression) != nil {
                        continue
                    }
                    
                    if result["shop_name"] == nil {
                        result["shop_name"] = text
                    }
                    break
                }
            }
        }
        
        // =========================
        // 🔥 SHOP NAME FALLBACK 강화
        // =========================
        if result["shop_name"] == nil {
            
            for row in rows {
                
                let text = row.fullText.trimmingCharacters(in: .whitespacesAndNewlines)
                let upper = text.uppercased()
                
                if text.isEmpty { continue }
                
                // ❌ Gmail subject 제거 (핵심)
                if upper.contains("PAYMENT RECEIPT") { continue }
                if upper.contains("GMAIL -") { continue }
                
                // ❌ 이메일 포함 줄 제거
                if text.contains("@") { continue }
                
                // ✅ strong signal
                if upper.contains("INC") || upper.contains("LLC") {
                    
                    if let existing = result["shop_name"] {
                        
                        if !isLikelyCompanyName(existing) {
                            result["shop_name"] = text
                        }
                        
                    } else {
                        result["shop_name"] = text
                    }
                    
                    break
                }
            }
        }
        
        // =========================
        // 🔥 FINAL SHOP NAME SANITY FILTER
        // =========================
        if let shop = result["shop_name"] {

            let cleaned = cleanShopName(shop)

            let looksLikeAddressMixedLine =
                cleaned.range(of: #"^(PLUMBING|HEATING|COOLING)\s+\d+\s+"#,
                              options: [.regularExpression, .caseInsensitive]) != nil

            if !isLikelyCompanyName(cleaned) || looksLikeAddressMixedLine {
                result.removeValue(forKey: "shop_name")
            } else {
                result["shop_name"] = cleaned
            }
        }
        
        // =========================
        // 🔥 FINAL SHOP NAME RECOVERY (핵심)
        // =========================
        if result["shop_name"] == nil {

            for row in headerRowsTop {

                let text = row.fullText.trimmingCharacters(in: .whitespacesAndNewlines)
                let upper = text.uppercased()

                if text.isEmpty { continue }

                // ❌ 설명/문장 제거
                if upper.contains("DESCRIPTION") { continue }
                if upper.contains("INVOICE") { continue }
                if upper.contains("BILL TO") { continue }

                // ❌ 주소/전화 제거
                if text.range(of: #"^\d+\s+"#, options: .regularExpression) != nil { continue }
                if firstMatch(text, pattern: #"\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}"#) != nil { continue }

                // ❌ "PLUMBING 540 Bloomer..." 같은 주소혼합 라인 제거
                if text.range(of: #"^(PLUMBING|HEATING|COOLING)\s+\d+\s+"#,
                              options: [.regularExpression, .caseInsensitive]) != nil {
                    continue
                }

                // ✅ "Ready Jetter Plumbing Payment terms ..." 처리
                if upper.contains("PLUMBING") ||
                   upper.contains("HEATING") ||
                   upper.contains("COOLING") ||
                   upper.contains("LLC") ||
                   upper.contains("INC") {

                    let cleaned = text
                        .replacingOccurrences(of: #"\s+Payment\s+terms.*$"#,
                                              with: "",
                                              options: [.regularExpression, .caseInsensitive])
                        .replacingOccurrences(of: #"\s+Due\s+upon\s+receipt.*$"#,
                                              with: "",
                                              options: [.regularExpression, .caseInsensitive])
                        .trimmingCharacters(in: .whitespacesAndNewlines)

                    if isLikelyCompanyName(cleaned) {
                        result["shop_name"] = cleanShopName(cleaned)
                        break
                    }
                }
            }
        }
        
        // =========================
        // 🔥 SIMPLE HEADER MERGE (핵심 해결)
        // =========================
        if result["shop_name"] == nil {

            let top = headerRowsTop.prefix(3) // 상단 3줄만

            for i in 0..<max(0, top.count - 1) {

                let l1 = top[i].fullText.trimmingCharacters(in: .whitespaces)
                let l2 = top[i+1].fullText.trimmingCharacters(in: .whitespaces)

                let combined = "\(l1) \(l2)"

                // ❌ 주소 라인 제외
                if l1.range(of: #"^\d+\s+"#, options: .regularExpression) != nil { continue }

                // ❌ 숫자 많으면 제외 (transaction 라인 방지)
                if combined.range(of: #"\d{4,}"#, options: .regularExpression) != nil { continue }

                // ❌ 너무 길면 제외
                if combined.count > 60 { continue }

                let cleaned = cleanShopName(combined)

                if cleaned.count > 5 {
                    result["shop_name"] = cleaned
                    print("🔥 [SHOP MERGE SUCCESS]:", cleaned)
                    break
                }
            }
        }
        
        // =========================
        // 🔥 GENERIC COMPANY FALLBACK (확장)
        // =========================
        if result["shop_name"] == nil {

            for row in headerRowsTop {

                let text = row.fullText.trimmingCharacters(in: .whitespacesAndNewlines)
                let upper = text.uppercased()

                if text.isEmpty { continue }

                // ❌ 기존 필터 유지
                if upper.contains("INVOICE") { continue }
                if upper.contains("RECIPIENT") { continue }
                if upper.contains("TOTAL") { continue }
                if text.contains("@") { continue }
                if upper.contains("WWW") { continue }

                // ❌ 주소 / 전화 제거
                if text.range(of: #"^\d+\s+"#, options: .regularExpression) != nil { continue }
                if firstMatch(text, pattern: #"\d{3}[-.\s]?\d{3}[-.\s]?\d{4}"#) != nil { continue }

                // ✅ 핵심: 짧은 타이틀형 텍스트 허용
                let wordCount = text.split(separator: " ").count

                if wordCount <= 5 &&
                   text.range(of: #"^[A-Z][A-Za-z&.\s]+$"#, options: .regularExpression) != nil {

                    result["shop_name"] = cleanShopName(text)
                    print("🔥 [GENERIC SHOP SUCCESS]:", text)
                    break
                }
            }
        }
        
        // =========================
        // 🔥 MULTI-LINE COMPANY MERGE (핵심 해결)
        // =========================
        if result["shop_name"] == nil {

            for i in 0..<rows.count - 1 {

                let l1 = rows[i].fullText.trimmingCharacters(in: .whitespacesAndNewlines)
                let l2 = rows[i+1].fullText.trimmingCharacters(in: .whitespacesAndNewlines)

                let combined = "\(l1) \(l2)"
                let upper = combined.uppercased()

                if combined.isEmpty { continue }

                // ❌ 약관 제거
                if upper.contains("NOT RESPONSIBLE") { continue }
                if upper.contains("NOT GUARANTEED") { continue }

                // ❌ 주소 제거
                if l1.range(of: #"^\d+\s+"#, options: .regularExpression) != nil { continue }

                // ❌ 전화 제거
                if firstMatch(combined, pattern: #"\d{3}[-.\s]?\d{3}[-.\s]?\d{4}"#) != nil { continue }

                // ✅ 핵심: 회사 키워드
                if upper.contains("PLUMBING") &&
                   upper.contains("SEWER") {

                    if let match = firstMatch(
                        combined,
                        pattern: #"[A-Z][A-Za-z& ]+(Plumbing).*?(Sewer)[A-Za-z& ,\.]*?(Inc\.?|LLC)"#
                    ) {

                        let cleaned = cleanShopName(match)

                        if isLikelyCompanyName(cleaned) {
                            result["shop_name"] = cleaned
                            break
                        }
                    }
                }
            }
        }
        
        // =========================
        // 🔥 INLINE COMPANY EXTRACTION (핵심 추가)
        // =========================
        if let shop = result["shop_name"] {

            let text = shop

            // ❌ 문장이 너무 길면 → 내부에서 회사명만 추출
            if text.count > 60 {

                if let match = firstMatch(
                    text,
                    pattern: #"[A-Z][A-Za-z& ]+(Plumbing|Heating|Cooling|Sewer)[A-Za-z& ,\.]*?(Inc\.?|LLC)"#
                ) {

                    let cleaned = cleanShopName(match)

                    if isLikelyCompanyName(cleaned) {
                        result["shop_name"] = cleaned
                    } else {
                        result.removeValue(forKey: "shop_name")
                    }

                } else {
                    result.removeValue(forKey: "shop_name")
                }
            }
        }
        
        // =========================
        // 🔥 INLINE COMPANY FROM LABEL (핵심 추가)
        // =========================
        if result["shop_name"] == nil {

            for row in rows {

                let text = row.fullText

                // Company Name: ABC Company
                if text.uppercased().contains("COMPANY NAME") {

                    if let match = firstMatch(
                        text,
                        pattern: #"COMPANY NAME[:\s]+([A-Z][A-Za-z&.\s]+)"#
                    ) {

                        let cleaned = match
                            .replacingOccurrences(of: "Company Name:", with: "", options: .caseInsensitive)
                            .trimmingCharacters(in: .whitespaces)

                        result["shop_name"] = cleanShopName(cleaned)
                        print("🔥 [LABEL SHOP SUCCESS]:", cleaned)
                        break
                    }
                }

                // inline: "... ABC Company"
                if let match = firstMatch(
                    text,
                    pattern: #"[A-Z][A-Za-z& ]+Company"#
                ) {
                    let cleaned = cleanShopName(match)
                    if isLikelyCompanyName(cleaned) {
                        result["shop_name"] = cleaned
                        print("🔥 [INLINE SHOP SUCCESS]:", cleaned)
                        break
                    }
                }
            }
        }
        
        // =========================
        // 🔥 HARD FILTER: 문장형 제거 (추가)
        // =========================
        if let shop = result["shop_name"] {

            let t = shop.lowercased()

            if t.contains("not guaranteed") ||
               t.contains("responsible for payment") ||
               t.contains("unable to open") ||
               t.contains("i will be") {

                result.removeValue(forKey: "shop_name")
            }
            
            if let shop = result["shop_name"] {

                let t = shop.lowercased()

                if t.contains("not guaranteed") ||
                   t.contains("responsible for payment") ||
                   t.contains("unable to open") ||
                   shop.count > 80 {

                    result.removeValue(forKey: "shop_name")
                }
            }
        }
        
        // =========================
        // 🔥 RE-RECOVERY (조건 수정 핵심 - FIXED)
        // =========================

        var shouldRecover = true

        if let existing = result["shop_name"] {
            let t = existing.lowercased()
            shouldRecover =
                !isLikelyCompanyName(existing) ||
                t.contains("not guaranteed") ||
                t.contains("responsible for payment") ||
                t.contains("unable to open")
        }

        if shouldRecover {

            for row in rows {

                let text = row.fullText.trimmingCharacters(in: .whitespacesAndNewlines)
                let upper = text.uppercased()

                if text.isEmpty { continue }

                // ❌ 문장형 제거 (완화)
                if text.count > 80 { continue }

                // ❌ 설명 제거
                if upper.contains("NOT RESPONSIBLE") { continue }
                if upper.contains("NOT GUARANTEED") { continue }

                // ❌ 주소 제거
                if text.range(of: #"^\d+\s+"#, options: .regularExpression) != nil { continue }

                // ❌ 전화 제거
                if self.firstMatch(text, pattern: #"\d{3}[-.\s]?\d{3}[-.\s]?\d{4}"#) != nil { continue }

                // ✅ 핵심: 회사 키워드
                if upper.contains("PLUMBING") ||
                   upper.contains("SEWER") {

                    if let match = self.firstMatch(
                        text,
                        pattern: #"[A-Z][A-Za-z& ]+(Plumbing|Sewer)[A-Za-z& ,\.]*?(Inc\.?|LLC)?"#
                    ) {

                        let cleaned = self.cleanShopName(match)

                        if self.isLikelyCompanyName(cleaned) {
                            result["shop_name"] = cleaned
                            break
                        }
                    }
                }
            }
        }
        
        // =========================
        // 🔥 BLOCK BAD SHOP BEFORE LAST RESORT (핵심 추가)
        // =========================
        if let shop = result["shop_name"] {

            let t = shop.lowercased()

            // 이미 정상적인 회사명이면 → LAST RESORT 막는다
            if isLikelyCompanyName(shop) &&
               !t.contains("not guaranteed") &&
               !t.contains("responsible") &&
               shop.count < 60 {
            }
        }
        
        // =========================
        // 🔥 LAST RESORT (강제 복구 - 핵심)
        // =========================
        if result["shop_name"] == nil {

            for row in rows {

                let text = row.fullText.trimmingCharacters(in: .whitespacesAndNewlines)
                let upper = text.uppercased()

                if text.isEmpty { continue }

                // ✅ 핵심 패턴: Payment terms 포함된 회사라인
                if upper.contains("PLUMBING") &&
                   upper.contains("PAYMENT") {

                    let cleaned = text
                        .components(separatedBy: "Payment").first ?? text

                    let final = cleanShopName(cleaned)

                    result["shop_name"] = final
                    break
                }

                // ✅ LLC 포함된 약관 라인에서 추출
                if upper.contains("LLC") {

                    let cleaned = text
                        .components(separatedBy: " is ").first ?? text

                    let final = cleanShopName(cleaned)

                    if isLikelyCompanyName(final) {
                        result["shop_name"] = final
                        break
                    }
                }
            }
        }
                
        // =========================
        // 5. SHOP ADDRESS (shop header only)
        // =========================
        if result["address"] == nil {
            
            // shop 정보가 존재할 수 있는 상단 header만 사용
            let shopAddressRows = headerRowsTop
            
            // 1) street + city 인접 2줄 우선
            for i in 0..<max(0, shopAddressRows.count - 1) {
                
                let line1 = shopAddressRows[i].fullText.trimmingCharacters(in: .whitespacesAndNewlines)
                let line2 = shopAddressRows[i + 1].fullText.trimmingCharacters(in: .whitespacesAndNewlines)

                // 🔥 FIX: skip duplicated lines (customer address duplication issue)
                if line1 == line2 { continue }

                // 🔥 FIX: skip obvious customer blocks even if header slipped
                if isCustomerBlock(line1) || isCustomerBlock(line2) { continue }
                
                let upper1 = line1.uppercased()
                let upper2 = line2.uppercased()
                
                if upper1.contains("BILL TO") || upper2.contains("BILL TO") { continue }
                if upper1.contains("JOB ADDRESS") || upper2.contains("JOB ADDRESS") { continue }
                if upper1.contains("BILLING ADDRESS") || upper2.contains("BILLING ADDRESS") { continue }
                if upper1.contains("DESCRIPTION OF WORK") || upper2.contains("DESCRIPTION OF WORK") { continue }
                if upper1.contains("INVOICE") || upper2.contains("INVOICE") { continue }
                if upper1.contains("HTTP") || upper2.contains("HTTP") { continue }
                if upper1.contains("GMAIL") || upper2.contains("GMAIL") { continue }
                if upper1.contains("WWW.") || upper2.contains("WWW.") { continue }
                
                let isStreet = line1.range(
                    of: #"^\d+\s+[A-Za-z0-9 .]+$"#,
                    options: [.regularExpression, .caseInsensitive]
                ) != nil
                
                let isCity = line2.range(
                    of: #"[A-Za-z .]+,\s*(MI|Michigan)\s*[|]?\s*\d{5}"#,
                    options: [.regularExpression, .caseInsensitive]
                ) != nil
                
                if isStreet && isCity {
                    let cleanedCity = line2
                        .replacingOccurrences(of: #"Date.*"#, with: "", options: .regularExpression)
                        .replacingOccurrences(of: "|", with: "")
                        .replacingOccurrences(of: "  ", with: " ")
                        .trimmingCharacters(in: .whitespacesAndNewlines)
                    
                    // 🔥 FIX: normalize duplicated street issue (e.g., "540 ... 540 ...")
                    let normalizedStreet = line1
                        .replacingOccurrences(of: #"(\b\d+\s+[A-Za-z0-9 .]+)\s+\1"#,
                                              with: "$1",
                                              options: .regularExpression)

                    result["address"] = "\(normalizedStreet), \(cleanedCity)"
                    break
                }
            }
        }

        // =========================
        // 🔥 SINGLE-LINE ADDRESS FIX (핵심)
        // =========================
        if result["address"] == nil {

            for row in headerRowsTop {

                let text = row.fullText.trimmingCharacters(in: .whitespacesAndNewlines)

                // ❌ customer block 제외
                if isCustomerBlock(text) { continue }

                // ❌ 이메일 제거
                if text.contains("@") { continue }

                // 🔥 핵심 패턴 (street + city 한 줄)
                if let match = firstMatch(
                    text,
                    pattern: #"\d+\s+[A-Za-z0-9 .]+,\s*[A-Za-z .]+,\s*(MI|Michigan)\s*\d{5}"#
                ) {
                    result["address"] = match
                    break
                }
            }
        }
        
        // =========================
        // 🔥 3-LINE ADDRESS SUPPORT (Mr Appliance)
        // =========================
        if result["address"] == nil {
            
            let rows = headerRowsTop
            
            for i in 0..<max(0, rows.count - 2) {
                
                let l1 = rows[i].fullText.trimmingCharacters(in: .whitespaces)
                let l3 = rows[i+2].fullText.trimmingCharacters(in: .whitespaces)
                
                let isStreet = l1.range(of: #"^\d+\s+.*"#, options: .regularExpression) != nil
                
                let isCity = l3.range(
                    of: #"[A-Za-z .]+,\s*(MI|Michigan)\s*\d{5}"#,
                    options: .regularExpression
                ) != nil
                
                if isStreet && isCity {
                    result["address"] = "\(l1), \(l3)"
                    break
                }
            }
        }
        
        // 2) single-line company footer address fallback
        if result["address"] == nil {
            for row in headerRows {
                
                let text = row.fullText.trimmingCharacters(in: .whitespacesAndNewlines)
                let upper = text.uppercased()
                
                if upper.contains("BILL TO") { continue }
                if upper.contains("JOB ADDRESS") { continue }
                if upper.contains("BILLING ADDRESS") { continue }
                if upper.contains("DESCRIPTION OF WORK") { continue }
                if upper.contains("HTTP") { continue }
                if upper.contains("GMAIL") { continue }
                if upper.contains("WWW.") { continue }
                
                // company footer style:
                // Randazzo ... 51327 Quadrate Drive, Macomb, Michigan 48042 586-336-1111
                if let streetMatch = firstMatch(
                    text,
                    pattern: #"\d+\s+[A-Za-z0-9 .]+?(?:RD|ROAD|DR|DRIVE|ST|STREET|AVE|AVENUE|BLVD|LN|LANE|CT|COURT|WAY)\b"#
                ),
                let cityMatch = firstMatch(
                    text,
                    pattern: #"[A-Za-z .]+,\s*(?:MI|Michigan)\s*\d{5}"#
                ) {
                    result["address"] = "\(streetMatch), \(cityMatch)"
                    break
                }
            }
        }
        
        // =========================
        // 🔥 FINAL GMAIL ADDRESS PATCH
        // =========================
        if result["address"] == nil && isGmailLike {

            let pages = splitPages(filteredRows)

            // 🔥 DEBUG START
            print("📄 pages count:", pages.count)

            for (i, page) in pages.enumerated() {
                print("📄 PAGE \(i):")
                for row in page {
                    print("   ", row.fullText)
                }
            }
            // 🔥 DEBUG END

            var street: String?
            var city: String?

            // 🔥 1. street 찾기 (모든 페이지 뒤에서)
            for page in pages {
                for row in page.reversed() {

                    let text = row.fullText.trimmingCharacters(in: .whitespaces)

                    let isStreet =
                        text.range(of: #"^\d+\s+.*\b(RD|RD\.|DR|DR\.|ST|ST\.|AVE|AVE\.|BLVD|LN|CT|WAY)\b"#,
                                   options: [.regularExpression, .caseInsensitive]) != nil

                    if isStreet {
                        street = text
                        break
                    }
                }
                if street != nil { break }
            }

            // 🔥 2. city 찾기 (모든 페이지 앞쪽에서)
            for page in pages {
                for row in page {

                    let text = row.fullText.trimmingCharacters(in: .whitespaces)

                    let isCity =
                        text.range(of: #"[A-Za-z .]+,\s*[A-Z]{2}\s*\d{5}"#,
                                   options: .regularExpression) != nil

                    if isCity {
                        city = text
                        break
                    }
                }
                if city != nil { break }
            }

            // 🔥 3. 합치기
            if let s = street, let c = city {
                let address = "\(s), \(c)"
                print("📍 Gmail cross-page address:", address)
                result["address"] = address
            }
        }
        
        // =========================
        // 🔥 GLOBAL ADDRESS RECOVERY (FIXED)
        // =========================
        if result["address"] == nil {

            for i in 0..<rows.count - 1 {

                let l1 = rows[i].fullText.trimmingCharacters(in: .whitespaces)
                let l2 = rows[i+1].fullText.trimmingCharacters(in: .whitespaces)

                // 🔥 FIX: completely block customer address patterns
                if isCustomerBlock(l1) || isCustomerBlock(l2) {
                    continue
                }

                // 🔥🔥🔥 핵심 추가 (customer block 바로 아래 차단)
                if i > 0 {
                    let prev = rows[i-1].fullText.uppercased()
                    if prev.contains("BILLING ADDRESS") ||
                       prev.contains("JOB ADDRESS") {
                        continue
                    }
                }

                if i > 1 {
                    let prev2 = rows[i-2].fullText.uppercased()
                    if prev2.contains("BILLING ADDRESS") ||
                       prev2.contains("JOB ADDRESS") {
                        continue
                    }
                }

                // 🔥 FIX: prevent duplicated address lines (same as above issue)
                if l1 == l2 { continue }

                let looksLikePerson =
                    l1.range(of: #"^[A-Z][a-z]+\s+[A-Z][a-z]+$"#, options: .regularExpression) != nil

                let containsDigits = l1.range(of: #"\d"#, options: .regularExpression) != nil

                // 사람 이름만 제거 (주소는 살림)
                if looksLikePerson && !containsDigits {
                    continue
                }

                let clean1 = l1
                    .replacingOccurrences(of: #"Invoice.*"#, with: "", options: .regularExpression)
                    .replacingOccurrences(of: #"Date.*"#, with: "", options: .regularExpression)
                    .trimmingCharacters(in: .whitespaces)

                let clean2 = cleanCompanyCityLine(l2)

                if clean1.isEmpty || clean2.isEmpty { continue }

                let isStreet = clean1.range(
                    of: #"^\d+\s+.*\b(Ave|Street|St|Road|Rd|Drive|Dr|Blvd|Lane|Ln|Ct|Way)\b"#,
                    options: [.regularExpression, .caseInsensitive]
                ) != nil

                let isCity = clean2.range(
                    of: #".+,\s*[A-Z]{2}\s*\d{5}"#,
                    options: .regularExpression
                ) != nil

                if isStreet && isCity {
                    let normalizedStreet = clean1
                        .replacingOccurrences(of: #"(\b\d+\s+[A-Za-z0-9 .]+)\s+\1"#,
                                              with: "$1",
                                              options: .regularExpression)
                    result["address"] = "\(normalizedStreet), \(clean2)"
                    break
                }
            }
        }
        
        
        
        // =========================
        // 6. SHOP PHONE
        // =========================
        // header 구간 안에서만 찾는다
        for row in headerRows {
            let upper = row.fullText.uppercased()
            
            if upper.contains("NEIGHBORLY") { continue }
            if upper.contains("CALL") { continue }
            
            // 기존 로직
            if let phone = firstMatch(
                row.fullText,
                pattern: #"\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}"#
            ), isValidPhone(phone, context: row.fullText) {
                result["phone"] = phone
                break
            }
            
            // 🔥🔥🔥 여기 추가 (핵심)
            if result["phone"] == nil {

                let matches = allMatches(
                    row.fullText,
                    pattern: #"\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}"#
                )

                for m in matches {
                    if isValidPhone(m, context: row.fullText) {
                        result["phone"] = m
                        break
                    }
                }
                
                if result["phone"] != nil { break }
            }
        }
        
        // 🔥 fallback: 전체 rows에서 찾기
        if result["phone"] == nil {

            for row in rows {

                if let phone = firstMatch(
                    row.fullText,
                    pattern: #"\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}"#
                ), isValidPhone(phone, context: row.fullText) {

                    result["phone"] = phone
                    break
                }
            }
        }
        
        // =========================
        // 🔥 PHONE MULTI-PARSE FIX (추가)
        // =========================
        if result["phone"] == nil {

            for row in headerRows {

                let matches = allMatches(
                    row.fullText,
                    pattern: #"\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}"#
                )

                if !matches.isEmpty {
                    // 첫 번째 유효한 번호 선택
                    for m in matches {
                        if isValidPhone(m, context: row.fullText) {
                            result["phone"] = m
                            break
                        }
                    }

                    if result["phone"] != nil { break }
                }
            }
        }
        
        // =========================
        // 🔥 FORCE PHONE RECOVERY (최종 보정)
        // =========================
        if result["phone"] == nil {

            for row in rows {

                let matches = allMatches(
                    row.fullText,
                    pattern: #"\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}"#
                )

                for m in matches {

                    if isValidPhone(m, context: row.fullText) {
                        result["phone"] = m
                        break
                    }
                }

                if result["phone"] != nil { break }
            }
        }
            
        // =========================
        // 7. DESCRIPTION
        // =========================
        if let startIndex = rows.firstIndex(where: {
            let t = $0.fullText.uppercased()
            return t.contains("DESCRIPTION OF WORK") ||
            t.contains("WORK PERFORMED") ||
            t.contains("DIAGNOSIS")
        }) {
            
            var collected: [String] = []
            
            for i in (startIndex + 1)..<rows.count {
                let upper = rows[i].fullText.uppercased()
                
                if upper.contains("TASK #") ||
                    upper.contains("SUB-TOTAL") ||
                    upper.contains("TOTAL DUE") ||
                    upper.contains("BALANCE DUE") ||
                    upper.contains("CUSTOMER AUTHORIZATION") {
                    break
                }
                
                let trimmed = rows[i].fullText.trimmingCharacters(in: .whitespacesAndNewlines)
                if !trimmed.isEmpty {
                    collected.append(trimmed)
                }
            }
            
            if !collected.isEmpty {
                result["description"] = collected.joined(separator: " ")
            }
        }
        
        result["type"] = "service"
        return result
    }