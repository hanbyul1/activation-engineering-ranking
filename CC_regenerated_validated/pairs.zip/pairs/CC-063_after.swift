private func findAccountNumberFromRows(_ rows: [OCRRow]) -> String? {
    return findAccountNumberFromRowsCore(rows)
}

    
    private func findAccountNumberFromRowsCore(_ rows: [OCRRow]) -> String? {

        for row in rows {

            let upper = row.fullText.uppercased()

            // 🔥🔥🔥 payment 영역 제거 (이거 없으면 계속 실패)
            if upper.contains("PLEASE") { continue }
            if upper.contains("PAY") { continue }
            if upper.contains("DETACH") { continue }
            if upper.contains("INDICATE") { continue }

            if !(upper.contains("ACCOUNT")) { continue }

            // 1️⃣ 숫자 기반 account (DTE 케이스)
            let digitParts = row.fullText.matches(for: #"\d+"#).flatMap { $0.dropFirst() }
            let joined = digitParts.joined()

            if joined.count >= 8 && joined.count <= 16 {
                return joined
            }

            // 2️⃣ hyphen형 account
            if let match = row.fullText.range(
                of: #"[A-Z0-9]+(?:-[A-Z0-9]+)+"#,
                options: .regularExpression
            ) {
                let candidate = String(row.fullText[match]).trimmingCharacters(in: .whitespaces)
                let digitCount = candidate.filter(\.isNumber).count
                if digitCount >= 4 {
                    return candidate
                }
            }
        }

        return nil
    }