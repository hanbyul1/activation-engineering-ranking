private func enrichAndBuildReport(parts: [Part], vehicle: Vehicle?) async {
    enrichAndBuildReportCore(parts, vehicle)
}

    
    private func enrichAndBuildReportCore(parts: [Part], vehicle: Vehicle?) async {

        print("🟢 ENTER enrichAndBuildReport")
        print("🟢 parts count:", parts.count)

        let ebayService = self.ebayService
        let cache = self.cache
        let maxAge: TimeInterval = 60 * 60 * 24

        var results: [PriceComparison] = []

        // =========================
        // 🔥 INITIAL BUILD (WITH IMAGE CACHE)
        // =========================
        for part in parts {

            let key = part.partNumber.rawValue
            let cached = await cache.getIfFresh(key, maxAge: maxAge)

            let billed = NSDecimalNumber(decimal: part.billedPrice.amount).doubleValue
            let market = cached?.price

            let diff = market != nil ? billed - market! : nil
            let percent = (market != nil && market! > 0)
                ? (diff! / market!) * 100
                : nil

            let imageKey = ImageCache.Key.partNumber(key)
            let cachedImage = ImageCache.shared.get(imageKey)

            results.append(
                PriceComparison(
                    part: part,
                    marketPrice: market != nil ? Money(amount: Decimal(market!)) : nil,
                    difference: diff != nil ? Money(amount: Decimal(diff!)) : nil,
                    percentage: percent != nil ? Decimal(percent!) : nil,
                    isOverpriced: diff != nil ? diff! > 0 : false,
                    marketURL: cached?.url,
                    imageURL: cached?.imageURL,
                    cachedImage: cachedImage
                )
            )
        }

        self.report = ComparisonReport(vehicle: vehicle, items: results)
        self.showPartsView = true

        print("🟢 INITIAL REPORT SET")

        // =========================
        // 🔥 ENRICH LOOP (NO CONTINUE!)
        // =========================
        for (index, part) in parts.enumerated() {

            let key = part.partNumber.rawValue
            let imageKey = ImageCache.Key.partNumber(key)

            print("🔁 LOOP ITEM:", key)

            let cached = await cache.getIfFresh(key, maxAge: maxAge)

            // =========================
            // 🔥 USE CACHE IF AVAILABLE
            // =========================
            if let cached, let price = cached.price, price > 0 {

                print("⚡ CACHE USED:", key)

                var cachedImage = ImageCache.shared.get(imageKey)

                // 🔥 CRITICAL FIX: load image if missing
                if cachedImage == nil,
                   let url = cached.imageURL,
                   let image = await ImageLoader.shared.load(url) {

                    ImageCache.shared.set(imageKey, image: image)
                    cachedImage = image

                    print("🌐 IMAGE LOADED FROM CACHE URL:", key)
                }

                let billed = NSDecimalNumber(decimal: part.billedPrice.amount).doubleValue
                let diff = billed - price
                let percent = price > 0 ? (diff / price) * 100 : nil

                results[index] = PriceComparison(
                    part: part,
                    marketPrice: Money(amount: Decimal(price)),
                    difference: Money(amount: Decimal(diff)),
                    percentage: percent != nil ? Decimal(percent!) : nil,
                    isOverpriced: diff > 0,
                    marketURL: cached.url,
                    imageURL: cached.imageURL,
                    cachedImage: cachedImage   // ✅ NOW NOT NIL
                )

                self.report = ComparisonReport(vehicle: vehicle, items: results)
                continue
            }

            // =========================
            // 🔥 FETCH FROM EBAY
            // =========================
            do {
                print("🌐 eBay FETCH:", key)

                let result = try await ebayService.searchPartWithLink(partNumber: key)
                let price = result.price > 0 ? result.price : nil

                // 🔥 IMAGE CACHE
                if ImageCache.shared.get(imageKey) == nil,
                   let url = result.imageURLs.first,
                   let image = await ImageLoader.shared.load(url) {

                    ImageCache.shared.set(imageKey, image: image)
                    print("🌐 IMAGE CACHED:", key)
                }

                await cache.set(
                    key,
                    value: CachedPrice(
                        price: price,
                        url: result.url,
                        imageURL: result.imageURLs.first,
                        timestamp: Date()
                    )
                )

                let billed = NSDecimalNumber(decimal: part.billedPrice.amount).doubleValue
                let diff = price != nil ? billed - price! : nil
                let percent = (price != nil && price! > 0)
                    ? (diff! / price!) * 100
                    : nil

                let cachedImage = ImageCache.shared.get(imageKey)

                results[index] = PriceComparison(
                    part: part,
                    marketPrice: price != nil ? Money(amount: Decimal(price!)) : nil,
                    difference: diff != nil ? Money(amount: Decimal(diff!)) : nil,
                    percentage: percent != nil ? Decimal(percent!) : nil,
                    isOverpriced: diff != nil ? diff! > 0 : false,
                    marketURL: result.url,
                    imageURL: result.imageURLs.first,
                    cachedImage: cachedImage
                )

                self.report = ComparisonReport(vehicle: vehicle, items: results)

                print("✅ eBay SUCCESS:", key)

            } catch {
                print("❌ eBay FAILED:", key, error.localizedDescription)
            }

            try? await Task.sleep(nanoseconds: 300_000_000)
        }

        print("🏁 FINISHED EBAY LOOP")
    }