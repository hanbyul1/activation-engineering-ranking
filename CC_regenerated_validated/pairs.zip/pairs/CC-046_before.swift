    
    func fetchDistractors(
        count: Int,
        excluding: Set<String>,
        seed: UInt64
    ) async -> [IngredientCard] {

        // ✅ 핵심: prepare 완료까지 기다림
        let ready = await prepareIfNeeded()
        guard ready else { return [] }

        return await withCheckedContinuation { cont in
            queue.async {

                guard self.db != nil, self.maxRowID > 0 else {
                    cont.resume(returning: [])
                    return
                }

                var rng = SeededRandomNumberGenerator(seed: seed)
                var results: [IngredientCard] = []
                results.reserveCapacity(count)

                let excludingLower = Set(excluding.map { $0.lowercased() })
                var used = Set<String>()

                let sqlForward = """
                SELECT
                    product_name,
                    energy_kcal_100g,
                    carbs_100g,
                    sugars_100g,
                    fiber_100g,
                    proteins_100g,
                    fat_100g,
                    saturated_fat_100g,
                    sodium_100g,
                    salt_100g,
                    nova_group,
                    nutrition_grade
                FROM products
                WHERE rowid >= ?
                  AND product_name IS NOT NULL
                  AND LENGTH(product_name) >= 3
                  AND product_name NOT GLOB '*[0-9]*'
                LIMIT 1;
                """

                let sqlWrap = """
                SELECT
                    product_name,
                    energy_kcal_100g,
                    carbs_100g,
                    sugars_100g,
                    fiber_100g,
                    proteins_100g,
                    fat_100g,
                    saturated_fat_100g,
                    sodium_100g,
                    salt_100g,
                    nova_group,
                    nutrition_grade
                FROM products
                WHERE rowid >= ?
                  AND product_name IS NOT NULL
                  AND LENGTH(product_name) >= 3
                  AND product_name NOT GLOB '*[0-9]*'
                LIMIT 1;
                """

                var stmtForward: OpaquePointer?
                var stmtWrap: OpaquePointer?

                sqlite3_prepare_v2(self.db, sqlForward, -1, &stmtForward, nil)
                sqlite3_prepare_v2(self.db, sqlWrap, -1, &stmtWrap, nil)

                let maxAttempts = count * 10 + 20
                var attempts = 0

                while results.count < count && attempts < maxAttempts {
                    attempts += 1
                    let anchor = Int64.random(in: 1...self.maxRowID, using: &rng)

                    var found = false

                    // 1️⃣ forward scan
                    sqlite3_reset(stmtForward)
                    sqlite3_clear_bindings(stmtForward)
                    sqlite3_bind_int64(stmtForward, 1, anchor)

                    if sqlite3_step(stmtForward) == SQLITE_ROW {
                        found = true
                    }

                    // 2️⃣ wrap-around scan
                    if !found {
                        sqlite3_reset(stmtWrap)
                        sqlite3_clear_bindings(stmtWrap)
                        sqlite3_bind_int64(stmtWrap, 1, anchor)

                        if sqlite3_step(stmtWrap) == SQLITE_ROW {
                            found = true
                        }
                    }

                    guard found else { continue }

                    let raw = String(cString: sqlite3_column_text(
                        found ? (sqlite3_column_text(stmtForward, 0) != nil ? stmtForward : stmtWrap) : stmtWrap,
                        0
                    ))

                    let lower = raw.lowercased()
                    if excludingLower.contains(lower) { continue }
                    if used.contains(lower) { continue }

                    used.insert(lower)
                    // stmt는 stmtForward 또는 stmtWrap 중 실제 row가 있는 쪽
                    let stmt = (sqlite3_column_text(stmtForward, 0) != nil) ? stmtForward! : stmtWrap!

                    let name = String(cString: sqlite3_column_text(stmt, 0))

                    let card = IngredientCard(
                        name: name.capitalized,
                        isCorrect: false,
                        calories: sqlite3_column_double(stmt, 1),
                        carbs: sqlite3_column_double(stmt, 2),
                        sugar: sqlite3_column_double(stmt, 3),
                        fiber: sqlite3_column_double(stmt, 4),
                        protein: sqlite3_column_double(stmt, 5),
                        fat: sqlite3_column_double(stmt, 6),
                        saturatedFat: sqlite3_column_double(stmt, 7),
                        sodium: sqlite3_column_double(stmt, 8),
                        salt: sqlite3_column_double(stmt, 9),
                        novaGroup: Int(sqlite3_column_int(stmt, 10)),
                        nutriScore: String(cString: sqlite3_column_text(stmt, 11)),
                        clusterID: nil
                    )

                    results.append(card)
                }

                sqlite3_finalize(stmtForward)
                sqlite3_finalize(stmtWrap)

                cont.resume(returning: results)
            }
        }
    }