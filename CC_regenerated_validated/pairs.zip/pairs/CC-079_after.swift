private func extractFlexibleDescription(texts: [String], partIndex: Int) -> String {
    return extractFlexibleDescriptionCore(texts, partIndex)
}

    
    private func extractFlexibleDescriptionCore(texts: [String], partIndex: Int) -> String {
        
        var descParts: [String] = []
        
        // 1. Try RIGHT side first (existing behavior)
        for i in (partIndex+1)..<texts.count {
            
            let text = texts[i].uppercased()
            
            if text.range(of: #"^\d+(\.\d{2})?$"#, options: .regularExpression) != nil {
                break
            }
            
            if Int(text) != nil { continue }
            
            descParts.append(texts[i])
        }
        
        if !descParts.isEmpty {
            return descParts.joined(separator: " ")
        }
        
        // 🔥 2. SAFE LEFT fallback (for receipts like your new example)
        descParts = []
        
        for i in stride(from: partIndex-1, through: 0, by: -1) {
            
            let text = texts[i].uppercased()
            
            // stop if we hit structured fields
            if text.contains("REPL") ||
                text.contains("QTY") ||
                text.contains("PRICE") {
                break
            }
            
            if text.range(of: #"^\d+(\.\d{2})?$"#, options: .regularExpression) != nil {
                continue
            }
            
            if Int(text) != nil { continue }
            
            descParts.insert(texts[i], at: 0)
        }
        
        if !descParts.isEmpty {
            return descParts.joined(separator: " ")
        }
        
        return "No description"
    }