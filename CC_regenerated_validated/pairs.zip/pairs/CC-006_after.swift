func extractUtilityFields(
        _ blockItems: [OCRItem],
        tokenItems: [OCRItem],
        rows: [OCRRow],
        fullText: String
    ) -> [String: String] {
    return extractUtilityFieldsCore(blockItems, tokenItems, rows, fullText)
}


    func extractUtilityFieldsCore(
        _ blockItems: [OCRItem],
        tokenItems: [OCRItem],
        rows: [OCRRow],
        fullText: String
    ) -> [String: String] {

        var result: [String: String] = [:]

        result["account_number"] =
            findAccountNumberGeneric(rows)

        result["service_period"] =
            extractGasServicePeriod(fullText)
            ?? extractServicePeriodWithLabel(rows)
            ?? extractServicePeriodTableRow(rows)
            ?? extractServicePeriodGeneric(rows)
            ?? mergeSplitServicePeriods(rows)
            ?? findServicePeriodFromFullText(fullText)
            ?? extractServicePeriodLoose(rows)

        result["due_date"] =
            findDueDateFromFullText(fullText) ??
            extractDueDate(rows) ??
            extractDateFromTokens(tokenItems) ??
            findDateNearLabel(
                keywordSets: [
                    ["WITHDRAWAL"],
                    ["WITHDRAW"],
                    ["DUE", "DATE"],
                    ["PAY", "BY"],
                    ["PAYMENT", "DUE"],
                    ["AFTER"]
                ],
                items: tokenItems
            ) ??
            findDateBelowKeyword("WITHDRAW", items: tokenItems) ??
            findDueDateFromRows(rows) ??
            findSingleDateFallback(rows)

        result["amount_due"] =
            findAutoPayAmount(rows) ??
            findWithdrawalAmount(rows) ??
            findAmountDueFromRows(rows) ??
            extractAmountFromRows(rows) ??
            findAmountNearLabelFlexible(
                keywordSets: [
                    ["AMOUNT", "DUE"],
                    ["TOTAL", "DUE"],
                    ["CURRENT", "CHARGES"],
                    ["WITHDRAWAL", "AMOUNT"]
                ],
                items: tokenItems
            )

        if result["amount_due"] == nil {
            result["amount_due"] = findAmountNearLabelFlexible(
                keywordSets: [
                    ["AMOUNT", "DUE"],
                    ["TOTAL", "ENERGY", "CHARGES"]
                ],
                items: tokenItems
            )
        }

        // 🔥 핵심 수정 (반드시)
        if let address = extractAddress(from: blockItems) {
            result["address"] = address
        }

        if result["usage"] == nil {
            let hasUsageSignal = rows.contains {
                let t = $0.fullText.uppercased()
                return t.contains("CCF") ||
                       t.contains("MCF") ||
                       t.contains("KWH") ||
                       t.contains("USAGE")
            }

            if hasUsageSignal {
                if let usage = extractUsageFromRows(rows) {
                    result["usage"] = usage
                }
            }
        }

        return result
    }