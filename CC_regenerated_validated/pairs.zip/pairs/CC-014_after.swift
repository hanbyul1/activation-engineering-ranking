private func extractWaterUsageWithUnit(
        _ rows: [OCRRow]
    ) -> (Double?, String?) {
    return extractWaterUsageWithUnitCore(rows)
}


    private func extractWaterUsageWithUnitCore(
        _ rows: [OCRRow]
    ) -> (Double?, String?) {

        print("💧 WATER USAGE EXTRACTION START")

        var candidates: [Double] = []

        // =================================================
        // 1️⃣ 기존 방식 (절대 유지) → "$ 앞 숫자"
        // =================================================
        for row in rows {

            let upper = row.fullText.uppercased()

            if upper.contains("CU FT") ||
               upper.contains("READ") ||
               upper.contains("CODE") ||
               upper.contains("AMOUNT DUE") ||
               upper.contains("LATE AMOUNT") {
                continue
            }

            let tokens = row.fullText
                .replacingOccurrences(of: ",", with: "")
                .components(separatedBy: " ")
                .filter { !$0.isEmpty }

            for i in 0..<(tokens.count - 1) {

                let current = tokens[i]
                let next = tokens[i + 1]

                // 🔥 기존 유지
                if next.contains("$"),
                   let value = Double(current),
                   value > 0 && value < 100 {

                    candidates.append(value)
                }
            }
        }

        // =================================================
        // 2️⃣ NEW: CCF 기반 (table 구조 대응)
        // =================================================
        if candidates.isEmpty {

            print("⚠️ fallback → CCF pattern")

            for row in rows {

                let upper = row.fullText.uppercased()

                if !upper.contains("CCF") { continue }

                let tokens = row.fullText
                    .replacingOccurrences(of: ",", with: "")
                    .components(separatedBy: " ")
                    .filter { !$0.isEmpty }

                for i in 0..<tokens.count {

                    if tokens[i].uppercased() == "CCF", i > 0 {

                        let prev = tokens[i - 1]

                        if let value = Double(prev),
                           value > 0 && value < 100 {

                            print("✅ CCF usage found:", value)
                            candidates.append(value)
                        }
                    }
                }
            }
        }

        // =================================================
        // 3️⃣ NEW: meter table (generic water)
        // =================================================
        if candidates.isEmpty {

            print("⚠️ fallback → METER TABLE pattern")

            for row in rows {

                let upper = row.fullText.uppercased()

                // 👉 핵심: meter row 감지
                if upper.contains("METER") ||
                   upper.contains("PREVIOUS") ||
                   upper.contains("CURRENT") {
                    continue
                }

                // 👉 실제 데이터 row
                let numbers = row.fullText.matches(for: #"\d+"#)
                    .compactMap { Int($0[0]) }

                // 최소 3개 숫자 있어야 table row
                if numbers.count >= 3 {

                    let prev = numbers[numbers.count - 3]
                    let curr = numbers[numbers.count - 2]
                    let usage = numbers[numbers.count - 1]

                    // 👉 sanity check
                    if usage > 0 && usage < 1000 &&
                       curr >= prev {

                        print("✅ TABLE usage found:", usage)
                        candidates.append(Double(usage))
                    }
                }
            }
        }
        
        // =================================================
        // 3️⃣ 선택 로직 (기존 유지)
        // =================================================
        guard !candidates.isEmpty else {
            print("❌ WATER usage not found")
            return (nil, "CCF")
        }

        let freq = Dictionary(grouping: candidates, by: { $0 })
            .mapValues { $0.count }

        let best = freq.max { $0.value < $1.value }?.key

        print("✅ WATER final usage:", best as Any)
        return (best, "CCF")
    }