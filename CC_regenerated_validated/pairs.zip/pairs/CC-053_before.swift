
    func execute(for type: String) -> AnalysisResult {

        var anomalyDetail: AnomalyDetail? = nil   // 🔥 추가

        let documents = repository.loadAll()
            .filter { $0.type.lowercased().contains(type.lowercased()) }

        let points = documents
            .compactMap { mapToPoint($0) }
            .sorted { $0.date < $1.date }

        // 🔥 순수 계산 (Domain)
        let result = engine.analyze(points)

        // 🔥 AI 해석 (Application Layer)
        let explanations: [String]

        if points.count >= 2 {
            let prev = points[points.count - 2]
            let curr = points[points.count - 1]

            if let ai = aiAnalyzer.analyze(prev: prev, curr: curr) {

                explanations = [
                    "Trend: \(ai.trend)",
                    "Anomaly: \(ai.anomaly == 1 ? "Yes" : "No")",
                    "Driver: \(ai.driver)"
                ]

                // 🔥🔥🔥 여기 추가
                if ai.anomaly == 1 {

                    let expected = prev.amount
                    let actual = curr.amount
                    let delta = actual - expected
                    let percent = expected > 0 ? (delta / expected) * 100 : 0

                    anomalyDetail = AnomalyDetail(
                        period: formatDate(curr.date),
                        actualAmount: actual,
                        expectedAmount: expected,
                        deltaAmount: delta,
                        deltaPercent: percent,
                        driver: ai.driver,
                        summary: "Bill increased mainly due to \(ai.driver)"
                    )
                }

            } else {
                explanations = ["AI analysis failed"]
            }

        } else {
            explanations = []
        }

        // 🔥 dataset
        let normalizedType = type.lowercased()

        let datasetType: DatasetType? =
            normalizedType.contains("electric") ? .electricityPrice :
            normalizedType.contains("gas") ? .gasPrice :
            nil

        let pricePoints: [TimeSeriesPoint] = {

            guard let datasetType else { return [] }

            let datasetName =
                datasetType == .electricityPrice ? "electricity_price" :
                datasetType == .gasPrice ? "natural_gas_price" :
                ""

            let prices = priceRepository.fetchPrices(for: datasetName)

            return points.compactMap { p in

                if let match = prices.min(by: { a, b in

                    let target = p.date

                    let dateA = Calendar.current.date(from: DateComponents(year: a.year, month: a.month))!
                    let dateB = Calendar.current.date(from: DateComponents(year: b.year, month: b.month))!

                    return abs(dateA.timeIntervalSince(target)) < abs(dateB.timeIntervalSince(target))

                }) {
                    return TimeSeriesPoint(
                        date: p.date,
                        amount: match.value,
                        usage: nil
                    )
                }
                return nil
            }
        }()

        return AnalysisResult(
            trend: result.trend,
            averageAmount: result.averageAmount,
            anomalies: result.anomalies,
            points: result.points,
            explanations: explanations,
            pricePoints: pricePoints,
            datasetType: datasetType,
            anomalyDetail: anomalyDetail   // 🔥🔥🔥 핵심
        )
    }