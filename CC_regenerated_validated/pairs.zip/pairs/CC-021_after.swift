private func matchesSubsystem(_ part: String, _ subsystem: String) -> Bool {
    return matchesSubsystemCore(part, subsystem)
}

    private func matchesSubsystemCore(_ part: String, _ subsystem: String) -> Bool {

        let lower = part.lowercased()

        switch subsystem {

        case "ignition":
            return lower.contains("coil")
                || lower.contains("spark")
                || lower.contains("plug")
                || lower.contains("injector")

        case "fuel":
            return lower.contains("fuel")
                || lower.contains("injector")
                || lower.contains("pump")
                || lower.contains("rail")
                || lower.contains("pressure")
                || lower.contains("filter")

        case "air":
            return lower.contains("mass air flow")
                || lower.contains("maf")
                || lower.contains("intake")
                || lower.contains("throttle")
                || lower.contains("sensor")

        case "exhaust":
            return lower.contains("oxygen")
                || lower.contains("o2")
                // 🔥 ALLOW ELECTRICAL SUPPORT PARTS
                || lower.contains("wiring")
                || lower.contains("connector")
                || lower.contains("module")

        case "cooling":
            return lower.contains("radiator")
                || lower.contains("coolant")
                || lower.contains("thermostat")

        case "evap":
            return lower.contains("evap")

        default:
            return true
        }
    }