
    private func isStopLine(_ raw: String) -> Bool {
        let k = normalizedKey(raw)

        // 1) Other ingredients (OCR 오타 포함)  ← 이게 제일 중요
        // otheringredients / orheringredients / otneringredients 등
        if k.contains("other") && k.contains("ingredient") { return true }
        if k.contains("orher") && k.contains("ingredient") { return true }
        if k.contains("otner") && k.contains("ingredient") { return true }

        // 2) 주소/웹사이트류 (보험)
        if k.contains("nowfoods") { return true }
        if k.contains("com") || k.contains("www") { return true }
        if k.contains("usa") { return true }
        // state+zip 패턴(대충): il60108 같은 형태를 잡고 싶으면 아래도 추가 가능
        if k.range(of: #"[a-z]{2}\d{5}"#, options: .regularExpression) != nil { return true }

        return false
    }