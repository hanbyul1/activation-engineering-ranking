static func buildIngredientSpace(
        canonicals: [IngredientCard],
        globalPool: [IngredientCard],
        stageNumber: Int
    ) -> StageIngredientSpace {
    return buildIngredientSpaceCore(canonicals, globalPool, stageNumber)
}

    
    static func buildIngredientSpaceCore(
        canonicals: [IngredientCard],
        globalPool: [IngredientCard],
        stageNumber: Int
    ) -> StageIngredientSpace {

        print("🧩 canonicals.count = \(canonicals.count)")
        
        let picker = IngredientAlternativePicker()
        let inferencer = IngredientRoleInferencer()

        func norm(_ s: String) -> String {
            s.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        }

        // ✅ 1️⃣ 전역 중복 방지용 used set
        var usedNames = Set<String>()

        // ✅ Level 기반 canonical 개수 규칙 (chapter 무시)
        func canonicalCountRange(for stageNumber: Int) -> ClosedRange<Int> {
            switch stageNumber {
            case 1...2:   return 1...2
            case 3...10:  return 3...4
            case 11...20: return 4...5
            default:      return 6...8
            }
        }

//        // ✅ canonicals가 너무 많으면 level 규칙에 맞게 "잘라서" 사용 (결정적 랜덤)
//        let selectedCanonicals: [IngredientCard] = {
//            let range = canonicalCountRange(for: stageNumber)
//            let upper = min(range.upperBound, canonicals.count)
//
//            guard upper > 0 else { return [] }
//
//            let targetCount = upper   // ✅ 항상 upperBound 사용
//            return Array(canonicals.prefix(targetCount))
//        }()

        // ✅ Level 정책을 강제로 만족하는 canonical 선택 로직
        let selectedCanonicals: [IngredientCard] = {
            let range = canonicalCountRange(for: stageNumber)
            let required = range.lowerBound   // ⭐ 최소 개수 보장

            var base = canonicals

            // ✅ canonical이 부족하면 globalPool에서 보강
            if base.count < required {
                let needed = required - base.count

                let fillers = globalPool
                    .filter { candidate in
                        let name = norm(candidate.name)
                        return !base.contains { norm($0.name) == name }
                    }
                    .shuffled()
                    .prefix(needed)

                base.append(contentsOf: fillers)
            }

            // 최종 개수는 upperBound까지
            let upper = min(range.upperBound, base.count)
            return Array(base.prefix(upper))
        }()
        
        var clusters: [IngredientCluster] = []
        clusters.reserveCapacity(canonicals.count)
        
        // ✅ 2️⃣ canonical 먼저 등록 (절대 중복 금지)
        for c in selectedCanonicals {
            usedNames.insert(norm(c.name))
        }

        clusters.reserveCapacity(selectedCanonicals.count)

        // 🔁 fallback: 역할 기반 채우기
        func roleFallback(
            canonical: IngredientCard,
            need: Int,
            seed: UInt64
        ) -> [IngredientCard] {

            if need <= 0 { return [] }

            let canonInf = inferencer.infer(
                name: canonical.name,
                macros: MacroProfile(
                    calories: canonical.calories,
                    carbs: canonical.carbs,
                    protein: canonical.protein,
                    fat: canonical.fat,
                    sugar: canonical.sugar,
                    fiber: canonical.fiber,
                    sodium: canonical.sodium
                )
            )

            var candidates: [(IngredientCard, Double)] = []

            for card in globalPool {
                let key = norm(card.name)
                if usedNames.contains(key) { continue }
                if key == norm(canonical.name) { continue }

                let inf = inferencer.infer(
                    name: card.name,
                    macros: MacroProfile(
                        calories: card.calories,
                        carbs: card.carbs,
                        protein: card.protein,
                        fat: card.fat,
                        sugar: card.sugar,
                        fiber: card.fiber,
                        sodium: card.sodium
                    )
                )

                // ✅ HARD RULE: 영양 역할 동일
                guard inf.role == canonInf.role else { continue }

                candidates.append((card, inf.confidence))
            }

            // confidence 높은 순
            candidates.sort { $0.1 > $1.1 }

            var top = candidates.prefix(60).map { $0.0 }
            var rng = SeededRandomNumberGenerator(seed: seed)
            top.shuffle(using: &rng)

            return Array(top.prefix(need))
        }

        // 🔁 fallback 2: 역할 무시하고도 중복 없이 채우기 (최후 수단)
        func relaxedFallback(
            canonical: IngredientCard,
            need: Int,
            seed: UInt64
        ) -> [IngredientCard] {
            if need <= 0 { return [] }

            // usedNames에 없는 것만
            var candidates: [IngredientCard] = globalPool.filter { card in
                let key = norm(card.name)
                if usedNames.contains(key) { return false }
                if key == norm(canonical.name) { return false }
                return true
            }

            var rng = SeededRandomNumberGenerator(seed: seed)
            candidates.shuffle(using: &rng)
            return Array(candidates.prefix(need))
        }
        
        // ─────────────────────────────
        // 클러스터 생성
        // ─────────────────────────────
        for (clusterIndex, canonical) in selectedCanonicals.enumerated() {

            // ✅ canonical 카드에 clusterID 주입
            let canonicalCard = IngredientCard(
                name: canonical.name,
                isCorrect: true,
                calories: canonical.calories,
                carbs: canonical.carbs,
                sugar: canonical.sugar,
                fiber: canonical.fiber,
                protein: canonical.protein,
                fat: canonical.fat,
                saturatedFat: canonical.saturatedFat,
                sodium: canonical.sodium,
                salt: canonical.salt,
                novaGroup: canonical.novaGroup,
                nutriScore: canonical.nutriScore,
                clusterID: clusterIndex          // ⭐️ 핵심
            )

            // ✅ picker에 줄 pool 자체에서 전역 중복 제거
            let filteredPool = globalPool.filter {
                let key = norm($0.name)
                return !usedNames.contains(key) && key != norm(canonical.name)
            }

            // 1️⃣ picker 먼저 시도
            var alternatives = picker.pickAlternatives(
                for: canonical,
                from: filteredPool,
                count: 2,
                seed: UInt64(stageNumber * 100 + clusterIndex)
            )

            // 2️⃣ 부족하면 fallback
            // 2️⃣ 부족하면 role fallback
            if alternatives.count < 2 {
                let fillers = roleFallback(
                    canonical: canonical,
                    need: 2 - alternatives.count,
                    seed: UInt64(stageNumber * 1000 + clusterIndex)
                )
                alternatives.append(contentsOf: fillers)
            }

            // 2️⃣-2 그래도 부족하면 "역할 무시" fallback (중복 금지 유지)
            if alternatives.count < 2 {
                let fillers = relaxedFallback(
                    canonical: canonical,
                    need: 2 - alternatives.count,
                    seed: UInt64(stageNumber * 33333 + clusterIndex)
                )
                alternatives.append(contentsOf: fillers)
            }

            // 3️⃣ 최종적으로 전역 중복 다시 한번 차단
            var finalAlternatives: [IngredientCard] = []
            for alt in alternatives {
                let key = norm(alt.name)
                guard !usedNames.contains(key) else { continue }
                finalAlternatives.append(alt)
                usedNames.insert(key)
                if finalAlternatives.count == 2 { break }
            }

            if finalAlternatives.count < 2 {
                print("⚠️ Not enough unique alternatives for \(canonical.name)")
            }
            
            // ✅ ⬇️⬇️⬇️ 바로 여기! (이 위치에 넣는다)
            while finalAlternatives.count < 2 {
                let filler = IngredientCard(
                    name: "\(canonical.name) (variant \(finalAlternatives.count + 1))",
                    isCorrect: false,
                    calories: canonical.calories,
                    carbs: canonical.carbs,
                    sugar: canonical.sugar,
                    fiber: canonical.fiber,
                    protein: canonical.protein,
                    fat: canonical.fat,
                    saturatedFat: canonical.saturatedFat,
                    sodium: canonical.sodium,
                    salt: canonical.salt,
                    novaGroup: canonical.novaGroup,
                    nutriScore: canonical.nutriScore,
                    clusterID: clusterIndex
                )
                finalAlternatives.append(filler)
            }

            // ✅ alternatives에도 동일 clusterID 주입
            let fixedAlternatives = finalAlternatives.map { alt in
                IngredientCard(
                    name: alt.name,
                    isCorrect: true,
                    calories: alt.calories,
                    carbs: alt.carbs,
                    sugar: alt.sugar,
                    fiber: alt.fiber,
                    protein: alt.protein,
                    fat: alt.fat,
                    saturatedFat: alt.saturatedFat,
                    sodium: alt.sodium,
                    salt: alt.salt,
                    novaGroup: alt.novaGroup,
                    nutriScore: alt.nutriScore,
                    clusterID: clusterIndex        // ⭐️ 핵심
                )
            }

            clusters.append(
                IngredientCluster(
                    id: clusterIndex,  
                    canonical: canonicalCard,     // ✅ 기존 canonical ❌ → 새 canonicalCard ✅
                    alternatives: fixedAlternatives
                )
            )
        }

        // ✅ allCandidates는 이제 “그냥 펼치기만” 하면 된다 (중복 없음)
        let allCandidates = clusters.flatMap { [$0.canonical] + $0.alternatives }

        return StageIngredientSpace(
            clusters: clusters,
            allCandidates: allCandidates
        )
    }