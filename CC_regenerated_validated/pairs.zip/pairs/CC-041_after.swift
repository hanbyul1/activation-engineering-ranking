private func symptomKeyword(for tag: String) -> String {
    return symptomKeywordCore(tag)
}

    
    private func symptomKeywordCore(for tag: String) -> String {
        switch tag.lowercased() {

        case "cold":
            return "cold start"

        case "start":
            return "hard start"

        case "stall":
            return "stalling"

        case "fuel_economy":
            return "poor fuel economy"

        case "rough_idle":
            return "rough idle"

        case "idle":
            return "idle problem"

        case "air":
            return "air intake"

        case "fuel":
            return "fuel system"

        case "power_loss":
            return "loss of power"

        case "acceleration":
            return "poor acceleration"

        case "misfire":
            return "engine misfire"

        case "ignition":
            return "ignition issue"

        case "sensor":
            return "sensor issue"

        case "exhaust":
            return "exhaust issue"

        default:
            return tag.replacingOccurrences(of: "_", with: " ")
        }
    }