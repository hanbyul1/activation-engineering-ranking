private func rowContent(
        _ item: MKMapItem,
        showArrow: Bool
    ) -> some View {
    return rowContentCore(item, showArrow)
}


    private func rowContentCore(
        _ item: MKMapItem,
        showArrow: Bool
    ) -> some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                let rawName = item.name
                let displayName = rawName ?? "Unknown"
                let keyName = rawName ?? ""

                Text(displayName)
                    .foregroundColor(
                        favoriteStore.isFavorite(keyName)
                        ? .yellow
                        : .white
                    )
                    .foregroundColor(.white)
                    .font(.system(size: 15, weight: .medium))

                if let category = item.pointOfInterestCategory {
                    Text(displayCategoryName(category))
                        .font(.caption2)
                        .foregroundColor(Color.white.opacity(0.8))
                }
            }

            Spacer()

            Spacer()

            if let distance = distanceString(for: item) {
                Text(distance)
                    .font(.caption)
                    .foregroundColor(.white.opacity(0.65))
            }

            if showArrow {
                Image(systemName: "chevron.right")
                    .foregroundColor(.white.opacity(0.4))
            }  
        }
        .padding(12)
        .background(
            RoundedRectangle(cornerRadius: 12)
                .fill(Color.white.opacity(showArrow ? 0.06 : 0.045))
        )
    }