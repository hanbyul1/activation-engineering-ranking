private func parseIngredientsOptimized(
        title: String,
        body: String,
        using db: [String: IngredientInfo],
        embedder: MiniLMEmbedderService,
        recipeIndex: RecipeEmbeddingIndex
    ) -> [IngredientLine] {
    return parseIngredientsOptimizedCore(title, body, db, embedder, recipeIndex)
}

    
    private func parseIngredientsOptimizedCore(
        title: String,
        body: String,
        using db: [String: IngredientInfo],
        embedder: MiniLMEmbedderService,
        recipeIndex: RecipeEmbeddingIndex
    ) -> [IngredientLine] {

        var results: [IngredientLine] = []

        func normalize(_ s: String) -> String {
            s.lowercased()
                .replacingOccurrences(of: "[^a-z ]", with: " ", options: .regularExpression)
                .replacingOccurrences(of: "\\s+", with: " ", options: .regularExpression)
                .trimmingCharacters(in: .whitespaces)
        }

        // ✅ “ingredient(단어/구)”가 phrase의 끝에 있으면 phrase를 살리고, 아니면 ingredient만
        //    (two-word에서도 그대로 재사용)
        func makeDisplay(from phrase: String, ingredient: String) -> String {

            func stripTrailingPunctuation(_ s: String) -> String {
                s.trimmingCharacters(in: CharacterSet(charactersIn: ".,;:"))
            }

            let normalizedPhrase = normalize(phrase)
            let words = normalizedPhrase.split(separator: " ").map(String.init)

            let ingWords = ingredient.split(separator: " ").map(String.init)
            if ingWords.isEmpty {
                return stripTrailingPunctuation(ingredient)
            }

            // ingredient가 phrase 마지막에 정확히 붙는 경우 (single or bigram)
            if words.count >= ingWords.count {
                let tail = Array(words.suffix(ingWords.count))
                if tail == ingWords {
                    return stripTrailingPunctuation(
                        phrase.trimmingCharacters(in: .whitespaces)
                    )
                }
            }

            // 그 외: ingredient만 출력
            return stripTrailingPunctuation(ingredient)
        }

        let source = body.trimmingCharacters(in: .whitespaces).isEmpty ? title : body

        // 🔹 calorie DB lookup (정규화 키 -> 원본 DB key)
        let lookup: [String: String] = db.keys.reduce(into: [:]) { dict, key in
            let n = normalize(key)
            dict[n] = key
            if n.hasSuffix("s") {
                dict[String(n.dropLast())] = key
            }
        }

        // 🔹 phrase 분해
        let phrases = source
            .components(separatedBy: CharacterSet(charactersIn: ","))
            .flatMap { $0.components(separatedBy: " with ") }
            .flatMap { $0.components(separatedBy: " and ") }
            .map { $0.trimmingCharacters(in: .whitespaces) }
            .filter { !$0.isEmpty }

        var seenKeys = Set<String>()

        print("🍽 Ingredient parsing START → '\(title)'")

        // =========================================================
        // 🅰️ PASS 1: SINGLE-WORD ONLY (하나라도 나오면 two-word 안함)
        // =========================================================
        for phrase in phrases {

            let clean = normalize(phrase)
            let words = clean.split(separator: " ").map(String.init)

//            print("🔎 PHRASE(raw) = '\(phrase)'")
//            print("   🧼 clean = '\(clean)'")
//            print("   🧩 words = \(words)")

            for w in words {
                // ✅ single-word만 허용
                guard foodOnlySingles.contains(w) else { continue }

                // 🚫 noise 필터
                if isGenericNoise(w) {
                    print("   ⛔️ SKIP noise → '\(w)'")
                    continue
                }

//                print("   🎯 single ingredient candidate = '\(w)'")

                // calorie DB 매칭
                if let dbKey = lookup[w],
                   let info = db[dbKey],
                   !seenKeys.contains(dbKey) {

                    let display = makeDisplay(from: phrase, ingredient: w)

                    results.append(
                        IngredientLine(
                            key: dbKey,
                            display: display,
                            grams: gramsFrom(info.unit),
                            calPerUnit: info.calories,
                            unit: normalizeUnit(info.unit)
                        )
                    )

                    seenKeys.insert(dbKey)
//                    print("   ✅ SINGLE DB HIT → '\(dbKey)'")
                }
            }
        }

        // title fallback도 single-word로만 (기존 유지)
        if results.isEmpty {
            print("🔁 FALLBACK(single) → try title-based single-word parsing")

            let titleWords = normalize(title)
                .split(separator: " ")
                .map(String.init)

            for w in titleWords {

                guard foodOnlySingles.contains(w) else { continue }
                if isGenericNoise(w) { continue }

                print("   🔁 title single ingredient candidate = '\(w)'")

                if let dbKey = lookup[w],
                   let info = db[dbKey] {

                    results.append(
                        IngredientLine(
                            key: dbKey,
                            display: makeDisplay(from: title, ingredient: w),
                            grams: gramsFrom(info.unit),
                            calPerUnit: info.calories,
                            unit: normalizeUnit(info.unit)
                        )
                    )

                    print("   ✅ TITLE SINGLE HIT → '\(dbKey)'")
                    break
                }
            }
        }

        // ✅ single-word가 하나라도 있으면 여기서 종료 (two-word 안봄)
        if !results.isEmpty {
            print("🍽 Ingredient parsing END (single) → found \(results.count) items")
            return results
        }

        // =========================================================
        // 🅱️ PASS 2: TWO-WORD (single이 완전 실패했을 때만)
        //  - 1) phrase에서 bigram 완전 매칭 우선
        //  - 2) 없으면 마지막 단어(w2) 기반으로 two-word 후보 중 첫번째 pick
        //  - 칼로리는 two-word 전체로 lookup
        //  - UI에는 실제 매칭된 단어만 남김 (둘다 매칭이면 둘다 유지, 아니면 w2만)
        // =========================================================
        print("🧯 NO single-word match → try two-word parsing")

        for phrase in phrases {

            let clean = normalize(phrase)
            let words = clean.split(separator: " ").map(String.init)
            if words.isEmpty { continue }

            // ---- (1) bigram 완전 매칭 시도 ----
            var pickedTwo: String? = nil
            var uiKept: String? = nil

            if words.count >= 2 {
                for i in 0..<(words.count - 1) {
                    let w1 = words[i]
                    let w2 = words[i + 1]
                    let bigram = "\(w1) \(w2)"

                    if foodOnlyTwoWords.contains(bigram) && !isGenericNoise(w1) && !isGenericNoise(w2) {
                        pickedTwo = bigram
                        uiKept = bigram // ✅ 둘 다 매칭 → UI에 둘 다 남김
                        break
                    }
                }
            }

            // ---- (2) bigram 없으면 마지막 단어(w2) 매칭 ----
            if pickedTwo == nil {
                // phrase 안의 어떤 단어든 “마지막 단어 후보”가 될 수 있음.
                // 여러 후보면 “첫번째 pick”이므로 phrase 순서대로 검사
                for w2 in words {
                    if isGenericNoise(w2) { continue }
                    if let candidates = foodOnlyTwoWordsBySecond[w2], let first = candidates.first {
                        pickedTwo = first
                        uiKept = w2 // ✅ 일부만 매칭 → UI에는 매칭된 단어(w2)만
                        break
                    }
                }
            }

            guard let twoKey = pickedTwo, let uiWord = uiKept else { continue }

            // calorie DB는 two-word 전체 문자열로 lookup
            let twoNorm = normalize(twoKey)
            guard let dbKey = lookup[twoNorm], let info = db[dbKey] else {
                // DB에 없으면 skip
                continue
            }

            if seenKeys.contains(dbKey) { continue }

            let display = makeDisplay(from: phrase, ingredient: uiWord)

            results.append(
                IngredientLine(
                    key: dbKey,                 // ✅ 칼로리/키는 two-word 전체
                    display: display,           // ✅ UI는 매칭된 단어만 남긴 뒤 phrase 결합
                    grams: gramsFrom(info.unit),
                    calPerUnit: info.calories,
                    unit: normalizeUnit(info.unit)
                )
            )

            seenKeys.insert(dbKey)

            print("   ✅ TWO-WORD DB HIT → key='\(dbKey)'  ui='\(uiWord)'  phrase='\(phrase)'")

            // ✅ “여러 개면 첫번째 pick” 규칙 → phrase에서 하나 잡았으면 break
            break
        }

        // title 기반 two-word fallback (body가 있었던 경우에만 한번 더)
        if results.isEmpty && !body.trimmingCharacters(in: .whitespaces).isEmpty {
            print("🔁 FALLBACK(two) → try title-based two-word parsing")

            let tClean = normalize(title)
            let tWords = tClean.split(separator: " ").map(String.init)

            var pickedTwo: String? = nil
            var uiKept: String? = nil

            if tWords.count >= 2 {
                for i in 0..<(tWords.count - 1) {
                    let bigram = "\(tWords[i]) \(tWords[i+1])"
                    if foodOnlyTwoWords.contains(bigram) {
                        pickedTwo = bigram
                        uiKept = bigram
                        break
                    }
                }
            }

            if pickedTwo == nil {
                for w2 in tWords {
                    if let candidates = foodOnlyTwoWordsBySecond[w2], let first = candidates.first {
                        pickedTwo = first
                        uiKept = w2
                        break
                    }
                }
            }

            if let twoKey = pickedTwo, let uiWord = uiKept {
                let twoNorm = normalize(twoKey)
                if let dbKey = lookup[twoNorm], let info = db[dbKey] {
                    let display = makeDisplay(from: title, ingredient: uiWord)
                    results.append(
                        IngredientLine(
                            key: dbKey,
                            display: display,
                            grams: gramsFrom(info.unit),
                            calPerUnit: info.calories,
                            unit: normalizeUnit(info.unit)
                        )
                    )
                    print("   ✅ TITLE TWO-WORD HIT → key='\(dbKey)' ui='\(uiWord)'")
                }
            }
        }

        print("🍽 Ingredient parsing END → found \(results.count) items")
        return results
    }