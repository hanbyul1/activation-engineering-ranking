
    private func handleReorder(feature: FeatureButtonModel, translation: CGSize) {
        guard
            let startIndex = dragStartIndex
                ?? recipeButtonStore.buttons.firstIndex(where: { $0.id == feature.id })
        else { return }

        if dragStartIndex == nil {
            dragStartIndex = startIndex
            lastTargetIndex = startIndex
        }

        let columns = 3

        // ⚠️ Home과 동일한 값 (버튼 프레임/spacing과 반드시 일치해야 함)
        let itemWidth: CGFloat = 100
        let itemHeight: CGFloat = 90
        let spacing: CGFloat = 25

        let stepX = itemWidth + spacing
        let stepY = itemHeight + spacing

        let deltaColumn = Int((translation.width / stepX).rounded())
        let deltaRow = Int((translation.height / stepY).rounded())

        let rawTarget = (dragStartIndex ?? startIndex) + deltaRow * columns + deltaColumn
        let targetIndex = max(0, min(recipeButtonStore.buttons.count - 1, rawTarget))

        if targetIndex == lastTargetIndex { return }

        withAnimation(.spring(response: 0.25)) {
            recipeButtonStore.buttons.move(
                fromOffsets: IndexSet(integer: lastTargetIndex ?? startIndex),
                toOffset: targetIndex > (lastTargetIndex ?? startIndex) ? targetIndex + 1 : targetIndex
            )
        }

        lastTargetIndex = targetIndex
    }