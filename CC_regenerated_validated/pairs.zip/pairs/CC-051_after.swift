private func extractCrossRowParts(_ tokens: [OCRToken]) -> [Part] {
    return extractCrossRowPartsCore(tokens)
}

    
    private func extractCrossRowPartsCore(_ tokens: [OCRToken]) -> [Part] {

        let rows = groupTokensIntoRows(tokens)
        var parts: [Part] = []

        for i in 0..<rows.count {

            let texts = rows[i].map { $0.text }

            // 🔥 detect loose part number (Ford style)
            guard let partIndex = texts.firstIndex(where: {
                isLoosePartNumber($0)
            }) else { continue }

            let partNumber = texts[partIndex]

            // 🔥 find price in SAME row first
            var price: Decimal? = texts.compactMap { text in
                let cleaned = text
                    .replacingOccurrences(of: ",", with: "")
                    .replacingOccurrences(of: ":", with: ".")

                if cleaned.range(of: #"^\d+\.\d{2}$"#, options: .regularExpression) != nil {
                    return Decimal(string: cleaned)
                }
                return nil
            }.min()

            // 🔥 if not found → search NEXT rows (critical fix)
            if price == nil {
                for j in (i+1)..<min(i+4, rows.count) {

                    let nextTexts = rows[j].map { $0.text }

                    if let found = nextTexts.compactMap({ text -> Decimal? in
                        let cleaned = text
                            .replacingOccurrences(of: ",", with: "")
                            .replacingOccurrences(of: ":", with: ".")

                        if cleaned.range(of: #"^\d+\.\d{2}$"#, options: .regularExpression) != nil {
                            return Decimal(string: cleaned)
                        }
                        return nil
                    }).first {

                        price = found
                        break
                    }
                }
            }

            guard let finalPrice = price else { continue }

            // 🔥 extract description (right side only, safe)
            var descParts: [String] = []
            for k in (partIndex+1)..<texts.count {
                let t = texts[k]
                if t.range(of: #"^\d"#, options: .regularExpression) != nil { break }
                if Int(t) == nil {
                    descParts.append(t)
                }
            }

            let description = descParts.isEmpty
                ? "No description"
                : descParts.joined(separator: " ")

            parts.append(
                Part(
                    partNumber: PartNumber(partNumber),
                    description: description,
                    quantity: 1,
                    billedPrice: Money(amount: finalPrice)
                )
            )
        }

        return parts
    }