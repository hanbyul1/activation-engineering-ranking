    
    private func datasetSymptoms(from code: OBDCode, tags: [String]) -> [String] {

        var symptoms: [String] = []

        // 🔹 Tag → dataset mapping
        for tag in tags {
            switch tag.lowercased() {

            case "stall":
                symptoms.append("engine_stall")

            case "start":
                symptoms.append("no_start")

            case "power_loss":
                symptoms.append("loss_power")

            case "coolant":
                symptoms.append("coolant_leak")

            case "brake":
                symptoms.append("brake_pedal")

            case "smell":
                symptoms.append("odor")

            case "overheat":
                symptoms.append("overheat")

            default:
                break
            }
        }

        // 🔹 Description parsing (adds robustness)
        let desc = code.description.lowercased()

        if desc.contains("stall") { symptoms.append("engine_stall") }
        if desc.contains("no start") { symptoms.append("no_start") }
        if desc.contains("power") { symptoms.append("loss_power") }
        if desc.contains("coolant") { symptoms.append("coolant_leak") }
        if desc.contains("check engine") { symptoms.append("check_engine") }

        return Array(Set(symptoms))
    }