func classify(from rawText: String) -> String {
    return classifyCore(rawText)
}


    func classifyCore(from rawText: String) -> String {

        let t = rawText.uppercased()

        // =========================
        // 🔥 1. UTILITY (최우선)
        // =========================
        if t.contains("KWH") ||
           t.contains("MCF") ||
           t.contains("CCF") ||
           t.contains("GALLON") {
            return "utility"
        }

        // =========================
        // 🔥 2. SERVICE (receipt 구조)
        // =========================
        if t.contains("RECEIPT") ||
           t.contains("TRANSACTION") ||
           t.contains("CARD TYPE") ||
           t.contains("APPROVED") ||
           t.contains("VISA") ||
           t.contains("SALE") {
            return "service"
        }

        // =========================
        // 🔥 3. SERVICE (일반 서비스 - 제한)
        // ⚠️ PAYMENT / BALANCE 제거
        // =========================
        if t.contains("INVOICE") ||
           t.contains("DESCRIPTION OF WORK") {
            return "service"
        }

        // =========================
        // 🔥 4. UNKNOWN
        // =========================
        return "unknown"
    }