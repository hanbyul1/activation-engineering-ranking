@ViewBuilder
    private func buttonCell(for feature: FeatureButtonModel) -> some View {
    return buttonCellCore(feature)
}


    @ViewBuilder
    private func buttonCellCore(for feature: FeatureButtonModel) -> some View {
        switch style {

        case .box:
            FeatureButtonBoxView(
                feature: feature,
                isEditing: isEditing,
                onDelete: { onDelete(feature) },
                onTap: {
                    guard !isEditing else { return }
                    onTap(feature)
                },
                isDragging: draggingItem?.id == feature.id,
                onDragChanged: { translation in
                    onDragChanged(feature, translation)
                },
                onDragEnded: onDragEnded
            )
            .opacity(
                featureButtonOpacity(
                    isEditing: isEditing,
                    draggingItemID: draggingItem?.id,
                    buttonID: feature.id
                )
            )
            .offset(draggingItem?.id == feature.id ? dragOffset : .zero)
            .highPriorityGesture(
                LongPressGesture(minimumDuration: 0.45)
                    .onEnded { _ in onLongPress() }
            )
            .gesture(
                isEditing
                ? DragGesture()
                    .onChanged { value in
                        onDragChanged(feature, value.translation)
                    }
                    .onEnded { value in
                        onDragEnded(value.location)
                    }
                : nil
            )

        case .circle:
            FeatureButtonCircleView(
                feature: feature,
                isEditing: isEditing,
                onTap: {
                    guard !isEditing else { return }
                    onTap(feature)
                },
                onDelete: {
                    onDelete(feature)
                },
                isDragging: draggingItem?.id == feature.id,
                onDragChanged: { translation in
                    onDragChanged(feature, translation)
                },
                onDragEnded: onDragEnded
            )
            .opacity(
                featureButtonOpacity(
                    isEditing: isEditing,
                    draggingItemID: draggingItem?.id,
                    buttonID: feature.id
                )
            )
            .offset(draggingItem?.id == feature.id ? dragOffset : .zero)
            .highPriorityGesture(
                LongPressGesture(minimumDuration: 0.45)
                    .onEnded { _ in onLongPress() }
            )
            .gesture(
                isEditing
                ? DragGesture()
                    .onChanged { value in
                        onDragChanged(feature, value.translation)
                    }
                    .onEnded { value in
                        onDragEnded(value.location)
                    }
                : nil
            )
            
        case .hexagon:
            FeatureButtonHexView(
                feature: feature,
                isEditing: isEditing,
                onTap: {
                    guard !isEditing else { return }
                    onTap(feature)
                },
                onDelete: {
                    onDelete(feature)
                },
                isDragging: draggingItem?.id == feature.id,
                onDragChanged: { translation in
                    onDragChanged(feature, translation)
                },
                onDragEnded: onDragEnded
            )
            .opacity(
                featureButtonOpacity(
                    isEditing: isEditing,
                    draggingItemID: draggingItem?.id,
                    buttonID: feature.id
                )
            )
            .offset(draggingItem?.id == feature.id ? dragOffset : .zero)
            .highPriorityGesture(
                LongPressGesture(minimumDuration: 0.45)
                    .onEnded { _ in onLongPress() }
            )
            .gesture(
                isEditing
                ? DragGesture()
                    .onChanged { value in
                        onDragChanged(feature, value.translation)
                    }
                    .onEnded { value in
                        onDragEnded(value.location)
                    }
                : nil
            )
        }
    }