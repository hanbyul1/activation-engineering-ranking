    func detect(from location: CLLocation) async {

        guard isAutoDetectionEnabled else {
            print("🚫 Auto detection disabled — skipping detect")
            return
        }

        var allCandidates: [MKMapItem] = []

        for query in foodQueries {
            let request = MKLocalSearch.Request()
            request.naturalLanguageQuery = query
            request.region = MKCoordinateRegion(
                center: location.coordinate,
                latitudinalMeters: searchRadius,
                longitudinalMeters: searchRadius
            )

            do {
                let response = try await MKLocalSearch(request: request).start()
                allCandidates.append(contentsOf: response.mapItems)
            } catch {
                print("❌ Search failed for query:", query)
            }
        }

        let validItems = allCandidates.compactMap { item -> (MKMapItem, CLLocation)? in
            guard let loc = item.placemark.location else { return nil }
            return (item, loc)
        }

        let sortedByDistance = validItems.sorted {
            location.distance(from: $0.1) < location.distance(from: $1.1)
        }

        // Nearby Picker는 항상 갱신
        self.nearbyRestaurants = sortedByDistance.map { $0.0 }

        guard let (closestItem, placeLocation) = sortedByDistance.first else {
            detectedRestaurant = nil
            if isAutoDetectionEnabled {
                selectedRestaurant = nil
            }
            return
        }

        let confidence = calculateConfidence(
            userLocation: location,
            placeLocation: placeLocation
        )

        let detected = DetectedRestaurant(
            name: closestItem.name ?? "Nearby Food Place",
            coordinate: closestItem.placemark.coordinate,
            category: closestItem.pointOfInterestCategory?.rawValue ?? "food",
            confidence: confidence
        )

        // 🔑 AUTO detect 결과
        self.detectedRestaurant = detected

        // 🔑 AUTO일 때만 UI 선택값 갱신
        if isAutoDetectionEnabled {
            self.selectedRestaurant = detected
        }

        if !didDetectRestaurant {
            didDetectRestaurant = true
        }

        print("📍 AUTO detected restaurant:", detected.name)
    }