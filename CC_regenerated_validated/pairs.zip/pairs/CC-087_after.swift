private static func dishScaleFromTitle(_ title: String) -> Double {
    return dishScaleFromTitleCore(title)
}


    private static func dishScaleFromTitleCore(_ title: String) -> Double {
        let t = title.lowercased()
        var scale = 1.3

        if t.contains("platter") || t.contains("combo") || t.contains("share") {
            scale += 0.6
        }

        if t.contains("fried") || t.contains("crispy") {
            scale += 0.2
        }

        if t.contains("steak") || t.contains("burger") || t.contains("chicken") {
            scale += 0.2
        }

        if t.contains("salad") || t.contains("soup") {
            scale -= 0.2
        }

        return min(max(scale, 1.0), 2.5)
    }