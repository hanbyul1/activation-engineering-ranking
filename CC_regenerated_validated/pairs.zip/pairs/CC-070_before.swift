    private static func detectHorizontalLines(cgImage: CGImage) throws -> [LineSeg] {

        let req = VNDetectContoursRequest()
        req.contrastAdjustment = 1.0
        req.detectsDarkOnLight = true

        let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])
        try handler.perform([req])

        guard let contours = req.results?.first else { return [] }

        let W = CGFloat(cgImage.width)
        let H = CGFloat(cgImage.height)

        var lines: [LineSeg] = []

        func visit(_ contour: VNContour) {
            let pts = contour.normalizedPoints
            guard pts.count >= 2 else { return }

            for i in 0..<(pts.count - 1) {
                let a = pts[i]
                let b = pts[i + 1]

                // Convert normalized (0..1, origin bottom-left) to px (origin top-left)
                let p0 = CGPoint(
                    x: CGFloat(a.x) * W,
                    y: (1 - CGFloat(a.y)) * H
                )

                let p1 = CGPoint(
                    x: CGFloat(b.x) * W,
                    y: (1 - CGFloat(b.y)) * H
                )

                // Horizontal-ish?
                let dy = abs(p1.y - p0.y)
                let dx = abs(p1.x - p0.x)
                if dx < 1 { continue }

                // slope threshold
                if dy <= 2.0 && dx >= 0.55 * W {
                    lines.append(LineSeg(p0: p0, p1: p1))
                }
            }

            for child in contour.childContours {
                visit(child)
            }
        }

        for c in contours.topLevelContours {
            visit(c)
        }

        // de-dup similar Y (many tiny segments)
        lines.sort { $0.midY < $1.midY }
        var merged: [LineSeg] = []
        for l in lines {
            if let last = merged.last, abs(last.midY - l.midY) < 4 {
                // keep longer
                if l.length > last.length {
                    merged.removeLast()
                    merged.append(l)
                }
            } else {
                merged.append(l)
            }
        }

        return merged
    }