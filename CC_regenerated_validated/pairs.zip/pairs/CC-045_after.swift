func addReceiptEstimate(parts: [PriceComparison], vin: String?) {
    addReceiptEstimateCore(parts, vin)
}

    
    func addReceiptEstimateCore(parts: [PriceComparison], vin: String?) {

        // =========================
        // 🔥 CLEAN PART NUMBER
        // =========================
        func cleanPartNumber(_ raw: Any) -> String {
            let str = String(describing: raw)

            if str.contains("PartNumber") {
                return str
                    .replacingOccurrences(of: "PartNumber(rawValue: \"", with: "")
                    .replacingOccurrences(of: "\")", with: "")
            }

            return str
        }

        // =========================
        // 🔥 SAFE MONEY → DOUBLE
        // =========================
        func extractPrice(_ value: Any?) -> Double? {
            guard let value else { return nil }

            // Try direct cast first (fast path)
            if let d = value as? Double { return d }
            if let d = value as? Decimal { return NSDecimalNumber(decimal: d).doubleValue }

            // Fallback: string parsing (handles Money, etc.)
            let str = String(describing: value)

            let filtered = str
                .components(separatedBy: CharacterSet(charactersIn: "0123456789.").inverted)
                .joined()

            return Double(filtered)
        }

        // =========================
        // 🔥 NORMALIZE FOR DUPLICATE CHECK
        // =========================
        let normalizedParts = parts.map {
            cleanPartNumber($0.part.partNumber).lowercased()
        }.sorted()

        let isDuplicate = items.contains { existing in
            let existingParts = existing.parts.map { $0.partNumber.lowercased() }.sorted()

            return existing.category == "Receipt / Estimate" &&
                   existingParts == normalizedParts
        }

        if isDuplicate {
            print("⚠️ DUPLICATE RECEIPT — NOT SAVING")
            return
        }

        // =========================
        // 🔥 CASE NUMBER
        // =========================
        let sameCategory = items.filter { $0.category == "Receipt / Estimate" }
        let caseNumber = sameCategory.count + 1

        // =========================
        // 🔥 BUILD SAVED PARTS (FULL DATA)
        // =========================
        let savedParts: [SavedPart] = parts.map { comparison in

            let partNumber = cleanPartNumber(comparison.part.partNumber)
            let name = partNumber

            let billed = extractPrice(comparison.part.billedPrice)
            let market = extractPrice(comparison.marketPrice)
            let diff = extractPrice(comparison.difference)

            let key = ImageCache.Key.partNumber(name)
            let image = comparison.cachedImage ?? ImageCache.shared.get(key)
            print("💾 SAVE IMAGE | part:", name, "| fromComparison:", comparison.cachedImage != nil, "| fromCache:", ImageCache.shared.get(key) != nil)

            return SavedPart(
                id: UUID(),
                partNumber: name,
                name: name,
                price: market,
                billedPrice: billed,
                difference: diff,
                imageURL: comparison.imageURL,
                sourceURL: comparison.marketURL,
                cachedImage: image
            )
        }

        let savedCount = savedParts.filter { $0.cachedImageData != nil }.count
        print("📦 SAVED PARTS WITH IMAGES:", savedCount, "/", savedParts.count)

        // =========================
        // 🔥 BUILD SAVED DIAGNOSIS
        // =========================
        let item = SavedDiagnosis(
            id: UUID(),
            code: vin ?? "RECEIPT",
            description: "Repair Estimate",
            symptoms: [],
            parts: savedParts,
            date: Date(),
            caseNumber: caseNumber,
            category: "Receipt / Estimate"
        )

        items.insert(item, at: 0)
        save()
    }