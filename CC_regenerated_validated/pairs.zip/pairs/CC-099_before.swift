        
    func saveMenuScanRecord() {

        guard settings.analyticsConsent else {
            print("🚫 No consent — menu scan not saved")
            return
        }

        let snapshots = scannedMenuSnapshots

        // ✅ 1️⃣ restaurantName을 여기서 확정
        let restaurantName =
            restaurantDetector.selectedRestaurant?.name
            ?? "Unknown"

        // ✅ 2️⃣ restaurantKey 생성 (단일 규칙)
        let restaurantKey = RestaurantKeyBuilder.make(
            name: restaurantName,
            address: locationManager.currentAddress
        )
        
        print("🧪 saveMenuScanRecord")
        print("   detectedRestaurant =", restaurantDetector.detectedRestaurant?.name ?? "nil")
        
        let record = MenuScanRecord(
            id: UUID(),
            scannedAt: Date(),
            source: .ocr, 
            restaurantName: restaurantName,
            restaurantKey: restaurantKey,
            address: locationManager.currentAddress,
            latitude: locationManager.currentLocation?.coordinate.latitude,
            longitude: locationManager.currentLocation?.coordinate.longitude,
            rawText: menuInput,
            items: snapshots
        )

        MenuScanStore.shared.save(record)
        print("✅ MenuScanRecord saved:", record.id)
        
        // ✅ CalCoin 보상 + 토스트
        if CalCoinStore.shared.rewardOnceForMenuScan(
            recordId: record.id.uuidString
        ) {
            pendingCalCoinReward = true
            didShowCalCoinToastForThisScan = false

            // 🔔 햅틱은 즉시 OK (보상 느낌)
            UINotificationFeedbackGenerator()
                .notificationOccurred(.success)
        }

        AnalyticsEventStore.shared.log(.menuSaved)
        
        saveUserScannedRestaurantIfNeeded()
    }