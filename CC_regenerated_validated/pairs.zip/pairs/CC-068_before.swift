    
    private func extractCCCPartsFromText(_ text: String) -> [Part] {

        let lines = text.components(separatedBy: .newlines)
        var parts: [Part] = []

        for line in lines {

            let clean = line.trimmingCharacters(in: .whitespaces)

            // must contain "Repl" (real part row)
            guard clean.uppercased().contains("REPL") ||
                  clean.range(of: #"\b\d{7,10}\b"#, options: .regularExpression) != nil
            else {
                continue
            }

            // 🔹 find part number
            guard let partMatch = clean.range(of: #"\b\d{7,10}\b"#, options: .regularExpression) else {
                continue
            }

            let partNumber = String(clean[partMatch])

            // 🔹 find ALL prices in line
            let priceRegex = try? NSRegularExpression(
                pattern: #"\d{1,3}(?:,\d{3})*\.\d{2}"#
            )

            let matches = priceRegex?.matches(
                in: clean,
                range: NSRange(clean.startIndex..., in: clean)
            ) ?? []

            let priceMatches: [String] = matches.compactMap {
                Range($0.range, in: clean).map { String(clean[$0]) }
            }

            guard !priceMatches.isEmpty else { continue }

            // 🔥 CRITICAL: choose FIRST or SMALLEST (unit price)
            let priceText = priceMatches
                .map { $0.replacingOccurrences(of: ",", with: "") }
                .compactMap { Decimal(string: $0) }
                .min()

            guard let price = priceText else { continue }

            // 🔹 description = text BEFORE part number
            var desc = clean[..<partMatch.lowerBound]
                .replacingOccurrences(of: "Repl", with: "", options: .caseInsensitive)
                .trimmingCharacters(in: .whitespaces)

            // 🔥 REMOVE leading line numbers like "9", "8", etc.
            if let match = desc.range(of: #"^\d+\s+"#, options: .regularExpression) {
                desc.removeSubrange(match)
            }

            parts.append(
                Part(
                    partNumber: PartNumber(partNumber),
                    description: desc.isEmpty ? "No description" : desc,
                    quantity: 1,
                    billedPrice: Money(amount: price)
                )
            )
        }

        return parts
    }