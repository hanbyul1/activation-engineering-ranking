func openMapForShop() {
    openMapForShopCore()
}


    func openMapForShopCore() {

        guard mapEnabled else {
            pendingMapAction = .shop
            activeAlert = .map
            return
        }

        let shopName = normalizeShopName(receipt.shopName)
        let businessAddress = cleanBusinessAddress(receipt.address)

        guard !shopName.isEmpty else {
            openFallbackMapSearch()
            return
        }

        func runSearch(near targetLocation: CLLocation?) {

            let request = MKLocalSearch.Request()
            request.naturalLanguageQuery = shopName

            if let targetLocation {
                request.region = MKCoordinateRegion(
                    center: targetLocation.coordinate,
                    span: MKCoordinateSpan(latitudeDelta: 0.08, longitudeDelta: 0.08)
                )
            }

            MKLocalSearch(request: request).start { response, _ in

                let items = response?.mapItems ?? []

                guard !items.isEmpty else {
                    if let businessAddress {
                        openMap(address: businessAddress)
                    } else {
                        openFallbackMapSearch()
                    }
                    return
                }

                let ranked = items.sorted {
                    scoreMapItem($0, shopName: shopName, targetLocation: targetLocation)
                    >
                    scoreMapItem($1, shopName: shopName, targetLocation: targetLocation)
                }

                if let best = ranked.first {
                    best.openInMaps(launchOptions: nil)
                } else if let businessAddress {
                    openMap(address: businessAddress)
                } else {
                    openFallbackMapSearch()
                }
            }
        }

        // 🔥 iOS 26 방식 geocoding
        if let businessAddress, !businessAddress.isEmpty {

            geocodeAddress(businessAddress) { location in
                runSearch(near: location)
            }

        } else {
            runSearch(near: nil)
        }
    }