    
    private func extractElectricUsageFromTable(
        rows: [OCRRow]
    ) -> Double? {

        print("🧠 TRY ELECTRIC TABLE EXTRACTION")

        for row in rows {

            let upper = row.fullText.uppercased()

            // 헤더 제외
            if upper.contains("USAGE") && upper.contains("KWH") {
                continue
            }

            // 날짜 있는 row만
            let datePattern = #"\d{2}/\d{2}/\d{4}"#
            guard row.fullText.range(of: datePattern, options: .regularExpression) != nil else {
                continue
            }

            let nums = row.fullText.matches(for: #"\d+(\.\d+)?"#)
                .compactMap { Double($0[0]) }

            if nums.count >= 4 {

                // 🔥 핵심 FIX
                let tail = Array(nums.suffix(3))

                if tail.count == 3 {

                    let usage = tail[0]   // [usage, cost, amount]

                    if usage > 0 && usage < 100000 {
                        print("✅ ELECTRIC TABLE USAGE FOUND:", usage)
                        return usage
                    }
                }
            }
        }

        return nil
    }