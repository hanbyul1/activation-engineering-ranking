    
    private func findDateNearLabel(
        keywordSets: [[String]],
        items: [OCRItem]
    ) -> String? {

        for keywords in keywordSets {

            if let anchor = findLabelAnchorFlexible(keywords: keywords, items: items) {

                let candidates = items.filter { isDate($0.text) }

                var best: OCRItem?
                var bestScore = CGFloat.greatestFiniteMagnitude

                for c in candidates {

                    let dx = abs(c.box.midX - anchor.box.midX)
                    let dy = abs(c.box.midY - anchor.box.midY)

                    if dx < 0.35 && dy < 0.15 {
                        let score = dx + dy

                        if score < bestScore {
                            bestScore = score
                            best = c
                        }
                    }
                }

                if let result = best?.text {
                    return result
                }
            }
        }

        return nil
    }