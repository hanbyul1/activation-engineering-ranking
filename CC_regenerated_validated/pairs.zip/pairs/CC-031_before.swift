    func extractAddress(from items: [OCRItem]) -> String? {
        // 1) City/State/Zip 후보군 추출 (Zip+4 대응 정규식으로 수정)
        let cityCandidates: [OCRItem] = items.compactMap { item -> OCRItem? in
            let cleaned = item.text.trimmingCharacters(in: .whitespacesAndNewlines)

            // 🔥 수정: 5자리 혹은 5-4자리(Zip+4) 형태를 모두 허용
            // 또한 OCR 오류로 인한 "48307-22.70" 형태도 일단 잡기 위해 패턴 확장
            let zipPattern = #"[A-Z\s]+,?\s*[A-Z]{2}\s+\d{5}(?:[-\s]\d{2,4}(?:\.\d{2})?)?"#
            
            guard let match = cleaned.range(
                of: zipPattern,
                options: [.regularExpression, .caseInsensitive]
            ) else {
                return nil
            }

            var fixed = String(cleaned[match])
            
            // 🛠️ 복원 로직: "48307-22.70" -> "48307-2270"
            fixed = fixed.replacingOccurrences(
                of: #"(\d{5})[-\s](\d{2})\.(\d{2})"#,
                with: "$1-$2$3",
                options: .regularExpression
            )

            return OCRItem(text: fixed, box: item.box)
        }

        let streetCandidates: [OCRItem] = items.compactMap { item -> OCRItem? in
            let cleaned = removeDateFragments(from: item.text)
                .trimmingCharacters(in: .whitespacesAndNewlines)

            // Street Address에서 금액으로 오인된 소수점 제거 (예: 123 Main St.22 -> 123 Main St 22)
            let fixed = cleaned.replacingOccurrences(
                of: #"\.(\d{2})$"#,
                with: "$1",
                options: .regularExpression
            )

            guard !cleaned.isEmpty else { return nil }
            guard !isDate(cleaned) else { return nil }
            
            // 🔥 수정: Zip+4 부분이 금액으로 오인되어 필터링되지 않도록
            // 주소 라인일 가능성이 높으면 isAmount 체크를 우회하거나 완화함
            if !isStreetAddressLine(fixed) { return nil }

            return OCRItem(text: fixed, box: item.box)
        }

        // 2) Pair matching (Street와 City/Zip이 수직으로 가까운지 확인)
        if !cityCandidates.isEmpty && !streetCandidates.isEmpty {
            var bestPair: (street: OCRItem, city: OCRItem)?
            var bestScore = CGFloat.greatestFiniteMagnitude

            for city in cityCandidates {
                for street in streetCandidates {
                    let dx = abs(street.box.minX - city.box.minX)
                    let dy = abs(street.box.midY - city.box.midY)

                    // 같은 왼쪽 정렬 선상에 있고 위아래로 인접한 경우
                    if dx > 0.15 { continue }
                    if dy > 0.08 { continue }

                    let score = dx + dy
                    if score < bestScore {
                        bestScore = score
                        bestPair = (street, city)
                    }
                }
            }

            if let pair = bestPair {
                return "\(pair.street.text), \(pair.city.text)"
            }
        }

        // 3) Row fallback (개별 토큰이 찢어졌을 때 Row 단위에서 재시도)
        if let addressFromRows = extractAddressFromRows(rows: processor.buildLooseRows(items)) {
            return addressFromRows
        }

        return cityCandidates.first?.text // 최후의 수단
    }