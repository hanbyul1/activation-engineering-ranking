private func extractRowBased(_ tokens: [OCRToken]) -> [Part] {
    return extractRowBasedCore(tokens)
}

    
    private func extractRowBasedCore(_ tokens: [OCRToken]) -> [Part] {
        
        let rows = groupTokensIntoRows(tokens)
        var parts: [Part] = []
        
        for row in rows {
            let texts = row.map { $0.text }
            let rowText = texts.joined(separator: " ").uppercased()
            
            // 🔥 FILTER OUT NON-PART ROWS
            
            if rowText.contains("SUBTOTAL") ||
                rowText.contains("TOTAL") ||
                rowText.contains("TAX") ||
                rowText.contains("LABOR") ||
                rowText.contains("SUPPLIES") ||
                rowText.contains("FEE") ||
                rowText.contains("PART NUMBER") ||
                rowText.contains("PART PRICE") ||
                rowText.contains("EXT PRICE") ||
                rowText.contains("MISC") {
                continue
            }
            
            // 🔥 NEW: support "part # XXXXX" pattern (tire receipts, narrative style)
            var partNumber: String?
            
            if let strict = extractPartNumber(from: texts) {
                partNumber = strict
            } else if let loose = texts.first(where: { isLoosePartNumber($0) }) {
                partNumber = loose
            } else if let partHashIndex = texts.firstIndex(where: { $0 == "#" || $0.uppercased() == "#" }) {
                if partHashIndex + 1 < texts.count {
                    let candidate = texts[partHashIndex + 1]
                    if candidate.range(of: #"^\d{6,10}$"#, options: .regularExpression) != nil {
                        partNumber = candidate
                    }
                }
            } else if let partWordIndex = texts.firstIndex(where: { $0.uppercased().contains("PART") }),
                      partWordIndex + 2 < texts.count,
                      texts[partWordIndex + 1] == "#" {
                let candidate = texts[partWordIndex + 2]
                if candidate.range(of: #"^\d{6,10}$"#, options: .regularExpression) != nil {
                    partNumber = candidate
                }
            }
            
            guard let partNumber else { continue }
            
            guard let partIndex = texts.firstIndex(of: partNumber) ?? texts.firstIndex(where: { $0 == partNumber }) else { continue }
            
            let quantity = extractQuantity(from: texts, partIndex: partIndex)
            
            // 🔥 NEW: better price extraction for inline "$XXX.XX" formats
            let price = extractInlinePrice(texts: texts)
            ?? extractBestPrice(texts: texts, partIndex: partIndex)
            ?? extractNearestGlobalPrice(for: row, allTokens: tokens)
            
            guard let price else { continue }
            
            let description = extractFlexibleDescription(texts: texts, partIndex: partIndex)
            
            parts.append(
                Part(
                    partNumber: PartNumber(partNumber),
                    description: description,
                    quantity: quantity,
                    billedPrice: Money(amount: price)
                )
            )
        }
        
        return parts
    }