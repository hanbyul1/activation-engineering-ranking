func detectPriceAnchors(from blocks: [OCRBlock], imageWidth: Double) -> [PriceAnchor] {
    return detectPriceAnchorsCore(blocks, imageWidth)
}


func detectPriceAnchorsCore(from blocks: [OCRBlock], imageWidth: Double) -> [PriceAnchor] {

    // ----------------------------
    // 0) 준비: 정렬 + price/title 후보
    // ----------------------------
    let sorted = blocks.sorted { $0.yPosition < $1.yPosition }

    let priceBlocks: [OCRBlock] = sorted.filter { b in
        b.hasPrice || MenuParser.containsPrice(b.text)
    }

    // 폰트 분포 기반 title threshold 계산
    let fonts = sorted.map { $0.relativeFontSize }.sorted()
    let medianFont = fonts.isEmpty ? 14.0 : fonts[fonts.count / 2]
    let p75Font: Double = {
        guard !fonts.isEmpty else { return medianFont }
        let idx = Int(Double(fonts.count - 1) * 0.75)
        return fonts[max(0, min(fonts.count - 1, idx))]
    }()

    // 메뉴에서 title은 보통 "상대적으로 확실히 큼"
    let titleThreshold = max(p75Font, medianFont * 1.25)

    let titleCandidates: [OCRBlock] = sorted.filter { b in
        if b.hasPrice || MenuParser.containsPrice(b.text) { return false }
        if MenuParser.isNoiseBlock(b.text) { return false }
        if b.relativeFontSize < titleThreshold { return false }
        return true
    }

    let titles = titleCandidates.sorted { $0.yPosition < $1.yPosition }

    print("🧱 detectPriceAnchors START")
    print("   blocks=\(blocks.count) prices=\(priceBlocks.count) titles=\(titles.count)")
    print("   medianFont=\(medianFont) p75=\(p75Font) titleThreshold=\(titleThreshold)")

    // ----------------------------
    // 1) Title 구간별로 price 매칭
    // ----------------------------
    var anchors: [PriceAnchor] = []
    var usedPriceIDs = Set<UUID>()

    let rowTol: Double = 18.0
    let belowTol: Double = 60.0

    // 🔹 Strategy B 전용 tolerance
    let belowOnlyMinGap: Double = 12.0
    let belowOnlyMaxGap: Double = 140.0

    for i in 0..<titles.count {
        let title = titles[i]
        let nextTitleY: Double =
            (i + 1 < titles.count)
            ? titles[i + 1].yPosition
            : Double.greatestFiniteMagnitude

        let sectionMinY = title.yPosition - rowTol
        let sectionMaxY = nextTitleY - rowTol

        print("\n🧩 TITLE[\(i)] '\(title.text)' y=\(title.yPosition) font=\(title.relativeFontSize)")
        print("   section=[\(sectionMinY) .. \(sectionMaxY)) nextTitleY=\(nextTitleY)")

        // ============================================================
        // 🅰️ Strategy A: 가격이 제목 오른쪽에 있는 경우 (기존 로직)
        // ============================================================
        var candidatesA = priceBlocks.filter { p in
            if usedPriceIDs.contains(p.id) { return false }
            if p.xPosition <= title.xPosition { return false }

            let sameRow = abs(p.yPosition - title.yPosition) <= rowTol
            let nearBelow =
                (p.yPosition >= title.yPosition - rowTol) &&
                (p.yPosition <= title.yPosition + belowTol)

            let inSection =
                (p.yPosition >= sectionMinY) &&
                (p.yPosition < sectionMaxY)

            return inSection && (sameRow || nearBelow)
        }

        candidatesA.sort {
            abs($0.yPosition - title.yPosition) <
            abs($1.yPosition - title.yPosition)
        }

        print("   🅰️ Strategy A priceCandidates=\(candidatesA.count)")
        for p in candidatesA.prefix(3) {
            print("      💰 '\(p.text)' x=\(p.xPosition) y=\(p.yPosition)")
        }

        var chosenPrice: OCRBlock? = candidatesA.first

        // ============================================================
        // 🅱️ Strategy B: 가격이 제목 아래 단독으로 있는 경우 (추가)
        // ============================================================
        if chosenPrice == nil {
            let candidatesB = priceBlocks.filter { p in
                if usedPriceIDs.contains(p.id) { return false }

                if p.yPosition <= title.yPosition + belowOnlyMinGap { return false }
                if p.yPosition >= nextTitleY - belowOnlyMinGap { return false }

                let dy = p.yPosition - title.yPosition
                return dy <= belowOnlyMaxGap
            }
            .sorted {
                abs($0.yPosition - title.yPosition) <
                abs($1.yPosition - title.yPosition)
            }

            print("   🅱️ Strategy B priceCandidates=\(candidatesB.count)")
            for p in candidatesB.prefix(3) {
                print("      💰 '\(p.text)' y=\(p.yPosition)")
            }

            chosenPrice = candidatesB.first
        }

        guard let finalPrice = chosenPrice else {
            print("   ❌ NO PRICE MATCHED for title '\(title.text)'")
            continue
        }

        usedPriceIDs.insert(finalPrice.id)
        print("   ✅ CHOSEN PRICE = '\(finalPrice.text)' y=\(finalPrice.yPosition)")

        // ----------------------------
        // 2) descriptions 수집
        // ----------------------------
        let desc = sorted.filter { b in
            if b.id == title.id { return false }
            if b.id == finalPrice.id { return false }
            if b.hasPrice || MenuParser.containsPrice(b.text) { return false }
            if MenuParser.isNoiseBlock(b.text) { return false }

            if b.yPosition <= title.yPosition + 2 { return false }
            if b.yPosition >= nextTitleY - 1 { return false }

            if b.relativeFontSize >= title.relativeFontSize * 0.98 { return false }

            return true
        }

        if desc.isEmpty {
            print("   🧾 DESCRIPTION: (none)")
        } else {
            print("   🧾 DESCRIPTION count=\(desc.count)")
            for d in desc {
                print("      • '\(d.text)' y=\(d.yPosition)")
            }
        }

        anchors.append(
            PriceAnchor(
                price: finalPrice,
                title: title,
                descriptions: desc
            )
        )
    }

    print("\n🧱 detectPriceAnchors END anchors=\(anchors.count)")
    return anchors
}