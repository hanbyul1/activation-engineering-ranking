private func normalizeComponent(_ input: String) -> String {
    return normalizeComponentCore(input)
}

    private func normalizeComponentCore(_ input: String) -> String {

        let lower = input.lowercased()

        if lower.contains("coil") { return "ignition coil" }
        if lower.contains("spark") || lower.contains("plug") { return "spark plug" }
        if lower.contains("injector") { return "fuel injector" }

        if lower.contains("mass air flow") || lower.contains("maf") {
            return "mass air flow sensor"
        }

        if lower.contains("o2") || lower.contains("oxygen") {
            return "oxygen sensor"
        }

        if lower.contains("fuel rail") { return "fuel rail" }
        if lower.contains("pressure sensor") { return "fuel pressure sensor" }
        if lower.contains("regulator") { return "fuel pressure regulator" }
        if lower.contains("pump") { return "fuel pump" }

        return input
    }